# This file contains the configuration for the project
# It is used to define the paths to the data and the data structure

import os
import boto3
from botocore.credentials import InstanceMetadataProvider, InstanceMetadataFetcher


def get_s3_bucket(bucket_name):
    if 'AWS_ACCESS_KEY_ID' in os.environ and 'AWS_SECRET_ACCESS_KEY' in os.environ:
        if 'AWS_REGION' in os.environ:
            region_name = os.environ['AWS_REGION']
        else:
            region_name = 'us-west-1'
        access_key = os.environ['AWS_ACCESS_KEY_ID']
        secret_key = os.environ['AWS_SECRET_ACCESS_KEY']
        s3 = boto3.resource('s3', aws_access_key_id=access_key,
                            aws_secret_access_key=secret_key,
                            region_name=region_name)

        s3_bucket = s3.Bucket(bucket_name)
    else:
        if 'AWS_REGION' in os.environ:
            region_name = os.environ['AWS_REGION']
        else:
            region_name = 'us-west-2'
        provider = InstanceMetadataProvider(iam_role_fetcher=InstanceMetadataFetcher(timeout=1000, num_attempts=2))
        creds = provider.load()
        access_key = creds.access_key
        secret_key = creds.secret_key
        token = creds.token
        s3 = boto3.resource('s3', aws_access_key_id=access_key,
                            aws_secret_access_key=secret_key,
                            region_name=region_name,
                            aws_session_token=token)

        s3_bucket = s3.Bucket(bucket_name)
    return s3_bucket


# workspace path configuration
workspace = '/data/work/hippo/file_io'
bucket_name = str(os.environ['HIPPO_SERVER_S3_BUCKET_NAME']) if 'HIPPO_SERVER_S3_BUCKET_NAME' in os.environ else 'hippoclinic'
port = str(os.environ['HIPPO_SERVER_PORT']) if 'HIPPO_SERVER_PORT' in os.environ else 50051

air_url = "https://air.radiology.ucsf.edu/api/secure/search/download/zip"

# natus data path configuration
#natus_root_path = str(os.environ['NATUS_ROOT_PATH'])
natus_sub_folder_suffix = 'EDF buffer'
# natus_sub_folder_prefix = ['Neuroworks', 'NWRECENT']
natus_sub_folder_prefix = ['NWRECENT']
# natus_sub_folder_suffix = ['DbData']
# natus_sub_folder_suffix = ['DBDATA']

# backend api configuration
device_data_api = '/hippo/patient/deviceData/s3ProcessUploadedFiles'
natus_callback_api = '/hippo/patient/natus/upsertPatientDataList'
natus_hospital_id = '814935994162876416'
call_batch_size = 50
# scan natus raw files time at 00:00 every day
scaner_time = "00:00"