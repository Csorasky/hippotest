#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# refer https://blog.csdn.net/caoxinjian423/article/details/84196609
import os
import logging
import logging.config
import json
import datetime
from config import workspace


class Logger():
    def __init__(self,
                 name='hippo_data',
                 configFile="logconf.json",
                 logFile=None,
                 queue=None):

        # if name not in logging.Logger.manager.loggerDict:
        self.logger = logging.getLogger(name)
        if configFile:
            config_file_path = configFile
            if not os.path.exists(configFile):
                config_file_path = os.path.join(os.path.dirname(__file__),
                                                "logconf.json")
            with open(config_file_path, "r") as config:
                configDict = json.load(config)
                print(configDict['loggers'])
                if logFile:
                    file_handler_name = configDict["loggers"][name]["handlers"][1]
                    configDict["handlers"][file_handler_name]["filename"] = logFile
                    # print(file_handler_name, logFile)
                logging.config.dictConfig(configDict)
        else:
            assert False, "Can not goto here"
            if logFile:
                self.logger = logging.basicConfig(filename=logFile)
            else:
                self.logger = logging.basicConfig()
        if queue:
            queue_hanler = logging.handlers.QueueHandler(queue)
            self.logger.addHandler(queue_hanler)
        # else:
        #     self.logger = logging.getLogger(name)


LOG_CONF_PATH = os.path.join(os.path.dirname(__file__), "logconf.json")


def setup_log_hippo():
    log_dir = os.path.join(workspace, 'log')
    if not os.path.exists(log_dir):
        os.makedirs(log_dir, exist_ok=True)
    log_name = 'hippo_data_{}.log'.format(datetime.datetime.now().strftime('%Y-%m-%d_%H:%M:%S'))
    log_path = os.path.join(log_dir, log_name)
    logger = Logger(name='hippo_data', configFile=LOG_CONF_PATH, logFile=log_path).logger
    return logger


if __name__ == "__main__":
    log_app = Logger(name='hippo_data', configFile=LOG_CONF_PATH).logger
    log_app.warning("it is warning")
    log_app.error("it is error")
    log_app.debug("it is debug")
