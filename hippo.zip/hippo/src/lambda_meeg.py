import os
import numpy as np
import shutil
from math import floor
import io
import mne
import bspline
from scipy.spatial import distance_matrix
import sys
import copy

from hippo.proto.hippo.common import s3_file_pb2
from hippo.proto.hippo.web import device_data_pb2
from hippo.proto.hippo.common import data_type_pb2
from hippo.comm import config
from hippo.proto.hippo.common.data_type_pb2 import DataFileFormat
from hippo.proto.hippo.common.common_pb2 import BooleanType

resample_fsample = 250
max_segment_length = 200
max_padding_length = 1  # 1s


def download_s3_folder(bucket, s3_folder, local_dir=None):
    """
    Download the contents of a folder directory
    Args:
        bucket_name: the name of the s3 bucket
        s3_folder: the folder path in the s3 bucket
        local_dir: a relative or absolute directory path in the local file system
    """
    for obj in bucket.objects.filter(Prefix=s3_folder):
        target = obj.key if local_dir is None \
            else os.path.join(local_dir, os.path.relpath(obj.key, s3_folder))
        if not os.path.exists(os.path.dirname(target)):
            os.makedirs(os.path.dirname(target), exist_ok=True)
        if obj.key[-1] == '/':
            continue
        bucket.download_file(obj.key, target)


def delete_s3_folder(bucket, s3_folder):
    objects = bucket.objects.filter(Prefix=s3_folder)
    for obj in objects:
        obj.delete()


def get_coef_param(raw_data):
    t = raw_data.times
    x_matrix = np.float32(np.vstack((np.ones(len(t)), t)))
    temp = np.dot(x_matrix, x_matrix.transpose())
    xx_inv = np.linalg.inv(temp)
    x_data = np.dot(xx_inv, x_matrix)
    return x_data


def get_global_coef(raw_data, original_sfreq, x_parameter):
    segment_duration = 1 * 60 * 3  # s
    current_time = raw_data.times[0]
    end_time = raw_data.times[-1]
    current_index = 0
    end_index = raw_data.n_times + 1
    global_coef = np.zeros((2, raw_data.info['nchan'])).astype(np.float32)
    while current_time < end_time:
        segment_end = current_time + segment_duration
        segment_index = current_index + int(segment_duration * original_sfreq)
        if segment_end > end_time:
            segment_end = end_time
        if segment_index > end_index:
            segment_index = end_index
        if end_time != segment_end:
            segmented_raw = raw_data.copy().crop(tmin=current_time, tmax=segment_end, include_tmax=False)
        else:
            segmented_raw = raw_data.copy().crop(tmin=current_time, tmax=segment_end, include_tmax=True)

        data_seg, seg_times = segmented_raw.load_data()[:]
        x = x_parameter[:, current_index: segment_index]
        coef = np.float32(np.dot(x, np.float64(data_seg.transpose())))
        global_coef += coef
        current_time = segment_end
        current_index = segment_index
    return global_coef


def find_duplicate_indexes(lst):
    arr = np.array(lst)
    unique_values, counts = np.unique(arr, return_counts=True)
    duplicate_values = unique_values[counts > 1]
    index_dict = {value: np.where(arr == value)[0].tolist() for value in duplicate_values}
    return index_dict


def convert_data_unit(raw_data, meg_unit, eeg_unit, channel_types):
    data = raw_data.copy()
    if meg_unit == 'FIFF_UNIT_T':
        m_ix = np.where((np.array(channel_types) == 'mag'))[0]

        data[m_ix, :] = data[m_ix, :] * 1e15
    if eeg_unit == 'FIFF_UNIT_V':
        e_ix = np.where((np.array(channel_types) == 'eeg'))[0]
        data[e_ix, :] = data[e_ix, :] * 1e7
    return data


def get_map_channel_names(raw_ch_names, layout_names):
    sq_ch_names = []
    sq_map_layout_names = []
    for layout_name in layout_names:
        for ch_name in raw_ch_names:
            if layout_name.lower() in ch_name.lower():
                sq_ch_names.append(ch_name)
                sq_map_layout_names.append(layout_name)

    origin_list = sorted(zip(sq_ch_names, sq_map_layout_names), key=lambda item: len(item[1]))

    sorted_mp = np.array(origin_list)[:, 1].tolist()
    sorted_ch = np.array(origin_list)[:, 0].tolist()

    indexes = find_duplicate_indexes(sorted_ch)

    if indexes:
        values_to_remove = []
        for sub_index in indexes.values():
            for i in range(len(sub_index)):
                if i != len(sub_index) - 1:
                    values_to_remove.append(sub_index[i])
        final_mp_channel = [sorted_mp[i] for i in range(len(sorted_mp)) if i not in values_to_remove]
        final_raw_channel = [sorted_ch[i] for i in range(len(sorted_ch)) if i not in values_to_remove]
    else:
        final_mp_channel = sorted_mp
        final_raw_channel = sorted_ch

    raw_map_channel_names = []
    reference_chnanel_names = []
    prefixes = ["DC", "EMG", "EOG", "ECG", "Events", "STIM", "PHO"]
    for name in raw_ch_names:
        if name in final_raw_channel:
            if any(name.startswith(prefix) for prefix in prefixes):
                map_name = ''
                raw_map_channel_names.append(map_name)
                reference_chnanel_names.append(name)
            else:
                map_name = final_mp_channel[final_raw_channel.index(name)]
                raw_map_channel_names.append(map_name)
        else:
            map_name = ''
            raw_map_channel_names.append(map_name)
            reference_chnanel_names.append(name)
    # remove duplicate map channel names
    indexes_map = find_duplicate_indexes(raw_map_channel_names)
    for item in indexes_map.items():
        if item[0] != '':
            duplicate_raw_channel = raw_ch_names[item[1]]
            duplicate_raw_channel_list = duplicate_raw_channel.tolist()
            min_length_index = duplicate_raw_channel_list.index(min(duplicate_raw_channel_list, key=len))
            for dup_idx in item[1]:
                if dup_idx != item[1][min_length_index]:
                    raw_map_channel_names[dup_idx] = ''
                    reference_chnanel_names.append(raw_ch_names[dup_idx])

    return np.array(raw_map_channel_names), np.array(reference_chnanel_names)


def get_top_map(channel_pos, xyv, spacex, spacey, nknots=7):
    """
    channel_pos is the MX2 dimensional position matrix with M be the number of channels
    xyv is the NX2 dmensional position want to have values.
    spacex, spacey, extra points add to the end of x, y coordinate.
    """

    dist_m = distance_matrix(channel_pos, xyv)
    bdwth = dist_m.std() / 10
    dx = np.exp(-(dist_m / (bdwth)) ** 2)
    dnom = dx.sum(0)
    dx = dx / dnom[np.newaxis, :]  ### first stage smoothing
    p = 3
    knot_x = np.linspace(min(xyv[:, 0]), max(xyv[:, 0]), nknots)
    knot_y = np.linspace(min(xyv[:, 1]), max(xyv[:, 1]), nknots)
    knots_x = np.concatenate(((xyv[:, 0].min() - spacex).reshape(1), knot_x, (xyv[:, 0].max() + spacex).reshape(1)))
    knots_y = np.concatenate(((xyv[:, 1].min() - spacey).reshape(1), knot_y, (xyv[:, 1].max() + spacey).reshape(1)))
    b_x = bspline.Bspline(knots_x, p)
    b_y = bspline.Bspline(knots_y, p)
    beval_x = b_x.collmat(xyv[:, 0])
    beval_y = b_y.collmat(xyv[:, 1])
    beval_vec = np.zeros((beval_x.shape[0], int((beval_x.shape[1]) * (beval_y.shape[1]))))
    for i in range(beval_x.shape[0]):
        beval_vec[i, :] = np.kron(beval_x[i, :], beval_y[i, :])
    xx_inv = np.linalg.inv(beval_vec.transpose() @ beval_vec)
    return dx, xx_inv, beval_vec


def get_channel_pos(raw_ch_names, data_type, edf_file):
    if data_type == 'MEG':
        layout = mne.channels.read_layout('CTF275')  ###change to EEG1005 for eeg meg CTF275
        raw_map_channel_names, reference_chnanel_names = get_map_channel_names(raw_ch_names, layout.names)

    if data_type == 'EEG':
        layout = mne.channels.read_layout('EEG1005')  ###change to EEG1005 for eeg meg CTF275
        # eeg channel names here T3 <-> T7, T4 <->T8, T5<->P7, T6<->T8.
        extension = ['T3', 'T4', 'T5', 'T6']
        if not edf_file:
            deault_map_ch_names = ['Fp1', 'Fp2', 'F3', 'F4', 'C3', 'C4', 'P3', 'P4', 'O1', 'O2', 'F7', 'F8', 'T7', 'T8',
                                   'P7', 'P8',
                                   'Fz', 'Cz', 'Pz']
            tmp = copy.deepcopy(raw_ch_names)
            if len(tmp) < len(deault_map_ch_names):
                tmp = deault_map_ch_names[:len(tmp)]
            else:
                tmp[:19] = deault_map_ch_names
            raw_map_channel_names, reference_chnanel_names = get_map_channel_names(tmp, layout.names + extension)

        else:
            raw_map_channel_names, reference_chnanel_names = get_map_channel_names(raw_ch_names,
                                                                                   layout.names + extension)

            # for some cases, the channel names are not exactly the same as the layout names, but they are similar
            # so we need to check if the channel names are similar to the layout names, for example,
            # if the channel name is 'T7-T8', we remove it but set type as 'EEG'
            lowercase_layout_names = [item.lower() for item in layout.names + extension]
            for i, raw_name in enumerate(raw_ch_names):
                if '-' in raw_name:
                    split_names = raw_name.split('-')
                    if len(split_names) == 2 \
                            and split_names[0].lower() in lowercase_layout_names \
                            and split_names[1].lower() in lowercase_layout_names:
                        raw_map_channel_names[i] = ''

            reference_chnanel_names_copy = copy.deepcopy(reference_chnanel_names.tolist())
            remove_channel_names = []
            for j, reference_name in enumerate(reference_chnanel_names_copy):
                if '-' in reference_name:
                    reference_split_names = reference_name.split('-')
                    if len(reference_split_names) == 2 \
                            and reference_split_names[0].lower() in lowercase_layout_names \
                            and reference_split_names[1].lower() in lowercase_layout_names:
                        remove_channel_names.append(reference_name)
            reference_chnanel_names = np.array(set(reference_chnanel_names) - set(remove_channel_names))

    layout_channel_name = np.array(layout.names)
    layout_channel_pos = layout.pos[:, :2]
    return raw_map_channel_names, layout_channel_pos, layout_channel_name, reference_chnanel_names


def convert_byte8(re_part_single_ch_data):
    uint8_min = 0
    uint8_max = 255
    segment_byte8 = []
    for part_data in re_part_single_ch_data:
        # convert data to uint8 format
        data_min = np.min(part_data)
        data_max = np.max(part_data)

        if data_max != data_min:
            int8_part_single_ch_data = np.round(
                ((part_data - data_min) / (data_max - data_min)) * (uint8_max - uint8_min) + uint8_min)
        else:
            int8_part_single_ch_data = part_data * 0
        segments_byte8_data = b''

        uint8_part_single_ch_data_byte = [int(i).to_bytes(1, 'big', signed=False) for i in
                                          int8_part_single_ch_data]

        for uint8_byte in uint8_part_single_ch_data_byte:
            segments_byte8_data += uint8_byte

        byte8_data = s3_file_pb2.SingleChannelSignalSegmentByte8(data=segments_byte8_data,
                                                                 minValue=data_min,
                                                                 maxValue=data_max)
        segment_byte8.append(byte8_data)
    return segment_byte8


def generate_topmap_data(channel_pos):
    N = 50
    spacex = (channel_pos[:, :].max() - channel_pos[:, :].min()) / N * 2
    spacey = (channel_pos[:, :].max() - channel_pos[:, :].min()) / N * 2
    xi = np.linspace(channel_pos[:, :].min() - spacex, channel_pos[:, :].max() + spacex, N)
    yi = np.linspace(channel_pos[:, :].min() - spacey, channel_pos[:, :].max() + spacey, N)
    xyi = np.meshgrid(xi, yi)
    xyv = np.hstack((xyi[0].reshape((N ** 2, 1)), xyi[1].reshape((N ** 2, 1))))

    x, y = [], []
    for i in range(channel_pos.shape[0]):
        x.append(channel_pos[i, 0])
        y.append(channel_pos[i, 1])

    dx, xx_inv, beval_vec = get_top_map(channel_pos, xyv, spacex, spacey, nknots=7)
    return dx, xx_inv, beval_vec


def generate_topmap_protobuf_data(s3_bucket,
                                  meeg_raw_file_key,
                                  raw_file_name,
                                  raw_file_id,
                                  topmap_data,
                                  ch_names,
                                  ch_names_map,
                                  channel_name,
                                  channel_pos,
                                  data_type,
                                  device_data,
                                  sfreq,
                                  edf_file):
    # channel postion
    raw_file_name_prefix = raw_file_id
    protobuf_id = '{}_topmap.protobuf'.format(raw_file_name_prefix)
    if not edf_file:
        meeg_topmap_protobuf_raw_file_key = meeg_raw_file_key.replace(raw_file_name, protobuf_id)
    else:
        meeg_topmap_protobuf_raw_file_key = meeg_raw_file_key.replace(
            meeg_raw_file_key.split('/')[-2] + '/' + raw_file_name,
            protobuf_id)

    topmap_data_parts = []
    for i, ch_data in enumerate(zip(channel_name, channel_pos)):
        ch_name = ch_data[0]
        ch_postion = ch_data[1]
        topmap_data.point2Data[ch_name].x = ch_postion[0]
        topmap_data.point2Data[ch_name].y = ch_postion[1]
        if data_type == 'EEG':
            if ch_name == 'T7':
                topmap_data.point2Data['T3'].x = ch_postion[0]
                topmap_data.point2Data['T3'].y = ch_postion[1]
            if ch_name == 'P7':
                topmap_data.point2Data['T5'].x = ch_postion[0]
                topmap_data.point2Data['T5'].y = ch_postion[1]
            if ch_name == 'T8':
                topmap_data.point2Data['T4'].x = ch_postion[0]
                topmap_data.point2Data['T4'].y = ch_postion[1]
            if ch_name == 'P8':
                topmap_data.point2Data['T6'].x = ch_postion[0]
                topmap_data.point2Data['T6'].y = ch_postion[1]
    # standard EEG 10-20 system channel position
    if data_type == 'EEG':
        topmap_data.point2Data['O9'].x = -29.8184000000000
        topmap_data.point2Data['O9'].y = -114.570000000000
        topmap_data.point2Data['O10'].x = 29.7416000000000
        topmap_data.point2Data['O10'].y = -114.260000000000

    for _, map_data in enumerate(zip(ch_names, ch_names_map)):
        raw_name = map_data[0]
        map_name = map_data[1]
        topmap_data.channelRelabels.extend([s3_file_pb2.ChannelRelabel(hostChannel=raw_name, relabel=map_name)])

    topmap_data.sampleFrequency = int(sfreq)

    # Convert to bytes and upload to s3
    top_map_serialized_byte = io.BytesIO(topmap_data.SerializeToString())
    data_size = sys.getsizeof(top_map_serialized_byte)
    current_file_name = '{}_{}.TopMapData.protobufdata'.format(raw_file_name_prefix, data_type)
    current_file_path = os.path.join(meeg_topmap_protobuf_raw_file_key, current_file_name)

    topmap_data_part = copy.deepcopy(device_data)
    topmap_data_part.dataId = str(raw_file_id)
    topmap_data_part.dataName = current_file_name
    topmap_data_part.fileName = current_file_path
    topmap_data_part.dataSize = data_size
    topmap_data_part.dataType = data_type_pb2.DataType.ENERGE_MATRIX

    topmap_data_parts.append(topmap_data_part)

    s3_bucket.upload_fileobj(top_map_serialized_byte, current_file_path)
    return topmap_data_parts


def generate_signal_protobuf_data(s3_bucket,
                                  raw_file_name_prefix,
                                  meeg_uint8_protobuf_raw_file_key,
                                  meeg_original_protobuf_raw_file_key,
                                  meeg_data_ori,
                                  device_data,
                                  raw_file_id,
                                  current_partition_microsecondstimes,
                                  ch_names,
                                  ori_detrend_convert_data,
                                  resample_data,
                                  resample_sfreq,
                                  original_sfreq,
                                  edf_file,
                                  resample_left_padding_data,
                                  resample_right_padding_data,
                                  ori_detrend_left_padding_data,
                                  ori_detrend_right_padding_data,
                                  id):
    # channel single data
    current_file_name = '{}_{:06}.MeegData.protobufdata'.format(raw_file_name_prefix, id)
    # original data info
    meeg_data_ori.currentFileName = current_file_name
    meeg_data_ori.currentStartTimeMicroSeconds = int(current_partition_microsecondstimes[0])
    meeg_data_ori.currentEndTimeMicroSeconds = int(current_partition_microsecondstimes[-1])
    meeg_data_ori.currentPartitionId = id

    original_meeg_data = copy.deepcopy(meeg_data_ori)
    original_meeg_data.sampleFrequency = original_sfreq
    # uint8 data info
    meeg_data = copy.deepcopy(meeg_data_ori)
    meeg_data.sampleFrequency = resample_sfreq

    for ch_id, ch_name in enumerate(ch_names):
        ori_part_single_ch_data = ori_detrend_convert_data[ch_id, :]
        part_single_ch_data = resample_data[ch_id, :]

        if resample_left_padding_data is not None:
            left_padding_data = ori_detrend_left_padding_data[ch_id, :]
            left_padding_byte8_data = convert_byte8([resample_left_padding_data[ch_id, :]])
            meeg_data.leftPaddingByte8[ch_name].CopyFrom(*left_padding_byte8_data)
            original_meeg_data.leftPadding[ch_name].CopyFrom(
                s3_file_pb2.SingleChannelSignal(data=left_padding_data.tolist()))
        if resample_right_padding_data is not None:
            right_padding_data = ori_detrend_right_padding_data[ch_id, :]
            right_padding_byte8_data = convert_byte8([resample_right_padding_data[ch_id, :]])
            meeg_data.rightPaddingByte8[ch_name].CopyFrom(*right_padding_byte8_data)
            original_meeg_data.rightPadding[ch_name].CopyFrom(
                s3_file_pb2.SingleChannelSignal(data=right_padding_data.tolist()))

        original_meeg_data.originalSignalData[ch_name].CopyFrom(
            s3_file_pb2.SingleChannelSignal(data=ori_part_single_ch_data.tolist()))

        part_data_length = len(part_single_ch_data)
        partition_rate = round(part_data_length / max_segment_length)

        if partition_rate > 2:
            re_part_single_ch_data = np.array_split(part_single_ch_data, partition_rate, axis=0)
        else:
            re_part_single_ch_data = [part_single_ch_data]

        segment_byte8 = convert_byte8(re_part_single_ch_data)
        meeg_data.convertedSignalDataByte8[ch_name].CopyFrom(
            s3_file_pb2.SingleChannelSignalByte8(segments=segment_byte8))

    # Convert to bytes and upload to s3
    meeg_part_serialized_byte = io.BytesIO(meeg_data.SerializeToString())
    data_size = sys.getsizeof(meeg_part_serialized_byte)
    current_file_path = os.path.join(meeg_uint8_protobuf_raw_file_key, current_file_name)
    s3_bucket.upload_fileobj(meeg_part_serialized_byte, current_file_path)

    # Convert original data to bytes and upload to s3
    original_meeg_part_serialized_byte = io.BytesIO(original_meeg_data.SerializeToString())
    original_current_file_path = os.path.join(meeg_original_protobuf_raw_file_key, current_file_name)
    s3_bucket.upload_fileobj(original_meeg_part_serialized_byte, original_current_file_path)

    # device data info
    device_data_part = copy.deepcopy(device_data)
    device_data_part.dataId = raw_file_id
    device_data_part.dataName = current_file_name
    device_data_part.fileName = current_file_path
    device_data_part.dataSize = data_size
    device_data_part.partitionStartIndex = int(current_partition_microsecondstimes[0])
    device_data_part.partitionEndIndex = int(current_partition_microsecondstimes[-1])
    if not edf_file:
        device_data_part.dataType = data_type_pb2.DataType.MEG_PROTOBUF
    else:
        device_data_part.dataType = data_type_pb2.DataType.EEG_PROTOBUF
    if id == 0:
        s3_bucket.upload_fileobj(io.BytesIO(), current_file_path.replace(current_file_name, '_LOGIC_PARTITION_SUCCESS'))
    return device_data_part


def get_times_partition(raw_data, ch_names, sfreq_scale_rate, parition_file_size):
    partition_data_num = int((parition_file_size * 1024 * 1024) / (len(ch_names) * 4))

    # TODO: change sfreq_scale_rate to original_sfreq
    if partition_data_num % sfreq_scale_rate != 0:
        partition_data_num = partition_data_num - partition_data_num % sfreq_scale_rate

    if raw_data.n_times // partition_data_num <= 1:
        partition_spilt_times = [raw_data.times]
    else:
        partition_num = raw_data.n_times // partition_data_num  - 1

        last_partition_data_num = raw_data.n_times - partition_num * partition_data_num

        partition_spilt_times = np.array_split(raw_data.times[:-last_partition_data_num], partition_num, axis=0)
        partition_spilt_times.append(raw_data.times[-last_partition_data_num:])
    return partition_spilt_times


def get_resample_sfreq(original_sfreq, resample_fsample):
    sfreq_scale_rate = floor(original_sfreq / resample_fsample)
    print(sfreq_scale_rate)
    if original_sfreq > resample_fsample:
        if original_sfreq % sfreq_scale_rate == 0:
            resample_sfreq = int(original_sfreq / sfreq_scale_rate)
        elif original_sfreq % (sfreq_scale_rate -1) == 0:
            resample_sfreq = int(original_sfreq / (sfreq_scale_rate - 1))
            sfreq_scale_rate = sfreq_scale_rate - 1
        else:
            sfreq_scale_rate = 1
            resample_sfreq = original_sfreq
    else:
        resample_sfreq = original_sfreq
        sfreq_scale_rate = 1

    return resample_sfreq, sfreq_scale_rate


def lambda_meeg_handler(patient_id, patient_folder, meeg_raw_file_key, data_file_format, raw_file_id,
                        is_raw_data_internal, logger):
    job_status = False
    try:
        s3_bucket = config.get_s3_bucket(config.bucket_name)
        logger.info(config.bucket_name)

        if data_file_format == DataFileFormat.EEG_EDF:
            edf_file = True
        else:
            edf_file = False

        if edf_file:
            meeg_originfile_key = meeg_raw_file_key
            raw_file_name = meeg_raw_file_key.split('/')[-1]
            logger.info(meeg_raw_file_key)
        else:
            meeg_originfile_key = meeg_raw_file_key + '/'
            raw_file_name = meeg_raw_file_key.split('/')[-1]
            logger.info(meeg_raw_file_key)

        meeg_data = s3_file_pb2.MeegData()
        device_datas = device_data_pb2.DeviceDataUploadRequest()
        device_data = device_data_pb2.DeviceData()

        if edf_file:
            if is_raw_data_internal == BooleanType.BOOLEAN_TRUE:
                download_path_folder = '{}/{}/'.format(patient_folder, raw_file_id)
                if not os.path.exists(download_path_folder):
                    os.makedirs(download_path_folder)
                download_path = os.path.join(download_path_folder, raw_file_name)
                s3_bucket.download_file(meeg_raw_file_key, download_path)
            else:
                download_path = meeg_raw_file_key
            raw_data = mne.io.read_raw_edf(download_path, preload=False, verbose=False)
        else:
            if is_raw_data_internal == BooleanType.BOOLEAN_TRUE:
                download_path = '{}/{}/{}'.format(patient_folder, raw_file_id, raw_file_name)
                download_s3_folder(s3_bucket, meeg_raw_file_key, download_path)
            else:
                download_path = meeg_raw_file_key
            raw_data = mne.io.read_raw_ctf(download_path, clean_names=True, preload=False, verbose=False)

        original_sfreq = int(raw_data.info['sfreq'])
        ch_names = np.array(raw_data.ch_names)
        chantypes = raw_data.get_channel_types()

        meg_unit = None
        eeg_unit = None

        if not edf_file:
            meg_ix = \
                np.where(
                    (np.array(chantypes) == 'mag') * (~np.isin(np.array(raw_data.ch_names), raw_data.info['bads'])))[
                    0]
            meg_raw_ch_names = np.array(raw_data.ch_names)[meg_ix]
            meg_raw_map_channel_names, meg_layout_channel_pos, meg_layout_channel_name, meg_reference_chnanel_names = get_channel_pos(
                meg_raw_ch_names, 'MEG', edf_file)
            meg_unit = raw_data.info['chs'][meg_ix[0]]['unit']._name

        eeg_ix = \
            np.where((np.array(chantypes) == 'eeg') * (~np.isin(np.array(raw_data.ch_names), raw_data.info['bads'])))[0]
        eeg_raw_ch_names = np.array(raw_data.ch_names)[eeg_ix]

        if len(eeg_raw_ch_names):
            eeg_data = True
            eeg_raw_map_channel_names, eeg_layout_channel_pos, eeg_layout_channel_name, eeg_reference_channel_names = get_channel_pos(
                eeg_raw_ch_names, 'EEG', edf_file)
            eeg_unit = raw_data.info['chs'][eeg_ix[0]]['unit']._name
        else:
            eeg_data = False

        bad_ch = raw_data.info['bads']
        utc_time = raw_data.info['meas_date']
        resample_sfreq, sfreq_scale_rate = get_resample_sfreq(original_sfreq, resample_fsample)
        # real microseconds time stamp
        unix_timestamp = int(utc_time.timestamp()) * 1000 * 1000
        microsecondstimes = raw_data.times * 1000 * 1000 + unix_timestamp

        parition_file_size = int((len(ch_names) * original_sfreq) / (327 * 600) * 8)
        if parition_file_size < 8:
            parition_file_size = 8
        split_times = get_times_partition(raw_data, ch_names, sfreq_scale_rate, parition_file_size)
        partition_length = len(split_times)

        # serialize part data
        device_data.originalFileName = meeg_originfile_key
        device_data.patientId = patient_id
        device_data.description = 'localProcessMeegFiles'

        # raw meeg data info
        meeg_data.rawFileName = raw_file_name
        meeg_data.rawStartTimeMicroSeconds = int(microsecondstimes[0])
        meeg_data.rawEndTimeMicroSeconds = int(microsecondstimes[-1])
        meeg_data.patientId = patient_id
        meeg_data.badChannelNames.extend(bad_ch)
        meeg_data.totalPartitionCount = partition_length

        # meeg channel info
        if not edf_file:
            meeg_data.channelNames['MEG'].CopyFrom(s3_file_pb2.ChannelName(name=meg_raw_ch_names.tolist()))
            if eeg_data:
                meeg_data.channelNames['EEG'].CopyFrom(s3_file_pb2.ChannelName(name=eeg_raw_ch_names.tolist()))
                reference_ch_names = [x for x in ch_names if x not in meg_raw_ch_names and x not in eeg_raw_ch_names]
            else:
                reference_ch_names = [x for x in ch_names if x not in meg_raw_ch_names]

            meeg_data.channelNames['REFERENCE'].CopyFrom(s3_file_pb2.ChannelName(name=reference_ch_names))
        else:
            real_eeg_raw_ch_names = [x for x in eeg_raw_ch_names if x not in eeg_reference_channel_names]
            meeg_data.channelNames['EEG'].CopyFrom(s3_file_pb2.ChannelName(name=real_eeg_raw_ch_names))
            meeg_data.channelNames['REFERENCE'].CopyFrom(
                s3_file_pb2.ChannelName(name=eeg_reference_channel_names.tolist()))

        # top map data
        meg_top_map_data = copy.deepcopy(meeg_data)
        eeg_top_map_data = copy.deepcopy(meeg_data)

        x_parameter = get_coef_param(raw_data)
        global_coef = get_global_coef(raw_data, original_sfreq, x_parameter)

        # process  data
        raw_file_name_prefix = raw_file_id
        uint8_protobuf_id = '{}_uint8.protobuf'.format(raw_file_name_prefix)
        original_protobuf_id = '{}_original.protobuf'.format(raw_file_name_prefix)

        if is_raw_data_internal == BooleanType.BOOLEAN_FALSE:
            if not edf_file:
                meeg_raw_file_key = 'patient/{}/source_data/{}/{}'.format(patient_id, raw_file_name_prefix,
                                                                          raw_file_name)
                meeg_uint8_protobuf_raw_file_key = meeg_raw_file_key.replace(raw_file_name, uint8_protobuf_id)
                meeg_original_protobuf_raw_file_key = meeg_raw_file_key.replace(raw_file_name, original_protobuf_id)
            else:
                meeg_raw_file_key = 'patient/{}/source_data/{}/{}/{}'.format(patient_id, raw_file_name_prefix,
                                                                             raw_file_name.replace('.edf', ''),
                                                                             raw_file_name)
                meeg_uint8_protobuf_raw_file_key = meeg_raw_file_key.replace(
                    meeg_raw_file_key.split('/')[-2] + '/' + raw_file_name,
                    uint8_protobuf_id)
                meeg_original_protobuf_raw_file_key = meeg_raw_file_key.replace(
                    meeg_raw_file_key.split('/')[-2] + '/' + raw_file_name,
                    original_protobuf_id)
        else:

            if not edf_file:
                meeg_uint8_protobuf_raw_file_key = meeg_raw_file_key.replace(raw_file_name, uint8_protobuf_id)
                meeg_original_protobuf_raw_file_key = meeg_raw_file_key.replace(raw_file_name, original_protobuf_id)
            else:
                meeg_uint8_protobuf_raw_file_key = meeg_raw_file_key.replace(
                    meeg_raw_file_key.split('/')[-2] + '/' + raw_file_name,
                    uint8_protobuf_id)
                meeg_original_protobuf_raw_file_key = meeg_raw_file_key.replace(
                    meeg_raw_file_key.split('/')[-2] + '/' + raw_file_name,
                    original_protobuf_id)

        delete_s3_folder(s3_bucket, meeg_uint8_protobuf_raw_file_key)
        delete_s3_folder(s3_bucket, meeg_original_protobuf_raw_file_key)

        device_data_parts = []

        ori_pad_length = int(original_sfreq * max_padding_length)

        previous_detrend_parition_data = None

        for i in range(partition_length):

            if i != partition_length - 1 and partition_length > 1:
                current_partition_raw_data = raw_data.copy().crop(tmin=split_times[i][0], tmax=split_times[i][-1],
                                                                  include_tmax=True)
                next_partition_raw_data = raw_data.copy().crop(tmin=split_times[i + 1][0], tmax=split_times[i + 1][-1],
                                                               include_tmax=True)
            else:

                current_partition_raw_data = raw_data.copy().crop(tmin=split_times[i][0], tmax=split_times[i][-1],
                                                                  include_tmax=True)
                next_partition_raw_data = None

            current_partition_microsecondstimes = split_times[i] * 1000 * 1000 + unix_timestamp
            current_t_param = split_times[i]
            current_x_param = np.float32(np.vstack((np.ones(len(current_t_param)), current_t_param)))
            current_detrend_parition_data = current_partition_raw_data.get_data() - np.dot(global_coef.transpose(),
                                                                                           current_x_param)

            if next_partition_raw_data is not None:
                next_t_param = split_times[i + 1]
                next_x_param = np.float32(np.vstack((np.ones(len(next_t_param)), next_t_param)))
                next_detrend_parition_data = next_partition_raw_data.get_data() - np.dot(global_coef.transpose(),
                                                                                         next_x_param)
                current_ori_right_padding = next_detrend_parition_data[:, :ori_pad_length]
            else:
                current_ori_right_padding = np.empty((current_detrend_parition_data.shape[0], 0))

            if previous_detrend_parition_data is not None:
                current_ori_left_padding = previous_detrend_parition_data[:, -ori_pad_length:]
            else:
                current_ori_left_padding = np.empty((current_detrend_parition_data.shape[0], 0))

            # convert data unit
            ori_detrend_convert_data = convert_data_unit(current_detrend_parition_data, meg_unit, eeg_unit, chantypes)
            current_detrend_padding_parition_data = np.hstack(
                (current_ori_left_padding, current_detrend_parition_data, current_ori_right_padding))

            if resample_sfreq == original_sfreq:
                current_detrend_padding_parition_resample_data = current_detrend_padding_parition_data
            else:
                current_detrend_padding_parition_resample_data = mne.filter.resample(
                    current_detrend_padding_parition_data, 1,
                    original_sfreq / resample_sfreq)

            if i == 0 and i == partition_length - 1:
                resample_left_padding_data = None
                ori_detrend_left_padding_data = None
                resample_right_padding_data = None
                ori_detrend_right_padding_data = None
                resample_data = current_detrend_padding_parition_resample_data
            elif i == 0:
                resample_left_padding_data = None
                ori_detrend_left_padding_data = None
                resample_right_padding_data = current_detrend_padding_parition_resample_data[:, -resample_sfreq:]
                ori_detrend_right_padding_data = convert_data_unit(current_ori_right_padding, meg_unit, eeg_unit,
                                                                   chantypes)
                resample_data = current_detrend_padding_parition_resample_data[:,
                                :current_detrend_padding_parition_resample_data.shape[1] - resample_sfreq]
            elif i == partition_length - 1:
                resample_left_padding_data = current_detrend_padding_parition_resample_data[:, :resample_sfreq]
                ori_detrend_left_padding_data = convert_data_unit(current_ori_left_padding, meg_unit, eeg_unit,
                                                                  chantypes)
                resample_right_padding_data = None
                ori_detrend_right_padding_data = None
                resample_data = current_detrend_padding_parition_resample_data[:, resample_sfreq:]
            else:
                resample_right_padding_data = current_detrend_padding_parition_resample_data[:, -resample_sfreq:]
                ori_detrend_right_padding_data = convert_data_unit(current_ori_right_padding, meg_unit, eeg_unit,
                                                                   chantypes)
                resample_left_padding_data = current_detrend_padding_parition_resample_data[:, :resample_sfreq]
                ori_detrend_left_padding_data = convert_data_unit(current_ori_left_padding, meg_unit, eeg_unit,
                                                                  chantypes)
                resample_data = current_detrend_padding_parition_resample_data[:,
                                resample_sfreq:current_detrend_padding_parition_resample_data.shape[1] - resample_sfreq]

            data_parts = generate_signal_protobuf_data(s3_bucket,
                                                       raw_file_name_prefix,
                                                       meeg_uint8_protobuf_raw_file_key,
                                                       meeg_original_protobuf_raw_file_key,
                                                       meeg_data,
                                                       device_data,
                                                       raw_file_id,
                                                       current_partition_microsecondstimes,
                                                       ch_names,
                                                       ori_detrend_convert_data,
                                                       resample_data,
                                                       resample_sfreq,
                                                       original_sfreq,
                                                       edf_file,
                                                       resample_left_padding_data,
                                                       resample_right_padding_data,
                                                       ori_detrend_left_padding_data,
                                                       ori_detrend_right_padding_data,
                                                       i)
            device_data_parts.append(data_parts)
            previous_detrend_parition_data = current_detrend_parition_data

        # meeg topmap data info
        if not edf_file:
            meg_top_map_data_parts = generate_topmap_protobuf_data(s3_bucket,
                                                                   meeg_raw_file_key,
                                                                   raw_file_name,
                                                                   raw_file_id,
                                                                   meg_top_map_data,
                                                                   meg_raw_ch_names,
                                                                   meg_raw_map_channel_names,
                                                                   meg_layout_channel_name,
                                                                   meg_layout_channel_pos,
                                                                   'MEG',
                                                                   device_data,
                                                                   resample_sfreq,
                                                                   edf_file)
            device_datas.deviceData.extend(meg_top_map_data_parts)
        if eeg_data:
            eeg_top_map_data_parts = generate_topmap_protobuf_data(s3_bucket,
                                                                   meeg_raw_file_key,
                                                                   raw_file_name,
                                                                   raw_file_id,
                                                                   eeg_top_map_data,
                                                                   eeg_raw_ch_names,
                                                                   eeg_raw_map_channel_names,
                                                                   eeg_layout_channel_name,
                                                                   eeg_layout_channel_pos,
                                                                   'EEG',
                                                                   device_data,
                                                                   resample_sfreq,
                                                                   edf_file)
            device_datas.deviceData.extend(eeg_top_map_data_parts)
        device_datas.deviceData.extend(device_data_parts)
        logger.info(device_datas)

        job_status = True
        message = f'meeg protobuf data upload to s3 success'
    except Exception as e:
        logger.info(e)
        message = f'mri protobuf data upload to s3 failed, error: {str(e)}'
        return message, job_status, None
    if is_raw_data_internal == BooleanType.BOOLEAN_TRUE:
        if os.path.isdir(download_path):
            shutil.rmtree(download_path)
        else:
            os.remove(download_path)
    return message, job_status, device_datas
