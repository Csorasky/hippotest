import os
import shutil
import re
import copy

from hippo.proto.hippo.web import device_data_pb2
from hippo.proto.hippo.common import data_type_pb2
from hippo.proto.hippo.common.data_type_pb2 import DataFileFormat
from hippo.proto.hippo.common.common_pb2 import BooleanType
from hippo.proto.hippo.web.hospital_pb2 import EegSystem
from hippo.comm import config
import subprocess
import struct
import uuid
from datetime import datetime, timedelta


def download_s3_folder(bucket, s3_folder, local_dir=None):
    """
    Download the contents of a folder directory
    Args:
        bucket_name: the name of the s3 bucket
        s3_folder: the folder path in the s3 bucket
        local_dir: a relative or absolute directory path in the local file system
    """
    for obj in bucket.objects.filter(Prefix=s3_folder):
        target = obj.key if local_dir is None \
            else os.path.join(local_dir, os.path.relpath(obj.key, s3_folder))
        if not os.path.exists(os.path.dirname(target)):
            os.makedirs(os.path.dirname(target), exist_ok=True)
        if obj.key[-1] == '/':
            continue
        bucket.download_file(obj.key, target)


def parse_vtc_file_with_alignment(file_path):
    # Open the binary file
    with open(file_path, 'rb') as file:
        # Read and unpack the header data
        header_format = '<16sI'  # Little-endian byte order, 16-byte GUID followed by a 4-byte LONG_Schema
        header_size = struct.calcsize(header_format)
        header_data = file.read(header_size)
        guid_header, schema_version = struct.unpack(header_format, header_data)

        # Convert bytes to GUID for the header
        guid_header = str(uuid.UUID(bytes_le=guid_header))

        print(f"Header GUID: {guid_header}")
        print(f"Schema Version: {schema_version}")

        # Now let's attempt to read the VtcRecords according to the provided structure
        record_format = '<261s16sQQ'  # Little-endian byte order
        record_size = struct.calcsize(record_format)

        # Read the rest of the file
        records_data = file.read()  # Read all the data at once to handle alignment in parsing manually

        # Initialize cursor to the first byte of the first record
        cursor = 0
        records = []

        # Loop to parse each VtcRecord
        while cursor < len(records_data):
            # Unpack the record
            end_of_record = cursor + record_size
            record_data = records_data[cursor:end_of_record]
            filename_bytes, location_guid_bytes, start_time, end_time = struct.unpack(record_format, record_data)

            # Check if we have a complete record
            if len(record_data) < record_size:
                print("Incomplete record encountered at the end of the file.")
                break

            # Decode and strip null characters from the filename
            filename_str = filename_bytes.rstrip(b'\x00').decode('latin1')

            # Convert the GUID bytes to a UUID object
            location_guid = str(uuid.UUID(bytes_le=location_guid_bytes))

            # Convert the FILETIME values to datetime objects
            start_time_dt = filetime_to_dt(start_time)
            end_time_dt = filetime_to_dt(end_time)

            # Append the record to the list
            records.append({
                'STRING_MpgFileName': filename_str,
                'GUID_Location': location_guid,
                'FILETIME_StartTime': start_time_dt,
                'FILETIME_EndTime': end_time_dt
            })

            # Move the cursor to the next record, adhering to the 1-byte boundary
            cursor = end_of_record

        return records


# Function to convert Windows FILETIME to UTC datetime
def filetime_to_dt(ft):
    """
    Converts a Microsoft FILETIME into a datetime.
    The FILETIME is a 64-bit value representing the number of 100-nanosecond intervals since January 1, 1601 (UTC).
    """
    # Get the number of seconds and remaining nanoseconds from the filetime
    seconds, ns = divmod(ft, 10 ** 7)
    # Create a datetime object from the seconds
    dt = datetime(1601, 1, 1) + timedelta(seconds=seconds, microseconds=ns / 10)
    return dt


def generate_video_protobuf_data(video_records, download_path, raw_file_id, meeg_raw_file_key, raw_file_name,
                                 s3_bucket, device_data, patient_folder):
    """
    Generate the video protobuf data, and upload the convert h264 video files to the s3 bucket
    """
    device_data_parts = []
    for i, video_record in enumerate(video_records):
        video_file_name = video_record['STRING_MpgFileName']
        start_time = video_record['FILETIME_StartTime']
        end_time = video_record['FILETIME_EndTime']
        start_time_stamp = int(start_time.timestamp()) * 1000 * 1000
        end_time_stamp = int(end_time.timestamp()) * 1000 * 1000

        video_file_path = os.path.join(download_path, video_file_name)
        if not os.path.exists(video_file_path):
            continue
        convert_video_path = os.path.join(patient_folder, '{}_{:06}'.format(raw_file_id, i) + '.mp4')
        # convert the video file to h264 mp4 format
        results = subprocess.check_output(
            ['ffmpeg', '-y', '-i', video_file_path, '-c:v', 'libx264',
             '-strict', '2', '-vcodec', 'copy', convert_video_path],
            stderr=subprocess.STDOUT).decode('utf-8')
        match = re.search(r'Stream .* Video: .* (\d+)x(\d+).* (\d+)\s*fps', results)
        if match:
            width, height, fps = match.groups()
            if os.path.exists(convert_video_path):
                data_name = '{}_{:06}'.format(raw_file_id, i) + '.mp4'
                s3_convert_video_file_path = os.path.join(
                    meeg_raw_file_key.replace(raw_file_name, 'convert_video_{}x{}_{}fps'.format(width, height, fps)),
                    data_name)

                s3_bucket.upload_file(convert_video_path, s3_convert_video_file_path)
                device_data_part = copy.deepcopy(device_data)
                device_data_part.dataId = raw_file_id
                device_data_part.dataName = data_name
                device_data_part.fileName = s3_convert_video_file_path
                device_data_part.dataSize = os.path.getsize(convert_video_path)
                device_data_part.partitionStartIndex = start_time_stamp
                device_data_part.partitionEndIndex = end_time_stamp
                device_data_part.dataType = data_type_pb2.DataType.EEG_VIDEO
                device_data_parts.append(device_data_part)

    return device_data_parts


def lambda_video_handler(patient_id, patient_folder, meeg_raw_file_key, data_file_format, raw_file_id,
                         is_raw_data_internal, eeg_system, logger):
    job_status = False
    try:
        assert data_file_format == DataFileFormat.EEG_NATUS_RAW
        s3_bucket = config.get_s3_bucket(config.bucket_name)
        logger.info(config.bucket_name)
        if is_raw_data_internal == BooleanType.BOOLEAN_TRUE:
            meeg_originfile_key = meeg_raw_file_key + '/'
        else:
            meeg_originfile_key = 'patient/{}/source_data/{}/'.format(patient_id, raw_file_id)
        raw_file_name = meeg_raw_file_key.split('/')[-1]
        logger.info(meeg_raw_file_key)

        device_datas = device_data_pb2.DeviceDataUploadRequest()
        device_data = device_data_pb2.DeviceData()

        if is_raw_data_internal == BooleanType.BOOLEAN_TRUE:
            download_path = '{}/{}/{}'.format(patient_folder, raw_file_id, raw_file_name)
            download_s3_folder(s3_bucket, meeg_raw_file_key, download_path)
        elif eeg_system == EegSystem.NATUS:
            download_path = meeg_raw_file_key
        else:
            download_path = meeg_raw_file_key

        natus_files = os.listdir(download_path)
        vtc_file = None
        for natus_file in natus_files:
            if natus_file.endswith('.vtc') and not natus_file.startswith('.'):
                vtc_file_name = natus_file
                vtc_file = '{}/{}'.format(download_path, vtc_file_name)
                device_data.containsVideo = BooleanType.BOOLEAN_TRUE

        # serialize part data
        device_data.originalFileName = meeg_originfile_key
        device_data.patientId = patient_id
        device_data.description = 'localProcessNatusFiles'

        if vtc_file is not None:
            # read the video file and get information
            video_records = parse_vtc_file_with_alignment(vtc_file)
            # generate the video protobuf data
            video_data_parts = generate_video_protobuf_data(video_records,
                                                            download_path,
                                                            raw_file_id,
                                                            meeg_raw_file_key,
                                                            raw_file_name,
                                                            s3_bucket,
                                                            device_data,
                                                            patient_folder)
            device_datas.deviceData.extend(video_data_parts)

        logger.info(device_datas)
        job_status = True
        message = f'natus eeg protobuf data upload to s3 success'
    except Exception as e:
        logger.info(e)
        message = f'natus eeg protobuf data upload to s3 failed, error: {str(e)}'
        return message, job_status, None
    if is_raw_data_internal == BooleanType.BOOLEAN_TRUE:
        if os.path.isdir(download_path):
            shutil.rmtree(download_path)
        else:
            os.remove(download_path)
    return message, job_status, device_datas
