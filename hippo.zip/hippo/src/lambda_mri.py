import copy
import os
import shutil
import io
import subprocess
import sys
import json
import requests
import zipfile
from datetime import datetime

path_to_conform_function = '/opt/fastsurfer/FastSurferCNN/data_loader/'
path_to_FastSurfer = '/opt/fastsurfer/'
sys.path.append(path_to_conform_function)
sys.path.append(path_to_FastSurfer)
from conform import *
from hippo.proto.hippo.common import s3_file_pb2
from hippo.proto.hippo.common import data_type_pb2
from hippo.proto.hippo.web import device_data_pb2
from hippo.comm import config
from hippo.proto.hippo.common.data_type_pb2 import DataFileFormat
from hippo.proto.hippo.common.common_pb2 import BooleanType
from hippo.proto.hippo.web.hospital_pb2 import ImageSystem

chunk_size = 4 * 1024 * 1024


def download_s3_folder(bucket, s3_folder, local_dir=None):
    """
    Download the contents of a folder directory
    Args:
        bucket_name: the name of the s3 bucket
        s3_folder: the folder path in the s3 bucket
        local_dir: a relative or absolute directory path in the local file system
    """
    for obj in bucket.objects.filter(Prefix=s3_folder):
        target = obj.key if local_dir is None \
            else os.path.join(local_dir, os.path.relpath(obj.key, s3_folder))
        if not os.path.exists(os.path.dirname(target)):
            os.makedirs(os.path.dirname(target), exist_ok=True)
        if obj.key[-1] == '/':
            continue
        bucket.download_file(obj.key, target)


def get_mri_raw_file_key(bucket, folder_path):
    mri_raw_file_key = None
    for obj in bucket.objects.filter(Prefix=folder_path):
        if obj.key != os.path.join(folder_path, '__MRI_NIFTI1_SUCCESS__'):
            mri_raw_file_key = obj.key
        if obj.key[-1] == '/':
            continue
    return mri_raw_file_key


def delete_s3_folder(bucket, s3_folder):
    objects = bucket.objects.filter(Prefix=s3_folder)
    for obj in objects:
        obj.delete()


def generate_mri_protobuf_data(nii_file, s3_bucket, patient_id, raw_file_name, raw_file_id,
                               mri_raw_file_key, mri_data, device_data, tranforms,
                               data_storage_type, dimension_index, data_type):
    # set the protobuf id and delete the old protobuf file
    # the numeric data type and {}x{}x{} dimention is just for the front end to parse the data
    mri_dimention = mri_data.shape
    covert_data = False
    if data_storage_type == s3_file_pb2.MRI_DATA_STORAGE_INT8:
        covert_data = True
        numeric_data_type = 'uint8'
        covert_data_type = s3_file_pb2.MRI_DATA_STORAGE_UINT8
    else:
        numeric_data_type = s3_file_pb2.MriDataStorageType.Name(data_storage_type).split('_')[-1].lower()
        covert_data_type = data_storage_type

    raw_file_name_prefix = '{}_{}_{}x{}x{}_{}_dim{}'.format(raw_file_id, data_type, mri_dimention[0], mri_dimention[1],
                                                            mri_dimention[2], numeric_data_type, dimension_index)
    protobuf_id = '{}.protobuf'.format(raw_file_name_prefix)
    if nii_file:
        mri_protobuf_raw_file_key = mri_raw_file_key.replace(mri_raw_file_key.split('/')[-2] + '/' + raw_file_name,
                                                             protobuf_id)
    else:
        mri_protobuf_raw_file_key = mri_raw_file_key.replace(raw_file_name, protobuf_id)
    delete_s3_folder(s3_bucket, mri_protobuf_raw_file_key)

    # generate the protobuf data by the dimension index
    device_data_parts = []
    parts_anatomy_data, parts_index_list, num_parts, dimension_pattern = get_mri_data_part(mri_data, dimension_index)
    mri_transforms = tranforms.astype(float).flatten().tolist()

    for i, part_anatomy_data in enumerate(parts_anatomy_data):
        if covert_data:
            part_mri_anatomy_data = (part_anatomy_data + 128).astype(np.int32).flatten().tolist()
        else:
            part_mri_anatomy_data = part_anatomy_data.astype(np.int32).flatten().tolist()

        current_start_index = parts_index_list[i][0]
        current_end_index = parts_index_list[i][-1]

        mri_serialized = s3_file_pb2.MriData(data32=part_mri_anatomy_data,
                                             dataDimensionSize1=mri_dimention[0],
                                             dataDimensionSize2=mri_dimention[1],
                                             dataDimensionSize3=mri_dimention[2],
                                             dataTransform=mri_transforms,
                                             transformDimensionSize1=tranforms.shape[0],
                                             transformDimensionSize2=tranforms.shape[1],
                                             rawFileName=raw_file_name,
                                             patientId=patient_id,
                                             partitionDimension=dimension_pattern,
                                             currentPartitionId=i,
                                             totalPartitionCount=num_parts,
                                             partitionStartIndex=current_start_index,
                                             partitionEndIndex=current_end_index,
                                             mriDataStorageType=covert_data_type)
        mri_serialized_byte = io.BytesIO(mri_serialized.SerializeToString())
        data_size = sys.getsizeof(mri_serialized_byte)

        current_file_name = '{}_{:06}.MriData.protobufdata'.format(raw_file_name_prefix, i)
        current_file_path = os.path.join(mri_protobuf_raw_file_key, current_file_name)
        s3_bucket.upload_fileobj(mri_serialized_byte, current_file_path)
        # device data info for the partition
        device_data_partition = copy.deepcopy(device_data)
        device_data_partition.dataId = raw_file_id
        device_data_partition.dataName = current_file_name
        device_data_partition.fileName = current_file_path
        device_data_partition.dataSize = data_size
        device_data_partition.partitionStartIndex = current_start_index
        device_data_partition.partitionEndIndex = current_end_index
        device_data_partition.dataPartitionPattern = dimension_pattern
        device_data_parts.append(device_data_partition)
    # upload the success file
    s3_bucket.upload_fileobj(io.BytesIO(), current_file_path.replace(current_file_name, '_BINARY_PARTITION_SUCCESS'))
    return device_data_parts


def get_ras_data(data, ori_nii_path):
    if max(data.shape) > 256:
        data.set_data_dtype(np.int8)
        ori_nii_gz_path = ori_nii_path + '.gz'
        nib.save(data, ori_nii_gz_path)
        int8_data = nib.load(ori_nii_gz_path)
        ras_data = nib.as_closest_canonical(int8_data)
        data_storage_type = s3_file_pb2.MRI_DATA_STORAGE_INT8
    else:
        ras_data = nib.as_closest_canonical(data)
        if min(ras_data.get_fdata().flatten()) < 0:
            data_storage_type = s3_file_pb2.MRI_DATA_STORAGE_INT32
        else:
            data_storage_type = s3_file_pb2.MRI_DATA_STORAGE_UINT32
    return ras_data, data_storage_type


def get_conform_data(data):
    data_resliced = conform(data)
    conform_ras_data = nib.as_closest_canonical(data_resliced)
    conform_data_storage_type = s3_file_pb2.MRI_DATA_STORAGE_UINT8
    return conform_ras_data, conform_data_storage_type


def get_mri_data_part(mri_data, dimension_index):
    dimension_pattern = s3_file_pb2.DATA_PARTITION_PATTERN_NULL
    if dimension_index == 0:
        part_size = chunk_size / (mri_data.shape[1] * mri_data.shape[2])
        dimension_pattern = s3_file_pb2.DATA_PARTITION_PATTERN_DIMENSION_1
    elif dimension_index == 1:
        part_size = chunk_size / (mri_data.shape[0] * mri_data.shape[2])
        dimension_pattern = s3_file_pb2.DATA_PARTITION_PATTERN_DIMENSION_2
    elif dimension_index == 2:
        part_size = chunk_size / (mri_data.shape[0] * mri_data.shape[1])
        dimension_pattern = s3_file_pb2.DATA_PARTITION_PATTERN_DIMENSION_3

    num_parts = round(mri_data.shape[dimension_index] / part_size)

    if num_parts < 1:
        num_parts = 1
    index_list = [i for i in range(mri_data.shape[dimension_index])]
    parts_index_list = np.array_split(index_list, num_parts)
    parts_anatomy_data = np.array_split(mri_data, num_parts, axis=dimension_index)
    return parts_anatomy_data, parts_index_list, num_parts, dimension_pattern


def lambda_mri_handler(patient_id, patient_folder, mri_raw_file_key, data_file_format, raw_file_id,
                       is_raw_data_internal, image_system, download_id, token, logger):
    job_status = False
    try:
        # set s3 bucket
        s3_bucket = config.get_s3_bucket(config.bucket_name)

        # indicate whether the file is nii file
        if data_file_format == DataFileFormat.MRI_NIFTI1:
            nii_file = True
        else:
            nii_file = False

        # get mri raw file key adn raw file name
        # TODO: get the raw file name from the AIR system URL
        if nii_file:
            raw_file_name = mri_raw_file_key.split('/')[-1]
        elif image_system == ImageSystem.AIR:
            raw_file_name = 'air_{}'.format(raw_file_id)
            mri_original_file_key = 'patient/{}/source_data/{}/'.format(patient_id, raw_file_id)
        else:
            mri_original_file_key = mri_raw_file_key + '/'
            raw_file_name = mri_raw_file_key.split('/')[-1]
        logger.info(mri_raw_file_key)

        if not nii_file:
            if is_raw_data_internal == BooleanType.BOOLEAN_TRUE:
                download_path = '{}/{}/{}'.format(patient_folder, raw_file_id, raw_file_name)
                download_s3_folder(s3_bucket, mri_raw_file_key, download_path)
            elif image_system == ImageSystem.AIR:
                headers = {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer ' + token,
                    'Connection': 'keep-alive'
                }
                data = {
                    'downloadId': download_id
                }
                response = requests.post(config.air_url, headers=headers, json=data)
                if response.status_code == 200:
                    blob = response.content
                else:
                    logger.info('request failed :', response.status_code)
                air_zip_path = '{}/{}.zip'.format(patient_folder, raw_file_name)
                with open(air_zip_path, 'wb') as f:
                    f.write(blob)
                extract_path = '{}/{}/{}'.format(patient_folder, raw_file_id, raw_file_name)
                with zipfile.ZipFile(air_zip_path, 'r') as zip_ref:
                    zip_ref.extractall(extract_path)
                zip_folder_name_sub = os.listdir(extract_path)
                zip_folder_name = os.listdir(os.path.join(extract_path, zip_folder_name_sub[0]))
                download_path = os.path.join(extract_path, zip_folder_name_sub[0], zip_folder_name[0])
            else:
                # local folder
                download_path = mri_raw_file_key
        else:
            if is_raw_data_internal == BooleanType.BOOLEAN_TRUE:
                download_path_folder = '{}/{}'.format(patient_folder, raw_file_id)
                if not os.path.exists(download_path_folder):
                    os.makedirs(download_path_folder)
                download_path = os.path.join(download_path_folder, raw_file_name)
                s3_bucket.download_file(mri_raw_file_key, download_path)
            else:
                # local file
                download_path = mri_raw_file_key

        # set basic DeviceData info
        device_datas = device_data_pb2.DeviceDataUploadRequest()
        device_data = device_data_pb2.DeviceData()

        # generate mri data and mri conform data
        convert_path = None
        ras_data = None
        conform_ras_data = None
        if nii_file:
            data = nib.load(download_path)
            ras_data, data_storage_type = get_ras_data(data, download_path)
            if max(data.shape) > 256:
                conform_ras_data, conform_data_storage_type = get_conform_data(data)
        else:
            convert_path = '{}/{}/{}_niix'.format(patient_folder, raw_file_id, raw_file_name)
            if not os.path.exists(convert_path):
                os.makedirs(convert_path)
            subprocess.call(['dcm2niix', '-ba', 'n', '-o', convert_path, download_path])
            print(os.listdir(convert_path))
            nii_files = os.listdir(convert_path)
            for file in nii_files:
                if file.endswith('.json'):
                    fp = open(os.path.join(convert_path, file), 'rb')
                    json_data = json.load(fp)
                    acquisition_date_time = json_data.get('AcquisitionDateTime')
                    if acquisition_date_time:
                        timestamp_str = acquisition_date_time.replace('T', ' ')
                    else:
                        timestamp_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
                    datetime_obj = datetime.strptime(timestamp_str, "%Y-%m-%d %H:%M:%S.%f")
                    timestamp = int(datetime_obj.timestamp()) * 1000 * 1000
                    device_data.hardwareDataTime = timestamp
                if file.endswith('.nii'):
                    ori_nii_gz_path = os.path.join(convert_path, file)
                    # upload ori_nii_gz_path to s3 for surface model generation
                    if is_raw_data_internal == BooleanType.BOOLEAN_TRUE:
                        s3_bucket.upload_file(ori_nii_gz_path, '{}.nii'.format(mri_raw_file_key))
                    else:
                        mri_upload_file_key = 'patient/{}/source_data/{}/{}'.format(patient_id, raw_file_id,
                                                                                    raw_file_name)
                        s3_bucket.upload_file(ori_nii_gz_path, '{}.nii'.format(mri_upload_file_key))
                    data = nib.load(ori_nii_gz_path)
                    ras_data, data_storage_type = get_ras_data(data, ori_nii_gz_path)
                    if max(data.shape) > 256:
                        conform_ras_data, conform_data_storage_type = get_conform_data(data)

        device_data.originalFileName = mri_raw_file_key if nii_file else mri_original_file_key
        device_data.patientId = patient_id
        device_data.dataType = data_type_pb2.DataType.MRI_T1_PROTOBUF
        device_data.description = 'localProcessMriFiles'

        if is_raw_data_internal == BooleanType.BOOLEAN_FALSE:
            if nii_file:
                mri_raw_file_key = 'patient/{}/source_data/{}/{}/{}'.format(patient_id, raw_file_id,
                                                                            raw_file_name.replace('.nii', ''),
                                                                            raw_file_name)
            else:
                mri_raw_file_key = 'patient/{}/source_data/{}/{}'.format(patient_id, raw_file_id, raw_file_name)

        # set dimension index, if mri data shape is larger than 256, dimension_index = 0,1,2
        dimension_index = 0

        # generate mri protobuf data and upload to s3
        if conform_ras_data is not None:
            data_type = 'norm'
            conform_mri_data = conform_ras_data.get_fdata()
            conform_tranforms = conform_ras_data.affine
            device_data_nomalized = copy.deepcopy(device_datas)
            device_data_parts_nomalized = generate_mri_protobuf_data(nii_file,
                                                                     s3_bucket,
                                                                     patient_id,
                                                                     raw_file_name,
                                                                     raw_file_id,
                                                                     mri_raw_file_key,
                                                                     conform_mri_data,
                                                                     device_data,
                                                                     conform_tranforms,
                                                                     conform_data_storage_type,
                                                                     dimension_index,
                                                                     data_type)

            device_data_nomalized.deviceData.extend(device_data_parts_nomalized)
            final_device_data = device_data_nomalized
        # generate mri original protobuf data and upload to s3, if mri data shape is smaller than 256,
        # then do not normalize the mri data. original mri data is the same as conformed mri data.
        if ras_data is not None:
            if max(ras_data.shape) <= 256:
                data_type = 'norm'
                mri_data = ras_data.get_fdata()
                tranforms = ras_data.affine
                device_data_ras = copy.deepcopy(device_datas)
                device_data_parts_ras = generate_mri_protobuf_data(nii_file,
                                                                   s3_bucket,
                                                                   patient_id,
                                                                   raw_file_name,
                                                                   raw_file_id,
                                                                   mri_raw_file_key,
                                                                   mri_data,
                                                                   device_data,
                                                                   tranforms,
                                                                   data_storage_type,
                                                                   dimension_index,
                                                                   data_type)

                device_data_ras.deviceData.extend(device_data_parts_ras)
                if conform_ras_data is not None:
                    device_data_nomalized.deviceData.extend(device_data_parts_ras)
                    final_device_data = device_data_nomalized
                else:
                    final_device_data = device_data_ras
            else:
                data_type = 'origin'
                mri_ori_data = ras_data.dataobj.get_unscaled()
                ori_tranforms = ras_data.affine
                device_data_ori_ras = copy.deepcopy(device_datas)
                device_data_parts_ori_ras = generate_mri_protobuf_data(nii_file,
                                                                       s3_bucket,
                                                                       patient_id,
                                                                       raw_file_name,
                                                                       raw_file_id,
                                                                       mri_raw_file_key,
                                                                       mri_ori_data,
                                                                       device_data,
                                                                       ori_tranforms,
                                                                       data_storage_type,
                                                                       dimension_index,
                                                                       data_type)

                device_data_ori_ras.deviceData.extend(device_data_parts_ori_ras)
                if conform_ras_data is not None:
                    device_data_nomalized.deviceData.extend(device_data_parts_ori_ras)
                    final_device_data = device_data_nomalized
                else:
                    final_device_data = device_data_ori_ras
        logger.info(final_device_data)
        job_status = True
        message = f'mri protobuf data upload to s3 successfully'
    except Exception as e:
        logger.info(e)
        message = f'mri protobuf data upload to s3 failed, error: {str(e)}'
        return message, job_status, None
    if is_raw_data_internal == BooleanType.BOOLEAN_TRUE:
        if os.path.isdir(download_path):
            shutil.rmtree(download_path)
        else:
            os.remove(download_path)
    if convert_path is not None:
        shutil.rmtree(convert_path)

    return message, job_status, final_device_data
