import requests
import os


def s3Upload(file, s3_file, s3_bucket, logger=None):
    try:
        s3_bucket.upload_fileobj(file, s3_file)
        message = " Upload Proto File Successful"
        if logger is not None:
            logger.info(message)
        return message, True
    except Exception as e:
        message = str(e)
        if logger is not None:
            logger.info(message)
        return message, False


def s3Upload_file(file, s3_file, s3_bucket, logger=None):
    try:
        s3_bucket.upload_file(file, s3_file)
        message = " Upload File Successful"
        if logger is not None:
            logger.info(message)
        return message, True
    except Exception as e:
        message = str(e)
        if logger is not None:
            logger.info(message)
        return message, False


def s3Download(local_file, s3_file, s3_bucket, logger=None):
    try:
        s3_bucket.download_file(s3_file, local_file)
        message = "Download Origin File Successful"
        if logger is not None:
            logger.info(message)
        return message, True
    except Exception as e:
        message = str(e)
        if logger is not None:
            logger.info(message)
        return message, False


def download_s3_folder(folder_name, local_directory, s3_bucket):
    for obj in s3_bucket.objects.filter(Prefix=folder_name):
        target = obj.key if local_directory is None \
            else os.path.join(local_directory, os.path.relpath(obj.key, folder_name))
        if not os.path.exists(os.path.dirname(target)):
            os.makedirs(os.path.dirname(target), exist_ok=True)
        if obj.key[-1] == '/':
            continue
        s3_bucket.download_file(obj.key, target)


def ListFiles(s3_folder_key, s3_bucket):
    """List files in specific S3 URL"""
    files = []
    for obj in s3_bucket.objects.filter(Prefix=s3_folder_key):
        files.append(obj.key)
    return files


def callback_backend(device_datas, backend_api, bucket, logger=None):
    if bucket == 'hippoclinic':
        service_callback_url = 'http://www.hippoclinic.com.cn'
    elif bucket == 'hippoclinic-staging':
        service_callback_url = 'https://www.hippoclinic.com'
    else:
        service_callback_url = 'http://hippoclinic.ucsf.edu'
    callback_api = service_callback_url + backend_api
    try:
        headers = {'content-type': "application/x-protobuf"}
        x = requests.post(callback_api, data=device_datas.SerializeToString(), headers=headers)
        logger.info('Callback backend: ' + str(x))
    except Exception as e:
        if logger is not None:
            logger.info('Failed to callback backend: ' + str(e))
