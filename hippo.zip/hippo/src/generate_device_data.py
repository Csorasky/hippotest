import numpy as np
from hippo.src.natus_raw_file_scaner import scan_natus_files, scan_natus_files_test
from hippo.proto.hippo.web import device_data_pb2
from hippo.proto.third_party import natus_pb2
from hippo.src.s3_files import callback_backend
from hippo.comm import config
import copy


def generate_natus_device_data(natus_root_path, logger):
    """generate natus device data message

    Args:
        natus_files (list): The list of natus file info
    Returns:
        job status (bool): The status of job
    """
    mrn_natus_raw_data_list = natus_pb2.MrnNatusRawDataList()
    mrn_natus_raw_data = natus_pb2.MrnNatusRawData()
    mrn_natus_device_data = device_data_pb2.DeviceData()

    # scan natus files
    try:
        natus_files = scan_natus_files_test(natus_root_path, logger)
        # natus_files = scan_natus_files(natus_root_path, logger)
        logger.info(f"Scan natus files: {natus_files}")
    except Exception as e:
        logger.info(f"Failed to scan natus files: {e}")
        return False

    natus_raw_data_list = []
    for natus_file in natus_files:
        natus_device_data = copy.deepcopy(mrn_natus_device_data)
        natus_raw_data = copy.deepcopy(mrn_natus_raw_data)
        for upload_data_path, data_name, data_size, create_time, study_name, campus, eeg_type in zip(
                natus_file['DataPath'],
                natus_file['DataName'],
                natus_file['DataSize'],
                natus_file['CreateTime'],
                natus_file['StudyName'],
                natus_file['Campus'],
                natus_file['EEGType']
                ):
            natus_device_data.uploadDataPath = upload_data_path
            natus_device_data.dataName = study_name
            natus_device_data.uploadDataName = data_name
            natus_device_data.dataSize = data_size
            natus_device_data.hardwareDataTime = create_time
            natus_device_data.studyName = study_name
            natus_device_data.campus = campus
            natus_device_data.eegType = eeg_type
            natus_raw_data.natusData.append(natus_device_data)
        natus_raw_data.mrn = natus_file['MRN']
        natus_raw_data.name = natus_file['PatientName'][0]
        natus_raw_data_list.append(natus_raw_data)

    # partition natus raw data
    partition_number = np.round(len(natus_raw_data_list) / config.call_batch_size)
    if partition_number < 1:
        partition_number = 1
    split_natus_raw_data_list = np.array_split(np.array(natus_raw_data_list), partition_number, axis=0)

    # send natus raw data to backend, one batch each time
    for split_natus_raw_data in split_natus_raw_data_list:
        mrn_natus_raw_data_list_copy = copy.deepcopy(mrn_natus_raw_data_list)
        mrn_natus_raw_data_list_copy.mrnNatusRawDataList.extend(split_natus_raw_data.tolist())
        mrn_natus_raw_data_list_copy.hospitalId = config.natus_hospital_id
        callback_backend(mrn_natus_raw_data_list_copy, config.natus_callback_api, config.bucket_name)
        logger.info(f"Send natus device data to backend successfully !")

    return True
