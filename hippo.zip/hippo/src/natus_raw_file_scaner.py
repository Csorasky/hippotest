import os
import pathlib
from nwreader.snc_reader import SyncFile
from nwreader.eeg_reader import read_eeg_file
from hippo.comm.config import natus_sub_folder_suffix, natus_sub_folder_prefix
from datetime import datetime


def get_folder_size(folder_path):
    total_size = 0
    for file_path in pathlib.Path(folder_path).rglob("*"):
        if file_path.is_file():
            total_size += file_path.stat().st_size

    return total_size


def merge_data(data):
    merged_data = {}
    for item in data:
        mrn = item["MRN"]
        data_name = item["DataName"]
        data_path = item["DataPath"]
        data_size = item["DataSize"]
        create_time = item["CreateTime"]
        patient_name = item["PatientName"]
        study_name = item["StudyName"]
        campus = item["Campus"]
        eeg_type = item["EEGType"]

        if mrn not in merged_data:
            merged_data[mrn] = {"MRN": mrn, "DataName": [data_name], "DataPath": [data_path],
                                "CreateTime": [create_time], "StudyName": [study_name], "Campus": [campus],
                                "PatientName": [patient_name], "DataSize": [data_size], "EEGType": [eeg_type]}
        else:
            merged_data[mrn]["DataName"].append(data_name)
            merged_data[mrn]["DataPath"].append(data_path)
            merged_data[mrn]["CreateTime"].append(create_time)
            merged_data[mrn]["PatientName"].append(patient_name)
            merged_data[mrn]["DataSize"].append(data_size)
            merged_data[mrn]["StudyName"].append(study_name)
            merged_data[mrn]["Campus"].append(campus)
            merged_data[mrn]["EEGType"].append(eeg_type)

    unique_data = list(merged_data.values())
    return unique_data


def scan_natus_files(natus_root_path, logger):
    """scan natus file folder and create protobufdata

    Args:
        natus_root_path (str): The folder path includes natus file
    Returns:
        natus_files (list): The list of natus file info
    """

    natus_file_info = {
        'MRN': '',
        'DataName': '',
        'DataPath': '',
        'DataSize': 0,
        'CreateTime': '',
        'PatientName': '',
        'StudyName': '',
        'Campus': '',
        'EEGType': ''
    }
    natus_files_list = []


    scaner_count = 0
    natus_sub_folder_list = os.listdir(natus_root_path)
    for natus_sub_folder in natus_sub_folder_list:
        if not natus_sub_folder.startswith(tuple(natus_sub_folder_prefix)):
            continue
        db_folder_list = os.listdir(os.path.join(natus_root_path, natus_sub_folder))
        for db_folder in db_folder_list:
            if db_folder not in natus_sub_folder_suffix:
                continue
            natus_file_list = os.listdir(os.path.join(natus_root_path, natus_sub_folder, db_folder))

            total_natus_files = len(natus_file_list)
            logger.info('total natus files {} in {}'.format(total_natus_files, natus_sub_folder))
            for i, natus_file in enumerate(natus_file_list):
                natus_file_path = os.path.join(natus_root_path, natus_sub_folder, db_folder, natus_file)
                logger.info('scan natus file path: {}/{}--{} '.format(i, total_natus_files, natus_file_path))
                natus_file_size = get_folder_size(natus_file_path)
                snc_file_path = os.path.join(natus_file_path, natus_file + '.snc')
                eeg_file_path = os.path.join(natus_file_path, natus_file + '.eeg')
                if not os.path.exists(eeg_file_path) or not os.path.exists(snc_file_path):
                    logger.info('eeg or snc file not exist')
                    continue
                snc_f = open(snc_file_path, 'rb')
                # get a sync file ready
                sync_file = SyncFile.from_file(snc_f)
                # read patient/study info
                eeg_file = read_eeg_file(eeg_file_path, sync_file=sync_file, verbose=False)

                # get patient/study info
                try:
                    study_name = eeg_file['Study'][0]['StudyName']
                except (KeyError, IndexError):
                    study_name = " "
                try:
                    mrn = eeg_file['Study'][0]['CustomFields']['Values'].get('MRN', " ")
                    campus = eeg_file['Study'][0]['CustomFields']['Values'].get('CAMPUS', " ")
                    eeg_type = eeg_file['Study'][0]['CustomFields']['Values'].get('EEG TYPE', " ")
                    creation_time = eeg_file['Study'][0].get('XLCreationTime', "")

                    first_name = eeg_file['Info']['Name'].get('FirstName', " ")
                    last_name = eeg_file['Info']['Name'].get('LastName', " ")
                    middle_name = eeg_file['Info']['Name'].get('MiddleName', " ")
                    patient_name = "{} {} {}".format(first_name, middle_name, last_name)
                except:
                    logger.info('error in parsing natus file {}'.format(natus_file_path))
                    continue

                # create natus file info
                natus_file_info['DataPath'] = natus_file_path
                natus_file_info['DataSize'] = natus_file_size
                natus_file_info['DataName'] = natus_file
                natus_file_info['CreateTime'] = int(
                    datetime.strptime(creation_time, "%Y-%m-%d %H:%M:%S.%f%z").timestamp()) * 1000 * 1000
                natus_file_info['MRN'] = mrn
                natus_file_info['PatientName'] = patient_name.rstrip().lstrip()
                natus_file_info['StudyName'] = study_name
                natus_file_info['Campus'] = campus
                natus_file_info['EEGType'] = eeg_type
                natus_files_list.append(natus_file_info.copy())
                snc_f.close()
                scaner_count += 1
                if scaner_count == 500:
                    logger.info('scaned {} natus files, program termination execution !'.format(scaner_count))
                    unique_natus_files_list = merge_data(natus_files_list)
                    return unique_natus_files_list
    unique_natus_files_list = merge_data(natus_files_list)
    return unique_natus_files_list


def scan_natus_files_test(natus_root_path, logger):
    """scan natus file folder and create protobufdata

    Args:
        natus_root_path (str): The folder path includes natus file
    Returns:
        natus_files (list): The list of natus file info
    """

    natus_file_info = {
        'MRN': '',
        'DataName': '',
        'DataPath': '',
        'DataSize': 0,
        'CreateTime': '',
        'PatientName': '',
        'StudyName': '',
        'Campus': '',
        'EEGType': ''
    }
    natus_files_list = []

    scaner_count = 0
    natus_folder = os.path.join(natus_root_path, natus_sub_folder_suffix)
    natus_file_list = os.listdir(natus_folder)
    total_natus_files = len(natus_file_list)
    logger.info('total natus files {} in {}'.format(total_natus_files, natus_sub_folder_suffix))
    for i, natus_file in enumerate(natus_file_list):
        natus_file_path = os.path.join(natus_root_path, natus_sub_folder_suffix, natus_file)
        logger.info('scan natus file path: {}/{}--{} '.format(i, total_natus_files, natus_file_path))
        natus_file_size = get_folder_size(natus_file_path)
        snc_file_path = os.path.join(natus_file_path, natus_file + '.snc')
        eeg_file_path = os.path.join(natus_file_path, natus_file + '.eeg')
        if not os.path.exists(eeg_file_path) or not os.path.exists(snc_file_path):
            logger.info('eeg or snc file not exist')
            continue
        snc_f = open(snc_file_path, 'rb')
        # get a sync file ready
        sync_file = SyncFile.from_file(snc_f)
        # read patient/study info
        eeg_file = read_eeg_file(eeg_file_path, sync_file=sync_file, verbose=False)

        # get patient/study info
        try:
            study_name = eeg_file['Study'][0]['StudyName']
        except (KeyError, IndexError):
            study_name = " "
        try:
            mrn = eeg_file['Study'][0]['CustomFields']['Values'].get('MRN', " ")
            campus = eeg_file['Study'][0]['CustomFields']['Values'].get('CAMPUS', " ")
            eeg_type = eeg_file['Study'][0]['CustomFields']['Values'].get('EEG TYPE', " ")
            creation_time = eeg_file['Study'][0].get('XLCreationTime', "")

            first_name = eeg_file['Info']['Name'].get('FirstName', " ")
            last_name = eeg_file['Info']['Name'].get('LastName', " ")
            middle_name = eeg_file['Info']['Name'].get('MiddleName', " ")
            patient_name = "{} {} {}".format(first_name, middle_name, last_name)
        except:
            logger.info('error in parsing natus file {}'.format(natus_file_path))
            continue

        # create natus file info
        natus_file_info['DataPath'] = natus_file_path
        natus_file_info['DataSize'] = natus_file_size
        natus_file_info['DataName'] = natus_file
        natus_file_info['CreateTime'] = int(
            datetime.strptime(creation_time, "%Y-%m-%d %H:%M:%S.%f%z").timestamp()) * 1000 * 1000
        natus_file_info['MRN'] = mrn
        natus_file_info['PatientName'] = patient_name.rstrip().lstrip()
        natus_file_info['StudyName'] = study_name
        natus_file_info['Campus'] = campus
        natus_file_info['EEGType'] = eeg_type
        natus_files_list.append(natus_file_info.copy())
        snc_f.close()
        scaner_count += 1
        if scaner_count == 500:
            logger.info('scaned {} natus files, program termination execution !'.format(scaner_count))
            unique_natus_files_list = merge_data(natus_files_list)
            return unique_natus_files_list
    unique_natus_files_list = merge_data(natus_files_list)
    return unique_natus_files_list