// RawDataReaderDlg.cpp : implementation file
//

#include "stdafx.h"
#include "RawDataReader.h"
#include "RawDataReaderDlg.h"
#include "FHeader.h"
#include "TocFile.h"
#include "DataProducer.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRawDataReaderDlg dialog

CRawDataReaderDlg::CRawDataReaderDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CRawDataReaderDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CRawDataReaderDlg)
	m_file_name = _T("No file selected");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CRawDataReaderDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRawDataReaderDlg)
	DDX_Control(pDX, IDC_PROCESS, m_process_button);
	DDX_Text(pDX, IDC_FILE_NAME, m_file_name);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CRawDataReaderDlg, CDialog)
	//{{AFX_MSG_MAP(CRawDataReaderDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_OPEN, OnOpen)
	ON_BN_CLICKED(IDC_PROCESS, OnProcess)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRawDataReaderDlg message handlers

BOOL CRawDataReaderDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CRawDataReaderDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CRawDataReaderDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CRawDataReaderDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CRawDataReaderDlg::OnOpen() 
{
	CString	patdir;

	m_process_button.EnableWindow(FALSE);
	m_file_name = _T("No file selected");
	UpdateData(FALSE);
	// prompt the user (with all document templates)
	if (!SelectDataFileName(m_file_name, IDS_SELECT_FILE, OFN_FILEMUSTEXIST))
		return; // open cancelled

	m_process_button.EnableWindow(TRUE);
	UpdateData(FALSE);
}

bool CRawDataReaderDlg::SelectDataFileName(CString& fileName, UINT nIDSTitle, DWORD lFlags)
{
	CFileDialog dlgFile(TRUE);

	CString title;
	VERIFY(title.LoadString(nIDSTitle));

	dlgFile.m_ofn.Flags |= lFlags;

	CString strFilter = "Data files (*.erd)";
	strFilter += (TCHAR)'\0';
	strFilter += (TCHAR)'*';
	strFilter += _T("*.erd");
	strFilter += (TCHAR)'\0';  
	dlgFile.m_ofn.nMaxCustFilter++;
	
	dlgFile.m_ofn.lpstrFilter = strFilter;
	dlgFile.m_ofn.lpstrTitle = title;

	dlgFile.m_ofn.nFilterIndex = 0;

	int nResult = dlgFile.DoModal();
	fileName.ReleaseBuffer();

	if(nResult != IDOK)
		return false;

	m_file_name = dlgFile.GetPathName();
	return true;
}

void CRawDataReaderDlg::OnProcess() 
{
	CWaitCursor wait_cursor;
	TCHAR src_drive[_MAX_DRIVE], src_path[_MAX_PATH], file_name[_MAX_FNAME], file_ext[_MAX_EXT];
	_tsplitpath(m_file_name, src_drive, src_path, file_name, file_ext);
	CString toc_name = CString(src_drive) + CString(src_path) + CString(file_name) + CString(".etc");
	CTocHeader toc_header;
	CTocFile toc_file(toc_header);
	// open selected TOC file
	if (toc_file.Open((LPCTSTR)toc_name, 0, NULL) == FALSE)
	{
		AfxMessageBox(_T("Failed to open table of contents file"));
		return;
	}
	// open selected data file
	CRawDataHeader raw_header;
	CEegFile data_file(raw_header);
	if (data_file.Open((LPCTSTR)m_file_name, 0, NULL) == FALSE)
	{
		AfxMessageBox(_T("Failed to open data file"));
		return;
	}
	// create and initialize data producer object
	std::auto_ptr<CDataProducer> pDataProducer;
	CRawDataHeader	*rdh = STATIC_DOWNCAST(CRawDataHeader, data_file.m_header);
	// create Data producer object. Based on a file schema VariableDeltaReader or ConstantDeltaReader will be created
	pDataProducer = std::auto_ptr<CDataProducer>(CDataProducer::CreateDataProducer(rdh->m_file_schema,rdh->m_num_channels,data_file.GetHeaderLen()));
	pDataProducer->InitNewDataFile(&data_file);
	int	*phys_chan;		// Storage to physical channel assignments.
	phys_chan = new int[rdh->m_num_channels];
	memcpy(phys_chan, rdh->m_phys_chan, rdh->m_num_channels * sizeof(int));
	pDataProducer->Init(rdh->m_num_channels,rdh->m_deltabits,phys_chan,rdh->m_discardbits);
	
	// find first toc entry
	TOC_ENTRY te = toc_file.FindTocEntry(-1);
	bool is_absolute = true;
	RAW_DATA cur_data;
	RAW_DATA last_data;
	CStdioFile m_file;
	if(!m_file.Open(_T("DateReaderLog.log"),CFile::modeCreate | CFile::modeWrite | CFile::shareDenyNone | CFile::typeText,NULL))
	{
		MessageBox(_T("Unable to open log file"), _T("Error"), MB_ICONSTOP | MB_OK);
		return;
	}
	// iterate through file toc entry at a time
	do
	{
		// position file pointer at the current entry offset
		data_file.Seek(te.offset,CFile::begin);
		// every seek into data file requires Reset of a corresponding DataProducer object
		pDataProducer->Reset();
		long sample_stamp = te.samplestamp;
		for(int sample = 0; sample < te.sample_span; sample++)
		{
			cur_data.m_hdr.m_samplestamp = sample_stamp;
			// read data 1 sample at a time
			if(pDataProducer->ReadData(&data_file,&cur_data,&last_data,is_absolute) == EFILE_END)
			{
				break;
			}
			// at this point cur_data contains requested time slice of data and can be accessed through 
			// cur_data.m_chan[].
			CStringA s;
			s.Format("%d\t%i\n",cur_data.m_chan[0],cur_data.m_hdr.m_samplestamp);
			m_file.Write(s,s.GetLength());
			last_data = cur_data;
			sample_stamp++;
		}	
	}while(toc_file.NextTocEntry(&te));

	delete[] phys_chan;
		
	toc_file.Close();
	data_file.Close();
	m_file.Close();
}
