/**********************************************************************************************************
*					Copyright (C) 1997 Excel Tech Ltd. All rights reserved.
*
* FILE:				FHeader.h
*
* CREATION DATE:	May 29, 1997
*
* AUTHOR:			Ron K.
*
* DESCRIPTION:		Interface of the CHeader class.
*
* REVISION INFORMATION:
*
* $Header: /Branches/Main/EEGWorks/Source/EegCommon/FHeader.h 23    4/29/04 12:15p Rwaddell $
*
**********************************************************************************************************/

#if !defined(FHEADER_H)
#define FHEADER_H

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "Eeg.h"

#define BASE_FILE_SCHEMA				1

#define GENERIC_FILE_SCHEMA				3
#define OLD_FORMAT_RAW_DATA_HEADER		7
#define RAW_DATA_FILE_SCHEMA_DEFAULT	9
#define RAW_DATA_FILE_SCHEMA			9
#define TOC_FILE_SCHEMA					3
#define NOTE_FILE_SCHEMA				3
#define VIDEO_FILE_SCHEMA				1
#define SYNC_FILE_SCHEMA				1
#define STC_FILE_SCHEMA					1

#define FHEADER_NAME_STR_LEN			80
#define FHEADER_VERSION_STR_LEN			10
#define FHEADER_MAX_STORE_CHANNELS		1024

#pragma pack(push, 1)

class CHeader : public CObject
{
	DECLARE_SERIAL(CHeader)

public:
	CHeader();
	CHeader(const CHeader &hdr);
	virtual const CHeader &operator=(const CHeader &hdr);
	virtual void Serialize(CArchive &ar);

	static GUID		m_GenericFileGuid;

	// File Header Data
	GUID			m_file_guid;			// The GUID defining the type of this file.

	WORD			m_file_schema;			// Schema number of the file, used to identify version changes.
	WORD			m_base_schema;			// The schema number of the base header (CHeader).

	__time32_t		m_creation_time;		// In UTC format.
	long			m_patient_id;			// Database record patient id.
	long			m_study_id;				// Database record study id.

	TCHAR			m_pat_last_name[FHEADER_NAME_STR_LEN];	// Patient identification fields.
	TCHAR			m_pat_first_name[FHEADER_NAME_STR_LEN];
	TCHAR			m_pat_middle_name[FHEADER_NAME_STR_LEN];
	TCHAR			m_pat_id[FHEADER_NAME_STR_LEN];
};

class CRawDataHeader : public CHeader
{
	DECLARE_SERIAL(CRawDataHeader)

public:
	CRawDataHeader();
	virtual const CRawDataHeader &operator=(const CRawDataHeader &hdr);
	virtual const CHeader &operator=(const CHeader &hdr);
	virtual void Serialize(CArchive &ar);

	static GUID		m_RawDataFileGuid;

	// Raw Header Data
	double			m_sample_freq;		// [Hz]
	int				m_num_channels;		// Number of channels stored.
	int				m_deltabits;		// Number of bits of delta information stored per channel.
	int				m_headbox_type[MAX_NUM_HEADBOXES];		// Type of the headbox.
	int				m_headbox_sn[MAX_NUM_HEADBOXES];			// Headbox serial number.
	char			m_headbox_sw_version[MAX_NUM_HEADBOXES][FHEADER_VERSION_STR_LEN];			// Headbox software version number: (major_rev.minor_rev).
	char			m_dsp_hw_version[FHEADER_VERSION_STR_LEN];		// The DSP board hardware version number.
	char			m_dsp_sw_version[FHEADER_VERSION_STR_LEN];		// The DSP software version number.
	int				m_phys_chan[FHEADER_MAX_STORE_CHANNELS];		// Storage to physical channel assignments.
	int				m_discardbits;		// Number of least significant bits to discard when storing.
};

class CTocHeader : public CHeader
{
	DECLARE_SERIAL(CTocHeader)

public:
	CTocHeader();
	virtual void Serialize(CArchive &ar);

	static GUID		m_TocFileGuid;
};

#pragma pack(pop)

#endif

/**********************************************************************************************************					
*	End of $Source: G:/Projects/Eeg/Storage/rcs/FHeader.h $
**********************************************************************************************************/
