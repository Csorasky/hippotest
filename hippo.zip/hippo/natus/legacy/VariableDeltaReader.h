// VariableDeltaReader.h: interface for the CVariableDeltaReader class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_VARIABLEDELTAREADER_H__125242E6_F68C_47E6_B1A5_0B8DDAB4A161__INCLUDED_)
#define AFX_VARIABLEDELTAREADER_H__125242E6_F68C_47E6_B1A5_0B8DDAB4A161__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "DataProducer.h"
#include "math.h"

#define BYTE_LOOKUP	256

class INTERPOLATION_DATA
{
public:
	INTERPOLATION_DATA()
	{
		Reset();
	}

	enum INTERPOLATION_STATUS
	{
		NOT_USED = 0,
		INITIALIZING,
		INITIALIZED 
	};

	inline void Reset()
	{
		m_old = LONG_MIN;
		m_new = LONG_MIN;
		m_inuse = NOT_USED;
		m_freq = SHRT_MAX;
	}

	inline bool IsInitialized() const
	{
		return (m_inuse == INITIALIZED);
	}

	inline void SetChanFreq(short freq)
	{
		if(m_freq != freq && freq != 0)
		{
			Reset();	// discard history
			m_freq = freq;
		}
	}

	inline long GetLastValue() const
	{
		ASSERT(m_inuse == INITIALIZED);
		return m_new;
	}

	inline bool IsVariableFreq() const
	{
		return (m_freq != SHRT_MAX);
	}

	inline short GetChanFreq() const
	{
		return m_freq;
	}

	inline bool IsDataToBeSkipped(short step) const
	{
		return (step%m_freq != 0);
	}

	inline void RecalculateInterpolationData(short step, long val)
	{
		m_old = GetInterpolatedData(m_new,m_freq - (step%m_freq));
		m_new = val;
	}

/**********************************************************************************************************
* FUNCTION:		PopulateInterpolationData() 
* AUTHOR:		GSHULKIN
* CLASS:		INTERPOLATION_DATA
* DESCRIPTION:  Populates internal data needed for interpolation of the channel recorded with frequency
*				lower than the HB sampling frequency
**********************************************************************************************************/
	void PopulateInterpolationData(long data)
	{
		switch(m_inuse)
		{
			case NOT_USED:	// populate old value
				m_old = data;
				m_inuse = INITIALIZING;
				break;
			case INITIALIZING:
				m_new = data;	// populate new value
				m_inuse = INITIALIZED;
				break;
			case INITIALIZED:
				m_old = m_new;	//replace old with new and new with given value 
				m_new = data;
				break;
			default:	// shouldn't have happened
				ASSERT(false);
		}
	}

/**********************************************************************************************************
* FUNCTION:		GetInterpolatedData() 
* AUTHOR:		GSHULKIN
* CLASS:		INTERPOLATION_DATA
* DESCRIPTION:  Calculates non-existent data using interpolation
**********************************************************************************************************/
	long GetInterpolatedData(long default_data,long step) const
	{
		ASSERT(m_freq != SHRT_MAX);

		if(!IsInitialized() || !IsVariableFreq())
		{
			return default_data;
		}

		if(m_new == RAW_SAMPLE_OVERFLOW_SHIFTED || m_new == RAW_SAMPLE_OVERFLOW ||
		   m_old == RAW_SAMPLE_OVERFLOW_SHIFTED || m_old == RAW_SAMPLE_OVERFLOW)
		{	// in case of special values don't interpolate
			return m_new;
		}
		else
		{	
			if(m_freq == 0)
			{	// prevent potential division by zero
				ASSERT(false && _T("Attempt to divide by zero"));
				return default_data;
			}
			// interpolate
			return (long)ceil(m_old + (((step%m_freq)) * ((double)(m_new - m_old) / (double)m_freq)));
		}
	}

private:
	long m_old;	// old historic value
	long m_new; // latest historic value
	short m_freq;	// channel frequency
	INTERPOLATION_STATUS m_inuse;	// initialized or not
};

class CVariableDeltaReader : public CDataProducer  
{
public:
	CVariableDeltaReader(){
		m_header_len = 0;
		InitializeShortedMask();

		m_variable_freq = FALSE;
		m_freq_byte = 0;
	};
	CVariableDeltaReader(int num_store_channels){
		m_num_store_channels = num_store_channels;
		InitializeShortedMask();
		
		m_variable_freq = FALSE;
		m_freq_byte = 0;
	};

	static BYTE	m_lookup_array[];
	static BYTE m_lookup_mask[];
	
	virtual EReadResult ReadData(CEegFile *data_file, RAW_DATA* raw, RAW_DATA* last_raw, bool& is_absolute);
	virtual void SetHeaderLen(ULONGLONG header_len)
	{
		m_header_len = header_len;
	}

	virtual void InitNewDataFile(CEegFile *data_file);

	virtual void CopyHeaderInfo(CEegFile *dest_file);

protected:

	virtual void SetDeltaMask()
	{
		m_mask_length = (int)ceil(m_num_store_channels / 8.);
	}

	void ConstructLookUpTable()
	{
		for (int i = 0; i < BYTE_LOOKUP; i++)
		{
			m_lookup_array[i] = 0;
		}
	}

	virtual void CreateShortedMask()
	{
		InitializeShortedMask();
	}

	virtual void SetFixedDeltaLength(){}
	void InitializeShortedMask();

	EReadResult ReadConstantFreqData(CEegFile *data_file, RAW_DATA* raw, RAW_DATA* last_raw, bool& is_absolute);
	EReadResult ReadVariableFreqData(CEegFile *data_file, RAW_DATA* raw, RAW_DATA* last_raw, bool& is_absolute);

	BYTE  m_inverted_shorted_mask[MAX_SHORTED_LENGTH];	
	ULONGLONG  m_header_len;
	INTERPOLATION_DATA m_interpolation_data[FHEADER_MAX_STORE_CHANNELS];
	BOOL  m_variable_freq;
	BYTE  m_freq_byte;
	EDelta m_is_abs[MAX_NUM_CHANNELS];
};

#endif // !defined(AFX_VARIABLEDELTAREADER_H__125242E6_F68C_47E6_B1A5_0B8DDAB4A161__INCLUDED_)
