// ConstantDeltaReader.h: interface for the CConstantDeltaReader class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CONSTANTDELTAREADER_H__BB767A97_94E1_4F34_BFA8_D105AF7DA974__INCLUDED_)
#define AFX_CONSTANTDELTAREADER_H__BB767A97_94E1_4F34_BFA8_D105AF7DA974__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "DataProducer.h"
#define MAX_DELTABITS			8		// number of bits of delta information stored per channel.
#define MAX_FIXEDDELTA_LENGTH			((int)(MAX_NUM_CHANNELS * MAX_DELTABITS / 8. + 0.5))

class CConstantDeltaReader : public CDataProducer  
{
public:
	virtual EReadResult ReadData(CEegFile *data_file, RAW_DATA* raw, RAW_DATA* last_raw, bool& is_absolute);
	virtual void SetHeaderLen(ULONGLONG /*header_len*/){ }
	virtual void InitNewDataFile(CEegFile* /*data_file*/){ }
	virtual void CopyHeaderInfo(CEegFile* /*dest_file*/){ }

protected:

	BYTE ReadDelta(BYTE deltas[MAX_FIXEDDELTA_LENGTH], int chan);
	virtual void SetFixedDeltaLength()
	{
		m_deltas_len = (int)(m_num_store_channels * m_deltabits / 8. + 0.5);
		m_abs_delta = (short)(1 << (m_deltabits - 1));
	}
	virtual void SetDeltaMask(){}
	virtual void CreateShortedMask(){}

	int m_deltas_len;
	BYTE m_dec_deltas[MAX_NUM_CHANNELS];

};

#endif // !defined(AFX_CONSTANTDELTAREADER_H__BB767A97_94E1_4F34_BFA8_D105AF7DA974__INCLUDED_)
