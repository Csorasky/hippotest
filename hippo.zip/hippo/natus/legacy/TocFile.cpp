// TocFile.cpp: implementation of the CTocFile class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TocFile.h"
#define CRITICAL_SECTION_TYPE CCriticalSection

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTocFile::CTocFile(const CTocHeader &header) :
	CEegFile(header),
	m_nStartSampleNumber(0),
	m_nStartSampleNumberInFile(-1)
{
}

CTocFile::~CTocFile()
{
}

/**********************************************************************************************************
*
* FUNCTION:		ReadTocEntry() 
*
* AUTHOR:		Ron K.
*
* CLASS:		CTocFile
*
* DESCRIPTION:  Reads a toc entry from the toc file at
*	the current file position.
*	Returns the number of bytes read.
*
* LIMITATIONS:
*
* REVISION HISTORY:
*	Date		Comment
*	20020108	V.A. Offset all sample numbers by an offset that we receive from STC file
*
**********************************************************************************************************/

UINT CTocFile::ReadTocEntry(TOC_ENTRY *te)
{
	UINT			n;

	ULONGLONG first_pos = Seek(0, CFile::current); // V.A. seems to be preventing Read from catching exception
	n = Read(te, sizeof(TOC_ENTRY));
	if (n == 0)
	{
		te->samplestamp = -1;
		te->sample_num = 0;
		return n;
	}
	ASSERT(n == sizeof(TOC_ENTRY));

	if (first_pos == (UINT)this->GetHeaderLen()){
		m_nStartSampleNumberInFile = te->sample_num;
	}

	// V.A. Add starting sample number from STC file
	te->sample_num += m_nStartSampleNumber;
	if (m_nStartSampleNumberInFile != -1)
		te->sample_num -= m_nStartSampleNumberInFile;

	if (m_header->m_file_schema <= 2)
	{	// Convert timestamp to samplestamp.
		te->samplestamp /= 2;
	}

	return n;
}

/**********************************************************************************************************
*
* FUNCTION:		FindTocEntry() 
*
* AUTHOR:		Ron K.
*
* CLASS:		CTocFile
*
* DESCRIPTION:  Find the toc entry with the greatest sample stamp that is less than or equal to the given stamp 's'.
*	The toc file position is set to just after the found entry.
*	Toc entries are written every MAX_CHUNK_SAMPLES samples, and whenever there is a discontinuity in
*	the samplestamps of the data. (Discontinuities occur whenever recording is stopped, or if data is lost.)
*	If no data was recorded then there will be no toc entries. In that case
*	return a toc entry with a samplestamp of -1.
*
*
* LIMITATIONS:
*
* REVISION HISTORY:
*	Date		Comment
*
**********************************************************************************************************/

TOC_ENTRY CTocFile::FindTocEntry(int s)
{
	TOC_ENTRY		mid_te, lower_te, upper_te;
	ULONGLONG		lower_pos, upper_pos, mid_pos, first_pos;
	UINT			n;

	first_pos = lower_pos = GetHeaderLen();
	Seek(GetHeaderLen(), CFile::begin);
	n = ReadTocEntry(&lower_te);
	if (n == 0)
	{
		lower_te.samplestamp = -1;
		lower_te.sample_num = 0;
		return lower_te;
	}

	ASSERT(n == sizeof(TOC_ENTRY));
	if (s <= lower_te.samplestamp)
		return lower_te;

	ULONGLONG offset = GetLength() - (int)sizeof(TOC_ENTRY);
//	upper_pos = Seek(- (int)sizeof(TOC_ENTRY), CFile::end);
	upper_pos = Seek(offset, CFile::begin);
	ASSERT(upper_pos == (UINT)offset);
	n = ReadTocEntry(&upper_te);
	ASSERT(n == sizeof(TOC_ENTRY));
	if (s >= upper_te.samplestamp)
		return upper_te;

	// Somewhere between the lower and upper limits.
	// Do a binary search.
	for (;;)
	{
		mid_pos = first_pos + ((upper_pos + lower_pos - 2 * first_pos) / sizeof(TOC_ENTRY) / 2) * sizeof(TOC_ENTRY);

		if (mid_pos == lower_pos)
		{
			Seek(lower_pos + sizeof(TOC_ENTRY), CFile::begin);
			return lower_te;
		}

		Seek(mid_pos, CFile::begin);
		n = ReadTocEntry(&mid_te);
		ASSERT(n == sizeof(TOC_ENTRY));
	
		if (mid_te.samplestamp == s)
			return mid_te;

		if (s > mid_te.samplestamp)
		{
			lower_te = mid_te;
			lower_pos = mid_pos;
		}
		else
		{
			upper_te = mid_te;
			upper_pos = mid_pos;
		}
	}
}

/**********************************************************************************************************
*
* FUNCTION:		NextTocEntry() 
*
* AUTHOR:		Ron K.
*
* CLASS:		CTocFile
*
* DESCRIPTION:  Get the next toc entry.
*	Return TRUE on success, FALSE if at the end of the file.
*	On an error, te->samplestamp is -1.
*
* LIMITATIONS:
*
* REVISION HISTORY:
*	Date		Comment
*
**********************************************************************************************************/

BOOL CTocFile::NextTocEntry(TOC_ENTRY *te)
{
	UINT			n;
	TOC_ENTRY		next;

	
	n = ReadTocEntry(&next);
	if (n == 0)
	{
		if (te != NULL)
		{
			te->samplestamp = -1;
			te->sample_num = LONG_MAX;
		}
		return FALSE;
	}

	ASSERT(n == sizeof(TOC_ENTRY));
	if (te != NULL) *te = next;
	return TRUE;
}

/**********************************************************************************************************
*
* FUNCTION:		PrevTocEntry() 
*
* AUTHOR:		Ron K.
*
* CLASS:		CTocFile
*
* DESCRIPTION:  Get the previous toc entry.
*	Return TRUE on success, FALSE if at the start of the file.
*	On an error, te->samplestamp is -1.
*
* LIMITATIONS:
*
* REVISION HISTORY:
*	Date		Comment
*
**********************************************************************************************************/

BOOL CTocFile::PrevTocEntry(TOC_ENTRY *te)
{
	ULONGLONG	pos;

	pos = GetPosition();
	if (pos < GetHeaderLen() + 2 * (int)sizeof(TOC_ENTRY))
	{
		if (te != NULL)
		{
			te->samplestamp = -1;
			te->sample_num = LONG_MAX;
		}
		return FALSE;
	}

	if (te == NULL)
		Seek(-(int)sizeof(TOC_ENTRY), CFile::current);
	else
	{
		Seek(-2 * (int)sizeof(TOC_ENTRY), CFile::current);
		ReadTocEntry(te);
	}

	return TRUE;
}

/**********************************************************************************************************
*
* FUNCTION:		FindSampleStamp() 
*
* AUTHOR:		Ron K.
*
* CLASS:		CTocFile
*
* DESCRIPTION:  Find the sample stamp associated with a given sample number.
*	Samples are numbered sequentially starting at 0.
*	Returns the found sample stamp. If the sample number is less than 0 or there
*	is no data in the file, return LONG_MIN. If the sample number is greater than the total 
*	number of samples in the file, the return LONG_MAX.
*
* LIMITATIONS:
*
* REVISION HISTORY:
*	Date		Comment
*
**********************************************************************************************************/

long CTocFile::FindSampleStamp(int sampnum)
{
	TOC_ENTRY		mid_te, lower_te, upper_te;
	ULONGLONG		lower_pos, upper_pos, mid_pos, first_pos;
	UINT			n;

	first_pos = lower_pos = GetHeaderLen();
	Seek(GetHeaderLen(), CFile::begin);
	n = ReadTocEntry(&lower_te);
	if (n == 0)
	{
		return LONG_MIN;		// No toc entries in the file.
	}

	ASSERT(n == sizeof(TOC_ENTRY));
	if (sampnum < lower_te.sample_num)
		return LONG_MIN;

	ULONGLONG offset = GetLength() - (int)sizeof(TOC_ENTRY);
//	upper_pos = Seek(- (int)sizeof(TOC_ENTRY), CFile::end);
	upper_pos = Seek(offset, CFile::begin);
	ASSERT(upper_pos == (UINT)offset);
	n = ReadTocEntry(&upper_te);
	ASSERT(n == sizeof(TOC_ENTRY));
	if (sampnum >= upper_te.sample_num + upper_te.sample_span)
		return LONG_MAX;
	if (sampnum >= upper_te.sample_num)
		return upper_te.samplestamp + (sampnum - upper_te.sample_num);

	// Somewhere between the lower and upper limits.
	// Do a binary search.
	for (;;)
	{
		mid_pos = first_pos + ((upper_pos + lower_pos - 2 * first_pos) / sizeof(TOC_ENTRY) / 2) * sizeof(TOC_ENTRY);

		if (mid_pos == lower_pos)
		{
			Seek(lower_pos + sizeof(TOC_ENTRY), CFile::begin);
			return lower_te.samplestamp + (sampnum - lower_te.sample_num);
		}

		Seek(mid_pos, CFile::begin);
		n = ReadTocEntry(&mid_te);
		ASSERT(n == sizeof(TOC_ENTRY));
	
		if (mid_te.sample_num == sampnum)
			return mid_te.samplestamp;

		if (sampnum > mid_te.sample_num)
		{
			lower_te = mid_te;
			lower_pos = mid_pos;
		}
		else
		{
			upper_te = mid_te;
			upper_pos = mid_pos;
		}
	}
}

/**********************************************************************************************************
*
* FUNCTION:		SampNumToStamp()
*
* AUTHOR:		Ron K.
*
* CLASS:		CTocFile
*
* DESCRIPTION:  Finds the sample stamp corresponding to the
*	given sample number. If the sample number is <= 0 return the first stamp.
*	If the sample number is > number of samples in file return the last stamp.
*
* LIMITATIONS:
*
* REVISION HISTORY:
*	Date		Comment
*
**********************************************************************************************************/

int CTocFile::SampNumToStamp(int samp_num)
{
	int				samp_stamp;
	ULONGLONG       pos;
	UINT			n;
	TOC_ENTRY		lower_te, upper_te;

	// Record the current toc file position.
	pos = GetPosition();

	samp_stamp = FindSampleStamp(samp_num);

	if (samp_stamp == LONG_MIN)
	{	// samp_num is before the start of study.
		lower_te = FindTocEntry(-1);
		if (lower_te.samplestamp == -1)
			return 0; //throw MAKE_ETL_EXCEPTION(NWSTORAGE_NO_DATA_RECORDED);
		else 
			samp_stamp = lower_te.samplestamp;
	}
	else if (samp_stamp == LONG_MAX)
	{	// samp_num is beyond the end of the study.
		ULONGLONG offset = GetLength() - (int)sizeof(TOC_ENTRY);
//		UINT upper_pos = Seek(- (int)sizeof(TOC_ENTRY), CFile::end);
		ULONGLONG upper_pos = Seek(offset, CFile::begin);
		ASSERT(upper_pos == (UINT)offset);
		n = ReadTocEntry(&upper_te);
		ASSERT(n == sizeof(TOC_ENTRY));
		samp_stamp = upper_te.samplestamp + upper_te.sample_span - 1;
	}

	// Return the toc file to the original position.
	Seek(pos, CFile::begin);
	return samp_stamp;
}

/**********************************************************************************************************
*
* FUNCTION:		GetNumTocEntries()
*
* AUTHOR:		Ron K.
*
* CLASS:		CTocFile
*
* DESCRIPTION:  
*
* LIMITATIONS:
*
* REVISION HISTORY:
*	Date		Comment
*
**********************************************************************************************************/

ULONGLONG CTocFile::GetNumTocEntries() const
{
	return (GetLength() - m_header_len) / sizeof(TOC_ENTRY);
}

/**********************************************************************************************************
*
* FUNCTION:		GetStartStamp() 
*
* AUTHOR:		Ron K.
*
* CLASS:		CTocFile
*
* DESCRIPTION:  Returns the study ending sample stamp. If no data was recorded then return -1.
*
* LIMITATIONS:
*
* REVISION HISTORY:
*	Date		Comment
*
**********************************************************************************************************/

int CTocFile::GetStartStamp()
{
	ULONGLONG		pos;
	TOC_ENTRY		lower_te;

	if (!IsRecordedData())
		return -1;

	// Record the current toc file position.
	pos = GetPosition();

	// Get the first toc entry.
	Seek(GetHeaderLen(), CFile::begin);
	ReadTocEntry(&lower_te);

	// Return the toc file to the original position.
	Seek(pos, CFile::begin);
	return lower_te.samplestamp;
}

int CTocFile::GetEndStamp()
{
	ULONGLONG		pos;
	long			s;
	TOC_ENTRY		upper_te;

	if (!IsRecordedData())
		return -1;

	// Record the current toc file position.
	pos = GetPosition();

	if (static_cast<DWORD>(GetHeaderLen()) == GetLength())
		return 0;	// 20011004 LB There are no toc entries, meaning nothing was recorded

	// Get the last toc entry.
	ULONGLONG offset = GetLength() - (int)sizeof(TOC_ENTRY);
//	UINT upper_pos = Seek(- (int)sizeof(TOC_ENTRY), CFile::end);
	ULONGLONG upper_pos = Seek(offset, CFile::begin);
	ASSERT(upper_pos == (UINT)offset);
	UINT n = ReadTocEntry(&upper_te);
	ASSERT(n == sizeof(TOC_ENTRY));

	s = upper_te.samplestamp + upper_te.sample_span - 1;

	// Return the toc file to the original position.
	Seek(pos, CFile::begin);
	return s;
}

/**********************************************************************************************************
*
* FUNCTION:		StampToSampNum() 
*
* AUTHOR:		Ron K.
*
* CLASS:		CTocFile
*
* DESCRIPTION:  Finds the sample stamp corresponding to the
*	given sample number. If the stamp is beyond the end of file, then
*	the last sample number is returned. If the stamp is before the start of
*	file then 0 is returned. If no data is recorded then -1 is returned.
*
* LIMITATIONS:
*
* REVISION HISTORY:
*	Date		Comment
*
**********************************************************************************************************/

int CTocFile::StampToSampNum(int samp_stamp)
{
	int				samp_num;
	ULONGLONG       pos;
	TOC_ENTRY		te;

	// Record the current toc file position.
	pos = GetPosition();

	te = FindTocEntry(samp_stamp);
	if (te.samplestamp == -1)
		samp_num = -1;
	else if (samp_stamp >= te.samplestamp + te.sample_span)
	{	// The time does not correspond to a recorded sample.
		// Return the sample number that has the closest time.
		samp_num = te.sample_num + te.sample_span;
	}
	else if (samp_stamp < te.samplestamp)
		samp_num = 0;	// samp_time is before the start of file.
	else
		samp_num = te.sample_num + (samp_stamp - te.samplestamp);

	// Return the toc file to the original position.
	Seek(pos, CFile::begin);
	return samp_num;
}

/**********************************************************************************************************
*
* FUNCTION:		GetRecordingTime() 
*
* AUTHOR:		Ron K.
*
* CLASS:		CStcFile
*
* DESCRIPTION:  Returns the number of samples recorded during study
*
* LIMITATIONS:
*
* REVISION HISTORY:
*	Date		Comment
*	20011004	L. Biswas - When no data is recorded return 0
**********************************************************************************************************/

long CTocFile::GetRecordingSampleNum()
{
	TOC_ENTRY		upper_te;

	// Record the current toc file position.
	ULONGLONG pos = GetPosition();

	if (static_cast<DWORD>(GetHeaderLen()) == GetLength())
	{
		// 20011004 LB: There are no toc entries, meaning nothing was recorded
		return 0;
	}
	// Get the last toc entry.
	ULONGLONG offset = GetLength() - (int)sizeof(TOC_ENTRY);
//	UINT upper_pos = Seek(- (int)sizeof(TOC_ENTRY), CFile::end);
	ULONGLONG upper_pos = Seek(offset, CFile::begin);
	ASSERT(upper_pos == (UINT)offset);
	UINT n = ReadTocEntry(&upper_te);
	ASSERT(n == sizeof(TOC_ENTRY));

	long num_recorded_samp = upper_te.sample_num + upper_te.sample_span;

	// Return the toc file to the original position.
	Seek(pos, CFile::begin);
	return num_recorded_samp;
}

/**********************************************************************************************************
*
* FUNCTION:		AddTocEntry() 
*
* AUTHOR:		Valery A.
*
* CLASS:		CTocFile
*
* DESCRIPTION:  Writes a new entry in TOC file
*
* LIMITATIONS:	throws CFile exceptions
*
* REVISION HISTORY:
*	Date		Comment
**********************************************************************************************************/

void CTocFile::AddTocEntry(TOC_ENTRY* te)
{
	SeekToEnd();
	Write(te, sizeof(TOC_ENTRY));
	Flush();
}

/**********************************************************************************************************
*
* FUNCTION:		GetIncrementalStamp() 
*
* AUTHOR:		Ron K.
*
* CLASS:		CTocFile
*
* DESCRIPTION:  Finds the stamp corresponding to the
*	start time plus a given number of samples.
*	Returns -1 if no data recorded.
*
* LIMITATIONS:
*
* REVISION HISTORY:
*	Date		Comment
*
**********************************************************************************************************/

long CTocFile::GetIncrementalStamp(long start_stamp, long inc)
{
	ULONGLONG        pos;
	int				samp_num;
	long			stamp;
	TOC_ENTRY		te, next_te;

	// Record the current toc file position.
	pos = GetPosition();

	te = FindTocEntry(start_stamp);

	if (te.samplestamp == -1)
		stamp = -1;
	else if (start_stamp >= te.samplestamp + te.sample_span)
	{
		// not a recorded area (break)
		if (inc >= 0){
			NextTocEntry(&next_te);
			if (next_te.samplestamp == -1)
			{	// start_time is beyond the end of file.
				stamp = LONG_MAX;
			}
			else
			{	// Start stamp corresponds to a time that was not recorded.
				// Return the nearest sample time.
				stamp = FindSampleStamp(next_te.sample_num + inc);
			}
		}else{
			{	// The time does not correspond to a recorded sample.
				// Return the sample number that has the closest time.
				samp_num = te.sample_num + te.sample_span;
				stamp = FindSampleStamp(samp_num + inc);
			}
		}
	}
	else
	{	
		samp_num = te.sample_num + (start_stamp - te.samplestamp);
		stamp = FindSampleStamp(samp_num + inc);
	}

	// Return the toc file to the original position.
	Seek(pos, CFile::begin);
	return stamp;
}

/**********************************************************************************************************
*
* FUNCTION:		ValidateStudyStamp() 
*
* AUTHOR:		Ron K.
*
* CLASS:		CTocFile
*
* DESCRIPTION:  Tests if there is a sample corresponding to stamp s.
*	Returns one of the enum values:
*	SS_VALID, SS_NO_DATA_RECORDED, SS_BEFORE_START, SS_AFTER_END, SS_NOT_RECORDED
*
* LIMITATIONS:
*
* REVISION HISTORY:
*	Date		Comment
*
**********************************************************************************************************/

CTocFile::SearchResult CTocFile::ValidateStudyStamp(long s)
{
	ULONGLONG    	pos;
	TOC_ENTRY		te;
	SearchResult	result = SS_VALID;

	// Record the current toc file position.
	pos = GetPosition();

	te = FindTocEntry(s);

	if (te.samplestamp == -1)
		result = SS_NO_DATA_RECORDED;
	else if	(s < te.samplestamp)
		result = SS_BEFORE_START;
	else if (s >= te.samplestamp + te.sample_span)
	{
		if (NextTocEntry(&te))
			result = SS_NOT_RECORDED;
		else
			result = SS_AFTER_END;
	}

	// Return the toc file to the original position.
	Seek(pos, CFile::begin);
	return result;
}
