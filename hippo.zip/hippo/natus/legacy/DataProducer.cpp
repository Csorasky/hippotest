// DataProducer.cpp: implementation of the CDataProducer class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "DataProducer.h"
#include "VariableDeltaReader.h"
#include "ConstantDeltaReader.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

/**********************************************************************************************************
* FUNCTION:		CreateDataProducer() 
* AUTHOR:		GSHULKIN
* CLASS:		CDataProducer
* DESCRIPTION:  Create new DataProducer based on a file schema. New schemas (> 7) require CVariableDeltaReader,
*				while old ones require CConstantDeltaReader
* LIMITATIONS:
* REVISION HISTORY:
**********************************************************************************************************/
CDataProducer* CDataProducer::CreateDataProducer(WORD file_schema, int num_channels, ULONGLONG header_len)
{
	CDataProducer* pDataProducer = NULL;
	if(file_schema > 7)
	{
		pDataProducer = static_cast<CDataProducer*>(new CVariableDeltaReader(num_channels));
		pDataProducer->SetHeaderLen(header_len);
	}
	else
		pDataProducer = static_cast<CDataProducer*>(new CConstantDeltaReader());

	return pDataProducer;
}
