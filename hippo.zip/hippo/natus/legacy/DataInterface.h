// DataInterface.h: interface for the ADataInterface class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DATAINTERFACE_H__2D81714A_B359_4859_95D0_C8B6981DC713__INCLUDED_)
#define AFX_DATAINTERFACE_H__2D81714A_B359_4859_95D0_C8B6981DC713__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "Eeg.h"
#include <memory>
using std::auto_ptr;

#define MAX_DELTA_LENGTH	MAX_NUM_CHANNELS * 2
#define MAX_SHORTED_LENGTH	MAX_NUM_CHANNELS / 8

// Frequency multiplyers: each one will be represented by a bit in a frequency BYTE.
// WARNING: changing these values will make previously recorded studies unreadable
#define	FIFTIETH_FREQ_POS		0
#define FORTH_FREQ_POS			1	
#define FIFTH_FREQ_POS			2
#define TENTH_FREQ_POS			3
#define TWENTIETH_FREQ_POS		4
#define TWENTYFIFTH_FREQ_POS	5

#define ABSOLUTE_DATA			7

#define FORTH_FREQ				4	
#define FIFTH_FREQ				5
#define TENTH_FREQ				10
#define TWENTIETH_FREQ			20
#define TWENTYFIFTH_FREQ		25
#define	FIFTIETH_FREQ			50

enum EDelta
{
	ABSOLUTE_VALUE = 0,
	BYTE_DELTA,
	DOUBLEBYTE_DELTA,
	NO_DELTA
};

class ADataInterface  
{
public:
	ADataInterface()
	{
		memset(m_phys_chan, 0, sizeof(m_phys_chan));
		memset(m_shorted_chan, 0, sizeof(m_shorted_chan));
		m_num_store_channels = 0;
		m_deltabits = 0;
		m_max_delta = 0;
		m_min_delta = 0;
		m_abs_delta = 0;
		m_mask_length = 0;
		m_number_short = 0;
		m_step = 0;
	}
	
	virtual ~ADataInterface()
	{
	}

	inline void Init(int num_store_channels, int deltabits, int* phys_chan, int discardbits)
	{
		SetNumStoreChanels(num_store_channels);
		SetDeltaBits(deltabits);
		SetPhysChannels(phys_chan);
		SetDiscardbits(discardbits);
	}
	
	inline void SetDeltaBits(int delta_bits)
	{
		m_deltabits = delta_bits;
		m_max_delta = (1 << (m_deltabits - 1)) - 1;
		m_min_delta = 1 - (1 << (m_deltabits - 1));
		m_abs_delta = (short)(1 << (m_deltabits*2 - 1));	// GSHULKIN - changed to indicate 2 BYTE extreme
		SetFixedDeltaLength();
	}

	inline void SetPhysChannels(int* channels)
	{
		memcpy(m_phys_chan, channels, MAX_NUM_CHANNELS * sizeof(int));	
	}

	inline void SetShortedChannels(short* shorted_channels, int channels_num)
	{
		m_number_short = 0;

		const int length = sizeof(m_shorted_chan) / sizeof(m_shorted_chan[0]);

		ASSERT(channels_num <= length);
		if(channels_num > length)
			channels_num = length;
		memcpy(m_shorted_chan, shorted_channels, channels_num * sizeof(m_shorted_chan[0]));
		for(int chan = 0; chan < m_num_store_channels; chan++)
		{
			if(m_shorted_chan[chan])
				m_number_short++;
		}
		CreateShortedMask();
	}

	inline short* GetShortedChannels(int& size)
	{
		size = 0;
		if(m_num_store_channels <= 0)
			return NULL;
		
		short* shorted_channels = new short[m_num_store_channels];
		memcpy(shorted_channels,m_shorted_chan,m_num_store_channels * sizeof(m_shorted_chan[0]));
		size = m_num_store_channels;
		return shorted_channels;
	}

	void SetNumStoreChanels(int num)
	{
		m_num_store_channels = num;
		SetDeltaMask();
		SetFixedDeltaLength();
	}

protected:
	int			m_deltabits;
	int			m_max_delta;
	int			m_min_delta;
	short		m_abs_delta;	// This delta is used to indicate that an absolute value follows.
	int			m_phys_chan[MAX_NUM_CHANNELS];		// Storage to physical channel assignments.
	int			m_num_store_channels;
	short		m_shorted_chan[FHEADER_MAX_STORE_CHANNELS];		// Storage to shorted channels
	int			m_number_short;
	short		m_step;

	int			m_mask_length;
	BYTE		m_delta_mask[MAX_NUM_CHANNELS];

	virtual void SetDeltaMask() = 0;
	virtual void SetFixedDeltaLength() = 0;
	virtual void CreateShortedMask() = 0;
	virtual void SetDiscardbits(int bits) = 0;
};

#endif // !defined(AFX_DATAINTERFACE_H__2D81714A_B359_4859_95D0_C8B6981DC713__INCLUDED_)
