/**********************************************************************************************************
*					Copyright (C) 1997 Excel Tech Ltd. All rights reserved.
*
* FILE:				EegFile.h
*
* CREATION DATE:	May 29, 1997
*
* AUTHOR:			Ron K.
*
* DESCRIPTION:		Interface of the CEegFile class.
*	This is a specialization of CFile that puts an EEG header at
*	the front of the file, and supports bit stream access.
*
* REVISION INFORMATION:
*
* $Header: /Branches/Main/EEGWorks/Source/EegCommon/EegFile.h 25    4/21/04 1:17a Akrasinsky $
*
**********************************************************************************************************/

#if !defined(EEGFILE_H)
#define EEGFILE_H

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "FHeader.h"
#include <afxmt.h>

class CEtlException;

#define MAX_CHUNK_SAMPLES		1000	// changed from 1000

class CEegFile : public CStdioFile
{
	DECLARE_DYNAMIC(CEegFile)

public:
	CEegFile(const CHeader &header);
	virtual ~CEegFile();
	size_t set_BufferSize(size_t sz);//returns actual size set
	inline size_t get_BufferSize() const {return m_buffer_sz;}
	virtual BOOL Open(LPCTSTR lpszFileName, UINT nOpenFlags, CEtlException *ex = NULL,CFileException* pfex=NULL);
	virtual BOOL Open(LPCTSTR lpszFileName, UINT nAddOpenFlags, /*inout*/ BOOL& bReadOnly, CEtlException *ex = NULL);
	inline ULONGLONG GetHeaderLen() const {return m_header_len;}
	CHeader			*m_header;

protected:
	static size_t DEFAULT_BUFFER_SZ;// static member so that default can be set for entire class
	size_t			m_buffer_sz;	// actual buffer size set to DEFAULT_BUFFER_SZ on ctor and then altered by set_BufferSize()
protected:
	ULONGLONG		m_header_len;	// Number of bytes long the header is.
};

struct TOC_ENTRY
{
	DWORD		offset;
	long		samplestamp;	// Sample number from start of study.
	long		sample_num;		// Number of samples stored to this point.
	short		sample_span;	// Number of samples from this toc entry to the next.
	// default constructor
	TOC_ENTRY()
	:	offset(0),
		samplestamp(-1),
		sample_num(0),
		sample_span(0)
	{;}

	bool operator<(const TOC_ENTRY& other) const{
		return (samplestamp < other.samplestamp);
	}
	bool operator==(const TOC_ENTRY& other) const{
		return (samplestamp == other.samplestamp);
	}
	bool operator==(long other_stamp) const{
		return (samplestamp == other_stamp);
	}
};

#endif

/**********************************************************************************************************					
*	End of $Source: G:/Projects/Eeg/Storage/rcs/EegFile.h $
**********************************************************************************************************/
