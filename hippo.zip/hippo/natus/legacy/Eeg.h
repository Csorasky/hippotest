/**********************************************************************************************************
*					Copyright (C) 1997 Excel Tech Ltd. All rights reserved.
*
* FILE:				Eeg.h
*
* CREATION DATE:	February 28, 1997
*
* AUTHOR:			Ron K.
*
* DESCRIPTION:		Project level include file. Defines the interface between project components.
*
* REVISION INFORMATION:
*
*	Reduced the number of channels from 32 to 30, removing A1 and A2.
* 20001207	Martin Fraser - removed the MinMax Channel type.
*
* $Header: /Branches/Main/EEGWorks/Source/Eeg.h 17    6/17/04 3:43p Gshulkin $
*
**********************************************************************************************************/

#ifndef EEG_H
#define EEG_H

#include <float.h>
#include <limits.h>

// Shared schema numbers.

const int MAX_NUM_CHANNELS = (512+20);						// Maximum number of channels supported.
const int MAX_NUM_HEADBOXES= 4;							// The maximum number of headboxes that will ever be supported.

#pragma pack(push, 1)

const long RAW_SAMPLE_OVERFLOW			= 0x7FFFFFL;	// 23rd bit is set when overflow occurs
const long RAW_SAMPLE_OVERFLOW_SHIFTED	= 0x7FFFC0L;	
const long RAW_SAMPLE_CHANNEL_SHORT		= 0x7FFF80L;	// flag for when channel is shorted

typedef struct tagRAW_DATA_HDR				// Following the header are m_num_chan raw values.
{
	WORD		m_num_chan;					// number of channels in this structure.
	BYTE		m_event;					// Used to mark data events such as external trigger.
	long		m_samplestamp;				// sample counter from start of study.
} RAW_DATA_HDR;

typedef struct tagRAW_DATA
{
	RAW_DATA_HDR	m_hdr;
	long			m_chan[MAX_NUM_CHANNELS];	
} RAW_DATA;

#pragma pack(pop)

#endif

/**********************************************************************************************************					
*	End of $Source: G:/Projects/Eeg/rcs/Eeg.h $
**********************************************************************************************************/
