// DataReader.h: interface for the ADataReader class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DATAREADER_H__48255516_0F3E_4B9B_BE63_520AEDF1E662__INCLUDED_)
#define AFX_DATAREADER_H__48255516_0F3E_4B9B_BE63_520AEDF1E662__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Eeg.h"
#include "EegFile.h"

enum EReadResult
{
	EFILE_END = 0,
	ESUCCESS,
	EFAILURE
};

class ADataReader  
{
public:
	ADataReader(){};
	virtual ~ADataReader(){};

	virtual EReadResult ReadData(CEegFile *data_file, RAW_DATA* raw, RAW_DATA* last_raw, bool& is_absolute) = 0;

};

#endif // !defined(AFX_DATAREADER_H__48255516_0F3E_4B9B_BE63_520AEDF1E662__INCLUDED_)
