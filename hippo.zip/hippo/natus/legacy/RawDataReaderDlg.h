// RawDataReaderDlg.h : header file
//

#if !defined(AFX_RAWDATAREADERDLG_H__FE5B36CA_EEF5_4DAA_9632_A57BF54E8A95__INCLUDED_)
#define AFX_RAWDATAREADERDLG_H__FE5B36CA_EEF5_4DAA_9632_A57BF54E8A95__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CRawDataReaderDlg dialog

class CRawDataReaderDlg : public CDialog
{
// Construction
public:
	CRawDataReaderDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CRawDataReaderDlg)
	enum { IDD = IDD_RAWDATAREADER_DIALOG };
	CButton	m_process_button;
	CString	m_file_name;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRawDataReaderDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	bool SelectDataFileName(CString& fileName, UINT nIDSTitle, DWORD lFlags);

	// Generated message map functions
	//{{AFX_MSG(CRawDataReaderDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnOpen();
	afx_msg void OnProcess();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_RAWDATAREADERDLG_H__FE5B36CA_EEF5_4DAA_9632_A57BF54E8A95__INCLUDED_)
