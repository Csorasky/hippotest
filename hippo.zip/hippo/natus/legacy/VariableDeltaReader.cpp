// VariableDeltaReader.cpp: implementation of the CVariableDeltaReader class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "VariableDeltaReader.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

BYTE CVariableDeltaReader::m_lookup_array[] =		
{
	0, 1, 1, 2, 1, 2, 2, 3, 1, 2, 2, 3, 2, 3, 3, 4,
	1, 2, 2, 3, 2, 3, 3, 4, 2, 3, 3, 4, 3, 4, 4, 5,
	1, 2, 2, 3, 2, 3, 3, 4, 2, 3, 3, 4, 3, 4, 4, 5,
	2, 3, 3, 4, 3, 4, 4, 5, 3, 4, 4, 5, 4, 5, 5, 6,
	1, 2, 2, 3, 2, 3, 3, 4, 2, 3, 3, 4, 3, 4, 4, 5,
	2, 3, 3, 4, 3, 4, 4, 5, 3, 4, 4, 5, 4, 5, 5, 6,
	2, 3, 3, 4, 3, 4, 4, 5, 3, 4, 4, 5, 4, 5, 5, 6,
	3, 4, 4, 5, 4, 5, 5, 6, 4, 5, 5, 6, 5, 6, 6, 7,
	1, 2, 2, 3, 2, 3, 3, 4, 2, 3, 3, 4, 3, 4, 4, 5,
	2, 3, 3, 4, 3, 4, 4, 5, 3, 4, 4, 5, 4, 5, 5, 6,
	2, 3, 3, 4, 3, 4, 4, 5, 3, 4, 4, 5, 4, 5, 5, 6,
	3, 4, 4, 5, 4, 5, 5, 6, 4, 5, 5, 6, 5, 6, 6, 7,
	2, 3, 3, 4, 3, 4, 4, 5, 3, 4, 4, 5, 4, 5, 5, 6,
	3, 4, 4, 5, 4, 5, 5, 6, 4, 5, 5, 6, 5, 6, 6, 7,
	3, 4, 4, 5, 4, 5, 5, 6, 4, 5, 5, 6, 5, 6, 6, 7,
	4, 5, 5, 6, 5, 6, 6, 7, 5, 6, 6, 7, 6, 7, 7, 8
};

BYTE CVariableDeltaReader::m_lookup_mask[] = 
{
	0, 1, 3, 7, 15, 31, 63, 127, 255
};

/**********************************************************************************************************
* FUNCTION:		ReadData() 
* AUTHOR:		GSHULKIN
* CLASS:		CVariableDeltaReader
* DESCRIPTION:  Read event byte, then the frequency byte and data (data is read differently in cases of variable 
*				and constant frequency
* LIMITATIONS:
* REVISION HISTORY:
**********************************************************************************************************/
EReadResult CVariableDeltaReader::ReadData(CEegFile *data_file, RAW_DATA* raw, RAW_DATA* last_raw, bool& is_absolute)
{
	// Get the event byte. 
	if (ReadRDF(&raw->m_hdr.m_event, sizeof(BYTE),data_file) < sizeof(BYTE))
	{
		return EFILE_END;
	}

	memset(m_is_abs, ABSOLUTE_VALUE, MAX_NUM_CHANNELS);
	if(m_variable_freq)
	{
		// Get the frequency byte. 
		if (ReadRDF(&m_freq_byte, sizeof(BYTE),data_file) < sizeof(BYTE))
		{
			return EFILE_END;
		}
		BOOL read_all = (m_variable_freq && (m_freq_byte & (1 << ABSOLUTE_DATA)));

		if(read_all)
			return ReadConstantFreqData(data_file,raw,last_raw,is_absolute);
		else
			return ReadVariableFreqData(data_file,raw,last_raw,is_absolute);
	}
	else
		return ReadConstantFreqData(data_file,raw,last_raw,is_absolute);
}

/**********************************************************************************************************
* FUNCTION:		InitializeShortedMask() 
* AUTHOR:		GSHULKIN
* CLASS:		CVariableDeltaReader
* DESCRIPTION:  Create inverted bitmask of the shorted channels for efficiency
* LIMITATIONS:
* REVISION HISTORY:
**********************************************************************************************************/	
void CVariableDeltaReader::InitializeShortedMask()
{
	int ord_byte,bit;
	BYTE shift;
	// Create bitmask from an array for efficiency
	for(int chan = 0; chan < m_num_store_channels; chan++)
	{
		ord_byte = (int)chan/8;
		bit = (int)chan%8;

		shift = (m_shorted_chan[chan]) ? (BYTE)1 : (BYTE)0;
		if(bit == 0)
			m_inverted_shorted_mask[ord_byte] = 0xFF;	// clear

		m_inverted_shorted_mask[ord_byte] &= ~(m_shorted_chan[chan] << bit);	// turn off the shorted bit
	}
}

/**********************************************************************************************************
* FUNCTION:		ReadConstantFreqData() 
* AUTHOR:		GSHULKIN
* CLASS:		CVariableDeltaReader
* DESCRIPTION:  Reads and uncompresses data from a raw data file with all the channels being recorded at a
*				frequency signal was sampled at.
* LIMITATIONS:
* REVISION HISTORY:
**********************************************************************************************************/	
EReadResult CVariableDeltaReader::ReadConstantFreqData(CEegFile *data_file, RAW_DATA* raw, RAW_DATA* last_raw, bool& is_absolute)
{
	// Get the delta mask
	int mask_size = sizeof(BYTE)*m_mask_length;
	if (ReadRDF((void*)m_delta_mask, mask_size,data_file) < mask_size)
	{
		return EFILE_END;
	}

	// Get the deltas
	int delta_size = 0;
	BYTE* delta_mask = m_delta_mask;
	for(int i = 0; i < mask_size; i++)		// 2 Bytes for 1 and 1 Byte for 0
	{
		if(i != mask_size - 1)
		{
			// first AND with inverted shorted. As a result we are getting 1's for 2Byte delta's and 0's for
			// 1Byte delta's and shorted channels
			delta_mask[i] &= m_inverted_shorted_mask[i];
			delta_size += 2*m_lookup_array[delta_mask[i]] + (8 - m_lookup_array[delta_mask[i]]);
		}
		else
		{
			// This is trickier we need only bits of interest and not the ones that result from the byte roundup
			int bit = m_num_store_channels%8;	// number of meaningful bits in the last byte
			if(bit == 0)
				bit = 8;
			delta_mask[i] &= m_lookup_mask[bit];
			delta_mask[i] &= m_inverted_shorted_mask[i];
						  // 1's									0's
			delta_size += 2*m_lookup_array[delta_mask[i]] + (bit - m_lookup_array[delta_mask[i]]);
		}
	}

	// optimized for general case when all channels are of the same frequency
	delta_size -= m_number_short;

	if (ReadRDF(&m_deltas, delta_size,data_file) < delta_size)
	{
		return EFILE_END;
	}

	int ord_byte,bit;
	int cur_index = 0;
	int absolute_values = 0;

	BYTE* temp_mask = m_delta_mask;
	int chan;
	for(chan = 0; chan < m_num_store_channels; chan++)
	{
		if(m_shorted_chan[chan])
			continue;				// skip shorted channels

		ord_byte = (int) (chan / 8);
		bit = (int) (chan % 8);

		if(temp_mask[ord_byte] & (1 << bit))
		{
			// 2 BYTE delta
			if((unsigned short&)m_deltas[cur_index] == _UI16_MAX)
			{
				m_is_abs[chan] = ABSOLUTE_VALUE;
				absolute_values++;
			}
			else
				m_is_abs[chan] = DOUBLEBYTE_DELTA;
			cur_index +=2;
		}
		else
		{
			// 1 BYTE delta
			m_is_abs[chan] = BYTE_DELTA;
			cur_index++;
		}
	}

	// Read the absolute values
   	if(absolute_values > 0)
	{
		int size_to_read = sizeof(long)*absolute_values;
		if(ReadRDF(m_absolute_values, sizeof(long)*absolute_values, data_file) < size_to_read)
		{
			return EFILE_END;
		}
	}

	// decompress data
	long diff;
	cur_index = 0;
	int abs_index = 0;
	is_absolute = true;
	for (chan = 0; chan < m_num_store_channels; chan++)
	{
		if(m_shorted_chan[chan])
		{
			raw->m_chan[m_phys_chan[chan]] = RAW_SAMPLE_CHANNEL_SHORT;
			raw->m_chan[m_phys_chan[chan]] <<= m_discardbits;
			continue;
		}

		if (m_is_abs[chan] == ABSOLUTE_VALUE)
		{
			ASSERT(abs_index < absolute_values);
			raw->m_chan[m_phys_chan[chan]] = m_absolute_values[abs_index];
			raw->m_chan[m_phys_chan[chan]] <<= m_discardbits;
			cur_index += 2;
			abs_index++;
		}
		else
		{
			// Sign extend delta.
			if(m_is_abs[chan] == BYTE_DELTA)
			{
				diff = m_deltas[cur_index];
				cur_index++;
				diff = (diff << (32 - m_deltabits)) >> (32 - m_deltabits);
			}
			else
			{
				diff = (short&) m_deltas[cur_index];
				cur_index += 2;
				diff = (diff << (32 - m_deltabits*2)) >> (32 - m_deltabits*2);
			}
			
			diff <<= m_discardbits;
			raw->m_chan[m_phys_chan[chan]] = last_raw->m_chan[m_phys_chan[chan]] + diff;
			is_absolute = false;
		}
	}

	// potentially needs to update interpolation data
	for(int interp_chan = 0; interp_chan < MAX_NUM_CHANNELS; interp_chan++)
	{
		if(m_interpolation_data[interp_chan].IsVariableFreq())
		{
			long val = raw->m_chan[m_phys_chan[interp_chan]];

			if(m_interpolation_data[interp_chan].IsInitialized())
			{
				// history data is initialized
				if(m_interpolation_data[interp_chan].IsDataToBeSkipped(m_step))
				{
					raw->m_chan[m_phys_chan[interp_chan]] = m_interpolation_data[interp_chan].GetInterpolatedData(m_interpolation_data[interp_chan].GetLastValue(),m_step);

					m_interpolation_data[interp_chan].RecalculateInterpolationData(m_step,val);
				}
				else
				{
					raw->m_chan[m_phys_chan[interp_chan]] = m_interpolation_data[interp_chan].GetLastValue();
					m_interpolation_data[interp_chan].PopulateInterpolationData(val);
				}	
			}
			else	// no valid history data yet
				m_interpolation_data[interp_chan].PopulateInterpolationData(val);
		}
	}
	
	m_step = 0;
	m_step++;
	return ESUCCESS;
}

/**********************************************************************************************************
* FUNCTION:		ReadVariableFreqData() 
* AUTHOR:		GSHULKIN
* CLASS:		CVariableDeltaReader
* DESCRIPTION:  Reads and uncompresses data from a raw data file with one or more channels recorded with a frequency
*				smaller than the frequency signal was sampled at.
* LIMITATIONS:
* REVISION HISTORY:
**********************************************************************************************************/	
EReadResult CVariableDeltaReader::ReadVariableFreqData(CEegFile *data_file, RAW_DATA* raw, RAW_DATA* last_raw, bool& is_absolute)
{
	// Get the delta mask
	int mask_size = sizeof(BYTE)*m_mask_length;
	if (ReadRDF((void*)m_delta_mask, mask_size,data_file) < mask_size)
	{
		return EFILE_END;
	}
		
	int ord_byte,bit;
	int cur_index = 0;
	int absolute_values = 0;

	BYTE* temp_mask = m_delta_mask;
	int chan;
	for(chan = 0; chan < m_num_store_channels; chan++)
	{
		if(m_shorted_chan[chan])
			continue;				// skip shorted channels

		// skip channels not being written because of lower frequency
		if(m_interpolation_data[chan].IsVariableFreq() && m_interpolation_data[chan].IsDataToBeSkipped(m_step))
		{
			m_is_abs[chan] = NO_DELTA;
			continue;
		}

		ord_byte = (int) (chan / 8);
		bit = (int) (chan % 8);

		if(temp_mask[ord_byte] & (1 << bit))
		{
			if(ReadRDF(&m_deltas[cur_index],sizeof(unsigned short),data_file) < sizeof(unsigned short))
				return EFILE_END;

			// 2 BYTE delta
			if((unsigned short&)m_deltas[cur_index] == _UI16_MAX)
			{
				m_is_abs[chan] = ABSOLUTE_VALUE;
				absolute_values++;
			}
			else
			{
				m_is_abs[chan] = DOUBLEBYTE_DELTA;
			}
			cur_index +=2;
		}
		else
		{
			if(ReadRDF(&m_deltas[cur_index],sizeof(BYTE),data_file) < sizeof(BYTE))
				return EFILE_END;
			
			// 1 BYTE delta
			m_is_abs[chan] = BYTE_DELTA;
			cur_index++;
		}
	}

	// Read the absolute values
   	if(absolute_values > 0)
	{
		int size_to_read = sizeof(long)*absolute_values;
		if(ReadRDF(m_absolute_values, sizeof(long)*absolute_values, data_file) < size_to_read)
		{
			return EFILE_END;
		}
	}

	// decompress data
	long diff;
	cur_index = 0;
	int abs_index = 0;

	is_absolute = true;
	for (chan = 0; chan < m_num_store_channels; chan++)
	{
		if(m_shorted_chan[chan])
		{
			raw->m_chan[m_phys_chan[chan]] = RAW_SAMPLE_CHANNEL_SHORT;
			raw->m_chan[m_phys_chan[chan]] <<= m_discardbits;
			continue;
		}

		if(m_is_abs[chan] == NO_DELTA)
		{
			// because of the lower frequency channel was not recorded
			raw->m_chan[m_phys_chan[chan]] = m_interpolation_data[chan].GetInterpolatedData(last_raw->m_chan[m_phys_chan[chan]],m_step);
			is_absolute = false;
		}
		else if (m_is_abs[chan] == ABSOLUTE_VALUE)
		{
			ASSERT(abs_index < absolute_values);
			long value = m_absolute_values[abs_index];
			value <<= m_discardbits;

			if(m_interpolation_data[chan].IsVariableFreq())
			{	// update history
				m_interpolation_data[chan].PopulateInterpolationData(value);
				// NOW NEEDS TO CALCULATE POINT WITH A PHASE SHIFT
				raw->m_chan[m_phys_chan[chan]] = m_interpolation_data[chan].GetInterpolatedData(last_raw->m_chan[m_phys_chan[chan]],m_step);
			}
			else
				raw->m_chan[m_phys_chan[chan]] = value;

			cur_index += 2;
			abs_index++;
		}
		else
		{
			// Sign extend delta.
			if(m_is_abs[chan] == BYTE_DELTA)
			{
				diff = m_deltas[cur_index];
				cur_index++;
				diff = (diff << (32 - m_deltabits)) >> (32 - m_deltabits);
			}
			else
			{
				diff = (short&) m_deltas[cur_index];
				cur_index += 2;
				diff = (diff << (32 - m_deltabits*2)) >> (32 - m_deltabits*2);
			}
			
			is_absolute = false;
			diff <<= m_discardbits;
			long value;
			
			if(m_interpolation_data[chan].IsVariableFreq())
			{
				if(m_interpolation_data[chan].IsInitialized())
					value = m_interpolation_data[chan].GetLastValue() + diff;	// use last history value
				else
					value = last_raw->m_chan[m_phys_chan[chan]] + diff; // use last processed value since history
																		// is not initialized
			
				m_interpolation_data[chan].PopulateInterpolationData(value);	// update history
				
				// NOW NEEDS TO CALCULATE POINT WITH A PHASE SHIFT
				raw->m_chan[m_phys_chan[chan]] = m_interpolation_data[chan].GetInterpolatedData(last_raw->m_chan[m_phys_chan[chan]],m_step);
			}
			else
			{
				value = last_raw->m_chan[m_phys_chan[chan]] + diff;
				raw->m_chan[m_phys_chan[chan]] = value;
			}
		}
	}

	m_step++;
	return ESUCCESS;
}

/**********************************************************************************************************
* FUNCTION:		CopyHeaderInfo() 
* AUTHOR:		GSHULKIN
* CLASS:		CVariableDeltaReader
* DESCRIPTION:  Copies information about shorted channels and information about downsampled channels
* LIMITATIONS:
* REVISION HISTORY:
**********************************************************************************************************/
void CVariableDeltaReader::CopyHeaderInfo(CEegFile *dest_file)
{
	dest_file->Flush();
	ULONGLONG position = dest_file->GetPosition();
	ASSERT(m_header_len == position);
	dest_file->Write(m_shorted_chan,sizeof(m_shorted_chan));
	short chan_freq[FHEADER_MAX_STORE_CHANNELS];
	int length = sizeof(chan_freq) / sizeof(chan_freq[0]);
	for(int i = 0; i < length; i++)
	{
		chan_freq[i] = m_interpolation_data[i].GetChanFreq();
	}
	dest_file->Write(chan_freq,sizeof(chan_freq));
	dest_file->Flush();
}

/**********************************************************************************************************
* FUNCTION:		InitNewDataFile() 
* AUTHOR:		GSHULKIN
* CLASS:		CVariableDeltaReader
* DESCRIPTION:  Reinitializes with a new erd file
* LIMITATIONS:
* REVISION HISTORY:
**********************************************************************************************************/
void CVariableDeltaReader::InitNewDataFile(CEegFile *data_file)
{
	ULONGLONG position = data_file->GetPosition();
	ASSERT(m_header_len > 0 && m_num_store_channels != 0);
	data_file->Seek(m_header_len,CFile::begin);

	const int length = sizeof(m_shorted_chan) / sizeof(m_shorted_chan[0]);

	short* shorted = new short[length];
	UINT bytes_read = data_file->Read(shorted, sizeof(m_shorted_chan));
	// it's possible not to have shorted channel info
	if(bytes_read != sizeof(m_shorted_chan))
	{
		data_file->Seek(position,CFile::begin);
		return;
	}

	SetShortedChannels(shorted,length);
	delete[] shorted;
	short chan_freq[FHEADER_MAX_STORE_CHANNELS];
	bytes_read = data_file->Read(chan_freq, sizeof(chan_freq));
	if(bytes_read != sizeof(chan_freq))
	{
		data_file->Seek(position,CFile::begin);
		return;
	}
	
	m_variable_freq = FALSE;
	for(int i = 0; i < m_num_store_channels; i++)
	{
		if(chan_freq[i] != SHRT_MAX)
		{
			m_variable_freq = TRUE;
		}

		m_interpolation_data[i].SetChanFreq(chan_freq[i]);
	}
	data_file->Seek(position,CFile::begin);
}