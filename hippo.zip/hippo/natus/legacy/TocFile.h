// TocFile.h: interface for the CTocFile class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TOCFILE_H__8396CC23_FBD9_11D2_B55D_00104B2AEDB0__INCLUDED_)
#define AFX_TOCFILE_H__8396CC23_FBD9_11D2_B55D_00104B2AEDB0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "EegFile.h"
class CTocHeader;

class CTocFile : public CEegFile  
{
public:
	CTocFile(const CTocHeader &header);
	virtual ~CTocFile();

// Methods
public:
	inline const CTocHeader *GetTocHeader() const {return dynamic_cast<CTocHeader*>(m_header);}
	UINT ReadTocEntry(TOC_ENTRY *te);
	virtual TOC_ENTRY FindTocEntry(int s);
	virtual BOOL NextTocEntry(TOC_ENTRY *te);
	BOOL PrevTocEntry(TOC_ENTRY *te);
	virtual long FindSampleStamp(int sampnum);
	int SampNumToStamp(int samp_num);
	int StampToSampNum(int samp_stamp);
	int GetStartStamp();
	int GetEndStamp();
	ULONGLONG GetNumTocEntries() const;
	inline BOOL IsRecordedData() const {
		return GetNumTocEntries() > 0;
	}
	long GetRecordingSampleNum();
	void AddTocEntry(TOC_ENTRY* te); // throws CFile exceptions
	long GetIncrementalStamp(long start_stamp, long inc);

	enum SearchResult {SS_VALID, SS_NO_DATA_RECORDED, SS_BEFORE_START, SS_AFTER_END, SS_NOT_RECORDED};
	SearchResult ValidateStudyStamp(long s);

	// V.A. accessors to get / set offset for samplenumbers. This allows reading code to be unaware
	// that TOC file segments always have 0 as the starting sample number
	int  GetStartSampleNumber() const{
		return m_nStartSampleNumber;
	}
	virtual void SetStartSampleNumber(int nStartSampleNumber){
		m_nStartSampleNumber = nStartSampleNumber;
	}
private:
	int	m_nStartSampleNumber;
	int	m_nStartSampleNumberInFile;
};

#endif // !defined(AFX_TOCFILE_H__8396CC23_FBD9_11D2_B55D_00104B2AEDB0__INCLUDED_)
