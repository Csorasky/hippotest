// DataProducer.h: interface for the CDataProducer class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DATAPRODUCER_H__6A2462DD_D2E1_4A9B_BF61_9ABBA3040B31__INCLUDED_)
#define AFX_DATAPRODUCER_H__6A2462DD_D2E1_4A9B_BF61_9ABBA3040B31__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "DataReader.h"
#include "DataInterface.h"

class CDataProducer : 
	public ADataReader, 
	public ADataInterface
{
public:
	CDataProducer()
	{
		m_discardbits = 0;
		Reset();
	}

	virtual void SetHeaderLen(ULONGLONG header_len) = 0;
	virtual void InitNewDataFile(CEegFile *data_file) = 0;

	static CDataProducer* CreateDataProducer(WORD file_schema, int num_channels, ULONGLONG header_len);

	virtual EReadResult ReadData(CEegFile *data_file, RAW_DATA* raw, RAW_DATA* last_raw, bool& is_absolute) = 0;
	virtual void CopyHeaderInfo(CEegFile *dest_file) = 0;
	inline void Reset() 
	{
		memset(&m_last_raw, 0, sizeof(RAW_DATA));
	}

	virtual void SetDiscardbits(int bits) { m_discardbits = bits; }
	inline void UpdateLastRaw(RAW_DATA*	raw)
	{
		if(raw)
			memcpy(&m_last_raw, raw, sizeof(RAW_DATA_HDR) + raw->m_hdr.m_num_chan * sizeof(long));
	}

protected:
	long				m_absolute_values[MAX_NUM_CHANNELS];
	RAW_DATA			m_last_raw;
	int					m_discardbits;

	BYTE				m_deltas[MAX_DELTA_LENGTH];

	int ReadRDF(void *buf, int len, CEegFile *data_file);
	virtual void SetDeltaMask() = 0;
	virtual void SetFixedDeltaLength() = 0;
	virtual void CreateShortedMask() = 0;
};

inline int CDataProducer::ReadRDF(void *buf, int len, CEegFile *data_file)
{
	return data_file->Read(buf,len);
}


#endif // !defined(AFX_DATAPRODUCER_H__6A2462DD_D2E1_4A9B_BF61_9ABBA3040B31__INCLUDED_)
