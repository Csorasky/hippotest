// ConstantDeltaReader.cpp: implementation of the CConstantDeltaReader class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ConstantDeltaReader.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

/**********************************************************************************************************
* FUNCTION:		ReadDelta() 
* AUTHOR:		GSHULKIN
* CLASS:		CConstantDeltaReader
* DESCRIPTION:   Reads a delta value from a compressed delta array.
*			     The number of bits of delta information is given by m_deltabits.
* LIMITATIONS:
* REVISION HISTORY:
**********************************************************************************************************/
BYTE CConstantDeltaReader::ReadDelta(BYTE deltas[MAX_FIXEDDELTA_LENGTH], int chan)
{
	int		offs, bit;
	BYTE	result;

	if (m_deltabits == 8)
		return deltas[chan];

	offs = chan * m_deltabits / 8;
	bit = (chan * m_deltabits) % 8;

	result = (BYTE)(deltas[offs] >> bit);
	if (m_deltabits + bit > 8)
		result |= deltas[offs + 1] << (8 - bit);

	result &= ((1 << m_deltabits) - 1);		// mask the result to m_deltabits bits.

	return result;
}

/**********************************************************************************************************
* FUNCTION:		ReadData() 
* AUTHOR:		GSHULKIN
* CLASS:		CConstantDeltaReader
* DESCRIPTION:   Read a timeslice of data. return EFILE_END if end of file is reached
* LIMITATIONS:
* REVISION HISTORY:
**********************************************************************************************************/
EReadResult CConstantDeltaReader::ReadData(CEegFile *data_file, RAW_DATA* raw, RAW_DATA* last_raw, bool& is_absolute)
{
	// Get the event byte. 
	if (ReadRDF(&raw->m_hdr.m_event, sizeof(BYTE),data_file) < sizeof(BYTE))
	{
		return EFILE_END;
	}
	
	// Get the compressed deltas.
	if (ReadRDF(m_deltas, m_deltas_len, data_file) < m_deltas_len)
	{
		return EFILE_END;
	}

	// Decode the deltas into bytes.
	int j;
	for (j = 0; j < m_num_store_channels; j++)
	{
		m_dec_deltas[j] = ReadDelta(m_deltas, j);
	}

	// Read in the absolute channel values, if any.
	long diff;
	is_absolute = true;
	for (j = 0; j < m_num_store_channels; j++)
	{
		if (m_dec_deltas[j] == m_abs_delta)
		{
			if (ReadRDF(&raw->m_chan[m_phys_chan[j]], sizeof(LONG), data_file) < sizeof(LONG))
			{
				return EFILE_END;
			}
			raw->m_chan[m_phys_chan[j]] <<= m_discardbits;
		}
		else
		{
			// Sign extend delta.
			diff = (m_dec_deltas[j] << (32 - m_deltabits)) >> (32 - m_deltabits);
			diff <<= m_discardbits;
			raw->m_chan[m_phys_chan[j]] = last_raw->m_chan[m_phys_chan[j]] + diff;
			is_absolute = false;	// indicate that data is not absolute. Used in a health check by a caller
		}
	}

	return ESUCCESS;
}
