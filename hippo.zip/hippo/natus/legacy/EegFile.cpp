/**********************************************************************************************************
*					Copyright (C) 1997 Excel Tech Ltd. All rights reserved.
*
* FILE:				EegFile.cpp
*
* CREATION DATE:	May 29, 1997
*
* AUTHOR:			Ron K.
*
* DESCRIPTION:		Implementation of the CEegFile class.
*	This is a specialization of CFile that puts an EEG header at
*	the front of the file, and supports bit stream io.
*
* REVISION INFORMATION:
*
*  Sept 02, 1999 - Dan Lisogurski
*  Changed from CFile to CStdioFile.  CFile by definition does not use any buffering which was
*  causing very slow file access / breaks / crashes over the network (the file cache seemed to
*  handle most of these problems for local files).
*
* $Header: /Branches/Main/EEGWorks/Source/EegCommon/EegFile.cpp 26    6/25/04 12:28a Buildmaster $
*
**********************************************************************************************************/

#include "stdafx.h"
#include "EegFile.h"
#include "FHeader.h"
#define CRITICAL_SECTION_TYPE CCriticalSection

#include <time.h>
#include <io.h> // to use _commit
#include <process.h>    /* _beginthread, _endthread */

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

size_t CEegFile::DEFAULT_BUFFER_SZ = 32768;		// max buffer size...may need to reduce this ??? TBD

IMPLEMENT_DYNAMIC(CEegFile, CStdioFile)

/**********************************************************************************************************
*
* FUNCTION:		CEegFile() 
*
* AUTHOR:		Ron K.
*
* CLASS:		CEegFile
*
* DESCRIPTION:
*
* LIMITATIONS:
*
* REVISION HISTORY:
*	Date		Comment
*
**********************************************************************************************************/

CEegFile::CEegFile(const CHeader &header)
{
	CRuntimeClass *hrc = header.GetRuntimeClass();
	m_header = (CHeader *)(*hrc->m_pfnCreateObject)();
	*m_header = header;
	m_header_len = 0;
	m_buffer_sz = DEFAULT_BUFFER_SZ;
}

/**********************************************************************************************************
*
* FUNCTION:		~CEegFile() 
*
* AUTHOR:		Ron K.
*
* CLASS:		CEegFile
*
* DESCRIPTION:  Destructor.
*
* LIMITATIONS:
*
* REVISION HISTORY:
*	Date		Comment
*
**********************************************************************************************************/

CEegFile::~CEegFile()
{
	delete m_header;
}

/**********************************************************************************************************
*
* FUNCTION:		set_BufferSize() 
*
* AUTHOR:		Steve Alexander
*
* CLASS:		CEegFile
*
* DESCRIPTION:  Use to setup buffer used for reading and writing access. Valid range is 2 to 32768 bytes.
*				Returns the actual number setup. This must be called before calling Open() to have the
*				desired buffer size. If the size specified by 'sz' is outside the valid range, the buffer
*				remains unchanged.
*
* LIMITATIONS:
*
* REVISION HISTORY:
*	Date		Comment
*
**********************************************************************************************************/
size_t CEegFile::set_BufferSize(size_t sz)
{
	size_t rsz=m_buffer_sz;

	if ( sz > 1 && sz < 32769 )
	{
		rsz = 2*(sz/2);//must be a factor of 2
	}

	m_buffer_sz = rsz;

	return rsz;
}

/**********************************************************************************************************
*
* FUNCTION:		Open() 
*
* AUTHOR:		Ron K.
*
* CLASS:		CEegFile
*
* DESCRIPTION:  If opening for creation, write the header.
*	If opening for read, then read in the header.
*
* LIMITATIONS:
*
* REVISION HISTORY:
*	Date		Comment
*	20011114	LB - If an exception is caught after the file has successfully opened (during serialization, for
*				example) the file should be closed before returning failure.
*	20011121	SCA - changed default buffer size. Experimented with buffer and found that 32K (previous) is too large
*				and results in thrashing (as seen in performance monitor). Found that 8K provides for even
*				recording between storage and video (balanced access - reduces thrashing).
*	20011220	Ilia Tulchinsky - added CFileException parameter for the callers that are interested
*				in what file exception caused the failure of file opening (CEtlException preserves the string representation but not 
				OS codes). 
**********************************************************************************************************/
BOOL CEegFile::Open(LPCTSTR lpszFileName, UINT nOpenFlags, CEtlException *ex /*= NULL*/,CFileException *pfex /*= NULL*/)
{
	BOOL			result;
	CFileException	fex;
	if (pfex==NULL)
		pfex = &fex;
	try
	{
		result = CStdioFile::Open(lpszFileName, nOpenFlags | CFile::typeBinary,pfex);
		if (result == FALSE)
		{
			AfxThrowFileException(pfex->m_cause, pfex->m_lOsError, pfex->m_strFileName);
		}
		setvbuf(this->m_pStream,NULL,_IOFBF,m_buffer_sz);
		if (nOpenFlags & modeCreate)
		{
			m_header->m_creation_time = _time32(NULL);
			CArchive ar(this, CArchive::store);
			m_header->Serialize(ar);
			ar.Close();
		}
		else
		{
			// Read in the base header.
			CArchive ar1(this, CArchive::load);
			m_header->Serialize(ar1);
			ar1.Close();
		}

		m_header_len = GetPosition();
		return TRUE;
	}

	catch(CException&)
	{
		if (m_pStream != NULL)	// 20011114 LB If file has been opened, close it
		{
			try
			{
				Close();
			}
			catch (...) {}
		}
		return FALSE;
	}
}

/**********************************************************************************************************
*
* FUNCTION:		Open() 
*
* AUTHOR:		Valery A.
*
* CLASS:		CEegFile
*
* DESCRIPTION:  Open (read-only or not) and return read-only flag
*
* LIMITATIONS:
*
* REVISION HISTORY:
**********************************************************************************************************/

BOOL CEegFile::Open(LPCTSTR lpszFileName, UINT nAddOpenFlags, /*inout*/ BOOL& bReadOnly, CEtlException *ex /*= NULL*/)
{
	BOOL result = TRUE;
	if (bReadOnly)
	{
		result = this->Open(lpszFileName, nAddOpenFlags | CFile::modeRead | CFile::shareDenyNone, ex);
		if (result == TRUE)
			bReadOnly = TRUE;
	}
	else
	{
		result = this->Open(lpszFileName, nAddOpenFlags | CFile::modeReadWrite | CFile::shareDenyWrite, ex);
		if (result == FALSE)
		{	// If we cannot open the file read/write then open it read only.
			result = this->Open(lpszFileName, nAddOpenFlags | CFile::modeRead | CFile::shareDenyNone, ex);
			if (result == TRUE)
				bReadOnly = TRUE;
		}
	}
	return result;
}

/**********************************************************************************************************					
*	End of $Source: G:/Projects/Eeg/Storage/rcs/EegFile.cpp $
**********************************************************************************************************/
