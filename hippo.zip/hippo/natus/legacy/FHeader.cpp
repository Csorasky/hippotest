/**********************************************************************************************************
*					Copyright (C) 1997 Excel Tech Ltd. All rights reserved.
*
* FILE:				FHeader.cpp
*
* CREATION DATE:	May 29, 1997
*
* AUTHOR:			Ron K.
*
* DESCRIPTION:		Implementation of the CHeader class.
*
* REVISION INFORMATION:
*
* $Header: /Branches/Main/EEGWorks/Source/EegCommon/FHeader.cpp 24    2/23/04 6:37p Itulchinsky $
*
**********************************************************************************************************/

#include "stdafx.h"
#include "FHeader.h"
#include <time.h>
#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#define DFLT_DELTABITS			8
#define DFLT_DISCARDBITS		6		// We sample 22 and discard 6, leaving 16 stored.

/**********************************************************************************************************					
*	CHeader Implementation
**********************************************************************************************************/

GUID CHeader::m_GenericFileGuid = 
{ /* ca0b0790-d795-11d0-af32-00a0245b54a5 */
    0xca0b0790,
    0xd795,
    0x11d0,
    {0xaf, 0x32, 0x00, 0xa0, 0x24, 0x5b, 0x54, 0xa5}
};

IMPLEMENT_SERIAL(CHeader, CObject, GENERIC_FILE_SCHEMA)

/**********************************************************************************************************
*
* FUNCTION:		CHeader() 
*
* AUTHOR:		Ron K.
*
* CLASS:		CHeader
*
* DESCRIPTION:  Default constructor.
*
* LIMITATIONS:
*
* REVISION HISTORY:
*	Date		Comment
*
**********************************************************************************************************/

CHeader::CHeader()
{
	m_file_guid = m_GenericFileGuid;
	m_base_schema = BASE_FILE_SCHEMA;
	m_file_schema = GENERIC_FILE_SCHEMA;
	m_creation_time = _time32(NULL);
	m_study_id = 0;
	m_patient_id = 0;
	m_pat_last_name[0] = '\0';
	m_pat_middle_name[0] = '\0';
	m_pat_first_name[0] = '\0';
	m_pat_id[0] = '\0';
}

/**********************************************************************************************************
*
* FUNCTION:		CHeader() 
*
* AUTHOR:		Ron K.
*
* CLASS:		CHeader
*
* DESCRIPTION:  Copy constructor.
*
* LIMITATIONS:
*
* REVISION HISTORY:
*	Date		Comment
*
**********************************************************************************************************/

CHeader::CHeader(const CHeader &hdr)
{
	if (this != &hdr)
		*this = hdr;
}

/**********************************************************************************************************
*
* FUNCTION:		operator=() 
*
* AUTHOR:		Ron K.
*
* CLASS:		CHeader
*
* DESCRIPTION:  Assignment operator.
*
* LIMITATIONS:
*
* REVISION HISTORY:
*	Date		Comment
*
**********************************************************************************************************/

const CHeader &CHeader::operator=(const CHeader &hdr)
{
	if (this != &hdr)
	{
		m_file_guid = hdr.m_file_guid;
		m_file_schema = hdr.m_file_schema;
		m_base_schema = hdr.m_base_schema;
		m_creation_time = hdr.m_creation_time;
		m_patient_id = hdr.m_patient_id;
		m_study_id = hdr.m_study_id;
		strcpy_s(m_pat_last_name, hdr.m_pat_last_name);
		strcpy_s(m_pat_middle_name, hdr.m_pat_middle_name);
		strcpy_s(m_pat_first_name, hdr.m_pat_first_name);
		strcpy_s(m_pat_id, hdr.m_pat_id);
	}

	return *this;
}

/**********************************************************************************************************
*
* FUNCTION:		Serialize() 
*
* AUTHOR:		Ron K.
*
* CLASS:		CHeader
*
* DESCRIPTION:	Serialization support for the generic header.
*
* LIMITATIONS:
*
* REVISION HISTORY:
*	Date		Comment
*
**********************************************************************************************************/

void CHeader::Serialize(CArchive &ar)
{
	CObject::Serialize(ar);

    if (ar.IsStoring())
	{
		ar.Write(&m_file_guid, sizeof(GUID));
		ar.Write(&m_file_schema, sizeof(WORD));
		ar.Write(&m_base_schema, sizeof(WORD));
		ar.Write(&m_creation_time, sizeof(__time32_t));
		ar.Write(&m_patient_id, sizeof(long));
		ar.Write(&m_study_id, sizeof(long));
		ar.Write(m_pat_last_name, FHEADER_NAME_STR_LEN);
		ar.Write(m_pat_middle_name, FHEADER_NAME_STR_LEN);
		ar.Write(m_pat_first_name, FHEADER_NAME_STR_LEN);
		ar.Write(m_pat_id, FHEADER_NAME_STR_LEN);
	}
	else
	{
		GUID	expected_guid;		
		ar.Read(&expected_guid, sizeof(GUID));
		if(expected_guid!=m_file_guid)		// file is corrupt or not an XLTEK file (e.g. BMSI .eeg file)
			AfxThrowArchiveException(CArchiveException::badIndex, (LPCTSTR)ar.m_strFileName);
//			throw MAKE_ETL_EXCEPTION1(NWSTORAGE_INVALID_FILE_FORMAT,"");
		ar.Read(&m_file_schema, sizeof(WORD));
		ar.Read(&m_base_schema, sizeof(WORD));
		ar.Read(&m_creation_time, sizeof(__time32_t));
		char strtime[26];
		_ctime32_s(strtime, 26, &m_creation_time);
		ar.Read(&m_patient_id, sizeof(long));
		ar.Read(&m_study_id, sizeof(long));
		ar.Read(m_pat_last_name, FHEADER_NAME_STR_LEN);
		ar.Read(m_pat_middle_name, FHEADER_NAME_STR_LEN);
		ar.Read(m_pat_first_name, FHEADER_NAME_STR_LEN);
		ar.Read(m_pat_id, FHEADER_NAME_STR_LEN);

		// Upgrade base schema number.
		if (m_base_schema == 0)
		{
			m_base_schema = BASE_FILE_SCHEMA;
			m_patient_id = 0;
			m_study_id = 0;
		}
	}
}

/**********************************************************************************************************					
*	CRawDataHeader Implementation
**********************************************************************************************************/

GUID CRawDataHeader::m_RawDataFileGuid = 
{ /* ca0b0791-d795-11d0-af32-00a0245b54a5 */
    0xca0b0791,
    0xd795,
    0x11d0,
    {0xaf, 0x32, 0x00, 0xa0, 0x24, 0x5b, 0x54, 0xa5}
};

IMPLEMENT_SERIAL(CRawDataHeader, CHeader, RAW_DATA_FILE_SCHEMA)

/**********************************************************************************************************
*
* FUNCTION:		CRawDataHeader() 
*
* AUTHOR:		Ron K.
*
* CLASS:		CRawDataHeader
*
* DESCRIPTION:  Default constructor.
*
* LIMITATIONS:
*
* REVISION HISTORY:
*	Date		Comment
*
**********************************************************************************************************/

CRawDataHeader::CRawDataHeader()
{
	int i;

	m_file_guid = m_RawDataFileGuid;
	m_sample_freq = 0;
	m_file_schema = RAW_DATA_FILE_SCHEMA;
	m_num_channels = 0;
	m_deltabits = DFLT_DELTABITS;
	m_discardbits = DFLT_DISCARDBITS;
	strcpy_s(m_dsp_hw_version, "0.0");
	strcpy_s(m_dsp_sw_version, "0.0");

	memset(m_phys_chan, 0, MAX_NUM_CHANNELS * sizeof(int));
	for (i = 0; i < m_num_channels; i++)
		m_phys_chan[i] = i;

	for (i = 0; i < MAX_NUM_HEADBOXES; i++)
	{
		m_headbox_type[i] = 0;
		m_headbox_sn[i] = 0;
		strcpy_s(m_headbox_sw_version[i], "0.0");
	}
}

/**********************************************************************************************************
*
* FUNCTION:		operator=() 
*
* AUTHOR:		Ron K.
*
* CLASS:		CHeader
*
* DESCRIPTION:  Assignment operator.
*
* LIMITATIONS:
*
* REVISION HISTORY:
*	Date		Comment
*
**********************************************************************************************************/

const CHeader &CRawDataHeader::operator=(const CHeader &hdr)
{
	if (this != &hdr)
	{
		if (hdr.IsKindOf(RUNTIME_CLASS(CRawDataHeader)))
			CRawDataHeader::operator=(*(CRawDataHeader *)&hdr);
		else
			CHeader::operator=(hdr);
	}
	
	return *this;
}

const CRawDataHeader &CRawDataHeader::operator=(const CRawDataHeader &hdr)
{
	if (this != &hdr)
	{
		CHeader::operator=(hdr);
		m_sample_freq = hdr.m_sample_freq;
		m_num_channels = hdr.m_num_channels;
		m_deltabits = hdr.m_deltabits;
		m_discardbits = hdr.m_discardbits;
		memcpy(m_headbox_type, hdr.m_headbox_type, MAX_NUM_HEADBOXES * sizeof(int));
		memcpy(m_headbox_sn, hdr.m_headbox_sn, MAX_NUM_HEADBOXES * sizeof(int));
		memcpy(m_headbox_sw_version, hdr.m_headbox_sw_version, FHEADER_VERSION_STR_LEN * MAX_NUM_HEADBOXES);
		memcpy(m_phys_chan, hdr.m_phys_chan, FHEADER_MAX_STORE_CHANNELS * sizeof(int));
	}

	return *this;
}

/**********************************************************************************************************
*
* FUNCTION:		Serialize() 
*
* AUTHOR:		Ron K.
*
* CLASS:		CRawDataHeader
*
* DESCRIPTION:	Serialization support for the raw header.
*
* LIMITATIONS:
*
* REVISION HISTORY:
*	Date		Comment
*
**********************************************************************************************************/

void CRawDataHeader::Serialize(CArchive &ar)
{
	CHeader::Serialize(ar);

    if (ar.IsStoring())
	{
		ar.Write(&m_sample_freq, sizeof(double));
		ar.Write(&m_num_channels, sizeof(int));
		ar.Write(&m_deltabits, sizeof(int));

		if (m_file_schema < 6)
			ar.Write(m_phys_chan, 32 * sizeof(int));
		else if (m_file_schema < 7)
			ar.Write(m_phys_chan, 128 * sizeof(int));
		else
			ar.Write(m_phys_chan, FHEADER_MAX_STORE_CHANNELS * sizeof(int));

		ar.Write(m_headbox_type, MAX_NUM_HEADBOXES * sizeof(int));
		ar.Write(m_headbox_sn, MAX_NUM_HEADBOXES * sizeof(int));
		ar.Write(m_headbox_sw_version, FHEADER_VERSION_STR_LEN * MAX_NUM_HEADBOXES);
		ar.Write(m_dsp_hw_version, FHEADER_VERSION_STR_LEN);
		ar.Write(m_dsp_sw_version, FHEADER_VERSION_STR_LEN);
		ar.Write(&m_discardbits, sizeof(int));
	}
	else
	{
		int old_num_channels = m_num_channels;
		double old_sample_freq = m_sample_freq;

		ar.Read(&m_sample_freq, sizeof(double));
		ar.Read(&m_num_channels, sizeof(int));
		ar.Read(&m_deltabits, sizeof(int));

		if (m_file_schema < 6)
			ar.Read(m_phys_chan, 32 * sizeof(int));
		else if (m_file_schema < 7)
			ar.Read(m_phys_chan, 128 * sizeof(int));
		else
			ar.Read(m_phys_chan, FHEADER_MAX_STORE_CHANNELS * sizeof(int));

		ar.Read(m_headbox_type, MAX_NUM_HEADBOXES * sizeof(int));
		ar.Read(m_headbox_sn, MAX_NUM_HEADBOXES * sizeof(int));
		ar.Read(m_headbox_sw_version, FHEADER_VERSION_STR_LEN * MAX_NUM_HEADBOXES);
		ar.Read(m_dsp_hw_version, FHEADER_VERSION_STR_LEN);
		ar.Read(m_dsp_sw_version, FHEADER_VERSION_STR_LEN);
		ar.Read(&m_discardbits, sizeof(int));

		// Recover a bogus header with what hopefully are the right values.
		// First try to recover to the values defined in the constructor, which likely come from patient info.
		// If this does not work then set the values to those used by the eeg32 headbox.
		if (m_sample_freq <= 0)
			m_sample_freq = old_sample_freq;
		if (m_num_channels <= 0)
		{
			m_num_channels = old_num_channels;
			memset(m_phys_chan, 0, FHEADER_MAX_STORE_CHANNELS * sizeof(int));
			for (int i = 0; i < m_num_channels; i++)
				m_phys_chan[i] = i;
		}

		if (m_sample_freq <= 0)
			m_sample_freq = 499.9069940;
		if (m_num_channels <= 0)
		{
			m_num_channels = 32;
			memset(m_phys_chan, 0, FHEADER_MAX_STORE_CHANNELS * sizeof(int));
			for (int i = 0; i < m_num_channels; i++)
				m_phys_chan[i] = i;
		}
	}
}

/**********************************************************************************************************					
*	CTocHeader Implementation
**********************************************************************************************************/

GUID CTocHeader::m_TocFileGuid = 
{ /* ca0b0792-d795-11d0-af32-00a0245b54a5 */
    0xca0b0792,
    0xd795,
    0x11d0,
    {0xaf, 0x32, 0x00, 0xa0, 0x24, 0x5b, 0x54, 0xa5}
};

IMPLEMENT_SERIAL(CTocHeader, CHeader, RAW_DATA_FILE_SCHEMA)

/**********************************************************************************************************
*
* FUNCTION:		CTocHeader() 
*
* AUTHOR:		Ron K.
*
* CLASS:		CTocHeader
*
* DESCRIPTION:  Default constructor.
*
* LIMITATIONS:
*
* REVISION HISTORY:
*	Date		Comment
*
**********************************************************************************************************/

CTocHeader::CTocHeader()
{
	m_file_guid = m_TocFileGuid;
	m_file_schema = TOC_FILE_SCHEMA;
}

/**********************************************************************************************************
*
* FUNCTION:		Serialize() 
*
* AUTHOR:		Ron K.
*
* CLASS:		CTocHeader
*
* DESCRIPTION:	Serialization support for the toc header.
*
* LIMITATIONS:
*
* REVISION HISTORY:
*	Date		Comment
*
**********************************************************************************************************/

void CTocHeader::Serialize(CArchive &ar)
{
	CHeader::Serialize(ar);

    if (ar.IsStoring())
	{
	}
	else
	{
		if (m_file_schema != TOC_FILE_SCHEMA &&
			m_file_schema != 2)
		{
			AfxThrowArchiveException(CArchiveException::badSchema, ar.GetFile()->GetFileName());
		}
	}
}

/**********************************************************************************************************					
*	End of $Source: S:/EEGWorks/Source/EegCommon/FHeader.cpp $
**********************************************************************************************************/
