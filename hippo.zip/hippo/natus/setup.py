from setuptools import setup, Extension
from Cython.Build import cythonize
from Cython.Compiler import Options
import numpy

Options.annotate = True

extensions = [
    Extension(
        "nwreader.fast.erd",
        sources=["nwreader/fast/fasterd.pyx"],
        include_dirs=[numpy.get_include()],
        define_macros=[('NPY_NO_DEPRECATED_API', 'NPY_1_7_API_VERSION')]
    ),
    Extension(
        "nwreader.fast.keytree",
        sources=["nwreader/fast/fastkeytree.pyx"],
        include_dirs=[numpy.get_include()],
        define_macros=[('NPY_NO_DEPRECATED_API', 'NPY_1_7_API_VERSION')]
    ),
]


setup(
    name='nwreader',  # Required
    setup_requires=[
        'setuptools>18.0',
        'Cython',
        'numpy'
    ],
    version="0.0.1",
    packages=['nwreader'],
    python_requires=">=3.7",
    ext_modules=cythonize(extensions, compiler_directives={"language_level": 3, "profile": False}),
)
