# from collections.abc import Iterable
from typing import Iterable
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from io import BufferedReader
from uuid import UUID

import struct

from .utils import b_to_str, b_to_guid

GENERIC_HEADER_LEN = 352


@dataclass
class GenericHeader:
    """Class to encapsulate generic headers info
    """
    guid: UUID  # GUID defining file type to follow
    schema: int  # Schema version of typed file
    base_schema: int  # Schema version of GenericHeader
    creation_time: datetime
    _patient_id: int  # Internal patient ID
    _study_id: int  # Internal study ID
    last_name: str
    first_name: str
    middle_name: str
    patient_id: str
    product_version_high: int  # In base_schema = 0 only
    product_version_low: int  # In base_schema = 0 only

    def as_dict(self) -> dict:
        """Post-process: remove mutually exclusive data fields
        defined in diferent versions of the base_schema
        """
        outdict = asdict(self)

        if self.base_schema == 0:
            del outdict['_patient_id']
            del outdict['_study_id']
        elif self.base_schema == 1:
            del outdict['product_version_high']
            del outdict['product_version_low']
        else:
            raise NotImplementedError('base_schema not implemented: {}'.format(self.base_schema))

        return outdict

    def validate_guid(self, guid: UUID) -> bool:
        """Check against a reference GUID

        Args:
            guid (UUID): reference GUID to check against

        Raises:
            ValueError: wrong GUID not matching expected type
        """
        if self.guid != guid:
            raise ValueError("File GUID type {} != expected {}".format(
                self.guid, guid))
        return True

    def validate_schemas(self, schemas) -> bool:
        """Check against a set of reference schemas that are implemented

        Args:
            schemas (set|dict_keys): Reference set of supported schemas

        Raises:
            ValueError: reference schemas input does not support "in"
            NotImplementedError: not a supported reference schema
        """
        if not hasattr(schemas, "__contains__"):
            raise ValueError("validate_schemas must used on set or dict_keys")

        if self.schema not in schemas:
            raise NotImplementedError(
                "schema {} not implemented, expecting {}".format(
                    self.schema, schemas)
            )
        return True

    def merge(self, headers: Iterable['GenericHeader']) -> 'GenericHeader':
        """Merge this instance of generic header with others

        Args:
            headers (Iterable[GenericHeader]): an iterable list of headers

        Raises:
            ValueError: mismatch in anything other than creation_time

        Returns:
            GenericHeader: the same GenericHeader with oldest creation_time
        """
        oldest_time = self.creation_time
        newest_last_name = self.last_name
        newest_first_name = self.first_name
        newest_middle_name = self.middle_name
        newest_patient_id = self.patient_id

        for seg_ in headers:
            if (
                # these should all exactly match; the only thing that gets
                # to change in the middle of a study are creation_time and
                # patient str arbitrary fields (name, id)
                seg_.guid != self.guid or
                seg_.schema != self.schema or
                seg_.base_schema != self.base_schema or
                seg_._patient_id != self._patient_id or
                seg_._study_id != self._study_id or
                seg_.product_version_high != self.product_version_high or
                seg_.product_version_low != self.product_version_low
            ):
                raise ValueError('merging generic headers show mismatching study params')

            # merge with oldest creation time
            if seg_.creation_time < oldest_time:
                oldest_time = seg_.creation_time

            # merge with newest (assuming most up to date) arbitrary strs
            if self.last_name != newest_last_name:
                newest_last_name = self.last_name
            if self.first_name != newest_first_name:
                newest_first_name = self.first_name
            if self.middle_name != newest_middle_name:
                newest_middle_name = self.middle_name
            if self.patient_id != newest_patient_id:
                newest_patient_id = self.patient_id

        return self.__class__(
            self.guid,
            self.schema,
            self.base_schema,
            oldest_time,
            self._patient_id,
            self._study_id,
            newest_last_name,
            newest_first_name,
            newest_middle_name,
            newest_patient_id,
            self.product_version_high,
            self.product_version_low
        )

    @classmethod
    def from_buffer(cls, buf: bytes) -> 'GenericHeader':

        # first assume base_schema = 1
        product_version_high = None
        product_version_low = None

        # first 16 bytes is guid
        guid = b_to_guid(buf[:16])

        (
            schema,
            base_schema,
            creation_time,
            _patient_id,
            _study_id,
            last_name,
            first_name,
            middle_name,
            patient_id
        ) = struct.unpack("<HHill80s80s80s80s",
                          buf[16:])

        # convert creation_time
        creation_time = datetime.fromtimestamp(creation_time, timezone.utc)
        last_name = b_to_str(last_name)
        first_name = b_to_str(first_name)
        middle_name = b_to_str(middle_name)
        patient_id = b_to_str(patient_id)

        # if base schema turns out to be 0
        if base_schema == 0:
            product_version_high = _patient_id
            _patient_id = None
            product_version_low = _study_id
            _study_id = None

        return cls(
                guid,
                schema,
                base_schema,
                creation_time,
                _patient_id,
                _study_id,
                last_name,
                first_name,
                middle_name,
                patient_id,
                product_version_high,
                product_version_low
        )

    @classmethod
    def from_file(cls, f: BufferedReader) -> 'GenericHeader':
        f.seek(0)
        buf = f.read(GENERIC_HEADER_LEN)
        return cls.from_buffer(buf)
