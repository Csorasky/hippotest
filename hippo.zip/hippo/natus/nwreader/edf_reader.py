import dask
import dask.array
import pyedflib
import xarray as xr
import datetime
import pandas as pd


def read_channel_chunk_delayed(fn, channel, start, chunksize):
    dtype = "int32"

    def read_channel_chunk():
        with pyedflib.EdfReader(fn) as fh:
            return fh.readSignal(
                chn=channel,
                start=start,
                n=chunksize,
                digital=True,
            )

    vals = dask.delayed(read_channel_chunk)()
    arr = dask.array.from_delayed(vals, (chunksize,), dtype=dtype)

    return arr


def read_edf(filename):
    with pyedflib.EdfReader(filename) as f:
        num_channels = f.signals_in_file
        nsamples = f.getNSamples()[0]
        chan_labels = f.getSignalLabels()
        chunksize = f.samples_in_datarecord(0)
        nchunks = f.datarecords_in_file
        start = f.getStartdatetime()
        end = start + datetime.timedelta(seconds=f.file_duration)

    chan_chunks = []
    for chan in range(num_channels):
        sample_chunks = []
        for record in range(nchunks):
            idx = record * chunksize
            chunk = read_channel_chunk_delayed(filename, chan, idx, chunksize)
            sample_chunks.append(chunk)

        chan_chunks.append(dask.array.concatenate(sample_chunks))

    timestamps = pd.date_range(start=start, end=end, periods=nsamples)
    da = xr.DataArray(
        data=dask.array.stack(chan_chunks, axis=0),
        dims=["channel", "sample"],
        coords={
            "channel": chan_labels,
            "timestamp": ("sample", timestamps),
        },
    )

    return da
