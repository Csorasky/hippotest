from datetime import datetime
from enum import Enum
from io import BufferedReader
import json
import struct
from uuid import UUID

from .snc_reader import SyncFile
from .header_reader import GenericHeader
from .fast.keytree import CKeyTree
from .utils import b_to_utf8, b_to_i, filetime_to_datetime

EEG_TYPE_GUID = UUID('ca0b0790-d795-11d0-af32-00a0245b54a5')
EEG_SCHEMAS = [3]

class HeadboxType(Enum):
    UNKNOWN              = 0
    EEG32                = 1
    IOM                  = 2
    EEG128               = 3
    AMB28                = 4
    PSG                  = 5
    EMU36                = 6
    AVSTIM               = 7
    MOBEE24              = 8
    MOBEE32              = 9
    EP16000_MAIN         = 10
    EP16000_AVSTIM       = 11
    EMU72                = 12
    EMU72_A              = 13
    CONNEX_BRAIN_MONITOR = 14
    TREX                 = 15
    EEG128_MULTIPLEX     = 16
    EMU40                = 17
    NEUROPATH            = 18
    EEG32U               = 19
    QUANTUM              = 20
    NEUROLINK_IP         = 21
    NETLINK              = 22
    NETLINK_TRAVELER     = 23
    COMET                = 24
    COMET_PLUS           = 25
    V32                  = 26
    V44                  = 27
    BRAIN_MONITOR        = 28
    EMBLA_NDX            = 29
    EMBLA_SDX            = 30
    BRAIN_MONITOR_IX     = 31
    EMBLETTA_MPR         = 32
    EDF                  = 33
    CAIN                 = 34
    REEG                 = 35
    
def _read_eeg_records(f: BufferedReader, sync_file: SyncFile = None):
    while True:
        rlength = b_to_i(f.read(1))
        if rlength == 0xff: # 1 byte burned by AfxReadStringLength (0xFF)
            rlength = b_to_i(f.read(2))
        if rlength == 0xffff: # 1+2=3 total bytes burned by AfxReadStringLength (0xFF 0xFF 0xFF)
            rlength = b_to_i(f.read(4))

        record = f.read(rlength)
        if len(record) == 0:
            return

        try:
            # record_json = convert_excel_to_json(record)
            record_json = CKeyTree.create_from_string(b_to_utf8(record), length=-1, sync_file=sync_file)
        except Exception as e:
            import warnings

            warnings.warn(f"{e} -- {record}")
            breakpoint()
            continue

        yield record_json
        
def read_eeg_file(file_path: str, sync_file: SyncFile = None, verbose=False):
    """Reads EEG file and returns a dict.

    Args:
        file_path (str): file to open
        sync_file (SyncFile, optional): SyncFile object for converting samplestamps to datetime, adding adjacent <name>TimeUtc fields
        verbose (bool, optional): Set to True to print EEG file as json

    Returns:
        CKeyTree: EEG file record with patient and study info
    """
    f: BufferedReader
    with open(file_path, "rb") as f:
        # read generic header
        gheader = GenericHeader.from_file(f)
        gheader.validate_guid(EEG_TYPE_GUID)
        gheader.validate_schemas(EEG_SCHEMAS)

        # read eeg record (only one patient record per eeg file)
        eeg_record = list(_read_eeg_records(f, sync_file=sync_file))[0]
        
        # replace XLCreationTime CLuser hex string with a datatime
        try:
            # Convert XLCreationTime from hex string to datetime
            # XLCreationTime is a little endian hex string representing a FILETIME
            hex_str = eeg_record['Study'][0]['XLCreationTime']
            hex_bytes = bytes.fromhex(hex_str)
            filetime_int64 = struct.unpack('<Q', hex_bytes)[0]
            dt = filetime_to_datetime(filetime_int64)
            
            dt_format = '%Y-%m-%d %H:%M:%S.%f%z'
            dt_str = dt.strftime(dt_format)
            eeg_record['Study'][0]['XLCreationTime'] = dt_str
            
            # ensure it can be read back as well
            dt_check = datetime.strptime(dt_str, dt_format)
            assert dt_check == dt
        except Exception as e:
            raise e
        
        # replace HeadboxType int with HeadboxType enum
        try:
            hb_type_int = eeg_record['Study'][0]['Headbox']['HB0']['HBType']
            eeg_record['Study'][0]['Headbox']['HB0']['HBType'] = HeadboxType(hb_type_int).name
            eeg_record['Study'][0]['HeadboxType'] = HeadboxType(hb_type_int).name
        except Exception as e:
            raise e

        if verbose:
            print(json.dumps(eeg_record, indent=2))
        return eeg_record