from functools import partial
from io import BufferedReader
from uuid import UUID

import numpy as np
import struct

from .header_reader import GenericHeader


SNC_TYPE_GUID = UUID('6086a9d2-60af-11d3-9860-00104b75c151')
SNC_SCHEMAS = {0, 1}  # set containing implemented schemas


def filetime_to_npdatetime64(filetimes: np.ndarray) -> np.datetime64:
    """Windows FileTime (64-bit) to datetime
    Note: this handles entire arrays with np.datetime64, please see
    filetime_to_datetime() in module .util for the minimal single-converter
    that uses only python datetime.datetime

    Args:
        filetimes (np.ndarray): 100-ns tick counts since 1601-01-01
            Note: not leap second aware, FileTime ignores whole concept

    Returns:
        np.datetime64: UTC datetime64
    """
    elapseds = np.round(filetimes / 10).astype('timedelta64[us]')
    return (elapseds + np.datetime64('1601-01-01')).astype('datetime64[ns]')


class SyncFile:
    """Encapsulates SNC synchronization files, and allows for interpolation
    of arbitrary samplestamps to arbitrary Windows FileTimes by linear interp.
    Also converts to np.datetime64.
    """
    def __init__(self, samplestamps, sampletimes):
        self.samplestamps = samplestamps
        self.sampletimes = sampletimes

    def _interp_stamps_raw(self, samplestamp):
        return np.interp(samplestamp, self.samplestamps, self.sampletimes)

    def interp_stamps(self, samplestamp):
        return filetime_to_npdatetime64(self._interp_stamps_raw(samplestamp))

    @classmethod
    def from_file(cls, f: BufferedReader):
        header = GenericHeader.from_file(f)
        header.validate_guid(SNC_TYPE_GUID)
        header.validate_schemas(SNC_SCHEMAS)

        samplestamps = []
        sampletimes = []

        SNC_ENCODING = "<lQ"
        # note: 16 byte reads for alignment, even though data is 12 bytes
        for entry in iter(partial(f.read, struct.calcsize(SNC_ENCODING)), b''):
            (sampleStamp, sampleTime) = \
                struct.unpack_from(SNC_ENCODING, entry)

            samplestamps.append(sampleStamp)
            sampletimes.append(sampleTime)

        samplestamps = np.array(samplestamps, dtype="float")
        sampletimes = np.array(sampletimes, dtype="float")

        return cls(samplestamps, sampletimes)
