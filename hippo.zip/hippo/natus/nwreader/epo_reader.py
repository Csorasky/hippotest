from __future__ import annotations

from enum import Enum
import struct
import numpy as np
import olefile
import os
from .utils import b_to_ascii, b_to_utf8

class ChannelType(Enum):
    CH_HEADER = 0
    CH_STAGE = 1
    CH_MARK = 2
    CH_EVENT_SUMMARY = 3
    CH_DATA_SUMMARY = 4
    CH_BYTE_DATA = 5
    CH_DOUBLE_DATA = 6
    CH_SHORT_DATA = 7
    CH_CSA_DATA = 8
    CH_AEEG_DATA = 9
    CH_QEEG_DATA = 10
    CH_EPR_DATA = 11
    CH_ENVELOPE_DATA = 12
    CH_SPECTRALENTROPY_DATA = 13
    CH_SPECTRALEDGE_DATA = 14
    CH_ALPHAVARIABILITY_DATA = 15
    CH_BURSTSUPPRESSION_DATA = 16
    CH_AMPLITUDE_DATA = 17

class StreamName(Enum):
    STM_SCHEMA = 'Schema'
    STM_STUDYINFO = 'StudyInfo'
    STM_EPOCHINFO = 'EpochInfo'
    STM_RAWDATA = 'ChannelRawData'
    STM_CHANNELINFO = 'ChannelInfo'
    STM_SUMMARY = 'Summary'
    STM_BYTE_DATA = 'ByteData'
    STM_SHORT_DATA = 'ShortData'
    STM_DOUBLE_DATA = 'DoubleData'
    STM_SLEEP_EVENT = 'SleepEvent'
    STM_CSA_DATA = 'CSAData'
    STM_AEEG_DATA = 'AEEGData'
    STM_QEEG_DATA = 'QEEGData'
    STM_MANUAL_AUTO_DATA = 'ManualAutoData'
 
class DataType(Enum):
    DATA_EKG = 1
    DATA_O2SAT = 2
    DATA_PULSERATE = 3
    DATA_BODYPOSITION = 4
    DATA_CPAP = 5
    DATA_CO2 = 6
    DATA_PH = 7
    DATA_SUPPLEMENTALO2 = 8
    DATA_AEEG = 9
    DATA_QEEG = 10
    DATA_THERM = 11
    DATA_FLOW = 12
    DATA_CPAPFLOW = 13
    DATA_PRESSURE = 14
    DATA_DC = 15
    DATA_RES = 16
    DATA_ACTIVITY = 17
    DATA_RESP_RATE = 18
    DATA_PTT = 19
    DATA_DERIVED = 20
    DATA_PHASE = 21
    DATA_ECG_HEARTRATE = 22
    DATA_RR_HEARTRATE_INTERVAL = 23
    DATA_MIC = 24
    DATA_ENVELOPE = 25
    DATA_SPECTRALENTROPY = 26
    DATA_SPECTRALEDGE = 27
    DATA_ALPHAVARIABILITY = 28
    DATA_BURSTSUPPRESSION_IBI = 29
    DATA_BURSTSUPPRESSION_BURST = 30
    DATA_BURSTSUPPRESSION_SUPPRESSION = 31
    DATA_AMPLITUDE_MINIMUM = 32
    DATA_AMPLITUDE_AVERAGE = 33
    DATA_AMPLITUDE_MAXIMUM = 34
    DATA_CSA_DSA = 35

class SummaryType(Enum):
    SUMMARY_COUNT = 1
    SUMMARY_DURATION = 2
    SUMMARY_AVERAGE = 3
    SUMMARY_MIN = 4
    SUMMARY_MAX = 5
    SUMMARY_POSITION = 6
    SUMMARY_CPAP_INSPIRATORY = 7
    SUMMARY_CPAP_EXSPIRATORY = 8
    SUMMARY_BREATH_RATE = 9
    SUMMARY_SUPPLEMENTAL_O2 = 10
    SUMMARY_ASV_OTHER = 11
    SUMMARY_SPECTRAL = 12

class EventRepType(Enum):
    EVENT_COUNT = 1
    EVENT_DURATION = 2
    EVENT_AMPLITUDE_MAX = 3
    EVENT_AMPLITUDE_AVG = 4
    EVENT_AMPLITUDE_MIN = 5
    
class SleepStages(Enum):
    WAKE = 0
    N1 = 1
    N2 = 2
    N3 = 3
    N4 = 4
    REM = 5
    MOVEMENT = 6
    UNSCORABLE = 7
    UNSCORED = 8

class ChannelInfo():
    """Represents the two additional ChannelInfo stream types specified in the file specification.
    The spec incorrectly indicates that ChannelInfo streams are either "Basic", "Data Summary",
    or "Event Summary" subtypes, with the latter two containing additional bytes beyond the Basic.
    
    However in practice, the Data Summary fields are instead included in a separate "Summary" stream,
    and the Event Summary fields are instead included in a separate "SleepEvent" stream.
    
    These two streams are mutually exclusive in any single storage, but always appear alongside a
    ChannelInfo stream.
    TODO: determine if the above statement is based on schema version.
    """
    def __init__(self, channelType: ChannelType):
        self.channelType = channelType

class ChannelInfoBasic():
    '''This class has a constructor which takes a bytes object of the ChannelInfo stream.
        It has the following fields:
            friendlyName,
            channelType
            startEpoch
            endEpoch
            hidden
            creator
            password
            description'''
    def __init__(self, channelInfo_b: bytes, storageName: str, verbose: bool = False):
        self.bytes_all = channelInfo_b
        self.storage_name = storageName
        self.verbose = verbose
        self.bytes_basic = None
        
        # ChannelInfoBasic fields
        self.friendlyName = None # The human readable channel name
        self.channelType = None  # The type of channel (Header, Staging Set, Marking Set, Event Summary, Data Summary) => see ChannelType
        self.startEpoch = None   # Unused
        self.endEpoch = None     # Unused
        self.hidden = None       # Determines whether or not the channel is hidden
        self.creator = None      # Unused (but would appear that it is supposed to be the name of the person who created the channel)
        self.password = None     # Password used for protecting channels from unwanted changes
        self.description = None  # Unused (intended as a text description of the channel)
        
        # parse the basic ChannelInfo section
        channelInfo_dict = self.read_channelInfo_basic(channelInfo_b, storageName)
        self.friendlyName = channelInfo_dict['friendlyName']
        self.channelType = channelInfo_dict['channelType']
        self.startEpoch = channelInfo_dict['startEpoch']
        self.endEpoch = channelInfo_dict['endEpoch']
        self.hidden = channelInfo_dict['hidden']
        self.creator = channelInfo_dict['creator']
        self.password = channelInfo_dict['password']
        self.description = channelInfo_dict['description']
        
        # store the bytes of the ChannelInfo Basic section
        self.bytes_basic = channelInfo_dict['bytes_basic']
        
    def read_channelInfo_basic(self, stream_b: bytes, storage_name: str) -> dict:
        """Read a Basic ChannelInfo stream in an EPO file.

        Args:
            stream_b (bytes): Bytes of the stream

        Returns:
            dict: A dictionary of the stream fields
        """
        # Sizing: ChannelInfo contains the following
        #   - ?? byte (variable) FriendlyName BSTR (first 4 bytes are the BSTR length)
        #   - 4 byte ChannelType int
        #   - 4 byte StartEpoch int
        #   - 4 byte EndEpoch int
        #   - 2 byte Hidden int (variant_bool)
        #   - ?? byte (variable) Creator BSTR (first 4 bytes are the BSTR length)
        #   - ?? byte (variable) Password BSTR (first 4 bytes are the BSTR length)
        #   - ?? byte (variable) Description BSTR (first 4 bytes are the BSTR length)
        IDX_FRIENDLY_NAME_SIZE = 0
        IDX_FRIENDLY_NAME = IDX_FRIENDLY_NAME_SIZE + 4
        
        # get the FriendlyName length (4 bytes)
        idx_start = IDX_FRIENDLY_NAME_SIZE
        idx_end = IDX_FRIENDLY_NAME
        (friendlyName_len,) = struct.unpack('<I', stream_b[idx_start:idx_end])
        
        # define the struct format for the ChannelInfo bytes now that we know the CurrentStageName length
        STRUCT_PART1 = '<I' + '{}s'.format(friendlyName_len) + 'IIIH'
        size_part1 = struct.calcsize(STRUCT_PART1)
        
        # get the Creator length (4 bytes)
        idx_start = size_part1
        idx_end = idx_start + 4
        (creator_len,) = struct.unpack('<I', stream_b[idx_start:idx_end])
        STRUCT_PART1_PART2 = STRUCT_PART1 + 'I' + '{}s'.format(creator_len)
        size_part1_part2 = struct.calcsize(STRUCT_PART1_PART2)
        
        # get the Password length (4 bytes)
        idx_start = size_part1_part2
        idx_end = idx_start + 4
        (password_len,) = struct.unpack('<I', stream_b[idx_start:idx_end])
        STRUCT_PART1_PART2_PART3 = STRUCT_PART1_PART2 + 'I' + '{}s'.format(password_len)
        size_part1_part2_part3 = struct.calcsize(STRUCT_PART1_PART2_PART3)
        
        # get the Description length (4 bytes)
        idx_start = size_part1_part2_part3
        idx_end = idx_start + 4
        (description_len,) = struct.unpack('<I', stream_b[idx_start:idx_end])
        STRUCT_PART1_PART2_PART3_PART4 = STRUCT_PART1_PART2_PART3 + 'I' + '{}s'.format(description_len)
        size_part1_part2_part3_part4 = struct.calcsize(STRUCT_PART1_PART2_PART3_PART4)
        
        # ensure that all bytes are being read
        if len(stream_b) != size_part1_part2_part3_part4 and self.verbose:
            print(f'WARNING: ChannelInfo remaining {len(stream_b)-size_part1_part2_part3_part4} bytes not fully read in {storage_name}/ChannelInfo')
        
        # unpack the EpochInfo bytes into a dict
        keys = ['friendlyName_len', 'friendlyName',
                'channelType',
                'startEpoch',
                'endEpoch',
                'hidden',
                'creator_len', 'creator',
                'password_len', 'password',
                'description_len', 'description']
        values = struct.unpack(STRUCT_PART1_PART2_PART3_PART4, stream_b[0:size_part1_part2_part3_part4])
        channelInfo = dict(zip(keys, values))
        
        # convert channelType int to string
        channelInfo['channelType'] = ChannelType(channelInfo['channelType'])
        
        # convert CurrentStageName bytes to string
        channelInfo['friendlyName'] = b_to_ascii(channelInfo['friendlyName'])
        channelInfo['creator'] = b_to_ascii(channelInfo['creator'])
        channelInfo['password'] = b_to_ascii(channelInfo['password'])
        channelInfo['description'] = b_to_ascii(channelInfo['description'])
        
        # indicate password presence
        if channelInfo['password'] != '':
            print('WARNING: password is not empty ({})'.format(channelInfo['password']))
        
        # store the bytes of the ChannelInfo Basic section
        channelInfo['bytes_basic'] = stream_b[0:size_part1_part2_part3_part4]
        
        return channelInfo

class ChannelInfoDataSummary(ChannelInfo):
    BYTE_LEN = 8
    
    def __init__(self, stream_b: bytes):
        super().__init__(ChannelType.CH_DATA_SUMMARY)
        self.bytes = stream_b
        
        # file spec indicates 8 bytes however in practice we see 12 bytes
        assert (len(stream_b) == ChannelInfoDataSummary.BYTE_LEN or len(stream_b) == ChannelInfoDataSummary.BYTE_LEN + 4)
        
        # parse the 8 bytes the file spec indicates
        dataSummary_dict = self.read_channelInfo_dataSummary(self.bytes)
        self.dataType = dataSummary_dict['dataType']
        self.summaryType = dataSummary_dict['summaryType']

    def read_channelInfo_dataSummary(self, dataSummary_b: bytes) -> dict:
        """Read additional DataSummary info based on the Basic ChannelInfo stream in an EPO file.

        Args:
            dataSummary_b (bytes): Bytes of the stream

        Returns:
            dict: a dictionary of the deserialized stream fields
        """
        
        # Sizing: DATASUMMARY contains the following
        #   - 4 byte DataType int
        #   - 4 byte SummaryType int
        
        # define the struct format for the stream bytes
        STRUCT_DATASUMMARY = '<II'
        size = struct.calcsize(STRUCT_DATASUMMARY)
        
        # unpack the bytes into a dict
        keys = ['dataType','summaryType']
        values = struct.unpack(STRUCT_DATASUMMARY, dataSummary_b[0:size])
        dataSummary = dict(zip(keys, values))
        
        # convert dataType and summaryType ints to enums
        dataSummary['dataType'] = DataType(dataSummary['dataType'])
        dataSummary['summaryType'] = SummaryType(dataSummary['summaryType'])
        
        return dataSummary

    def __str__(self) -> str:
        return 'ChannelInfoDataSummary: dataType={}, summaryType={}'.format(self.dataType, self.summaryType)

class ChannelInfoEventSummary(ChannelInfo):
    
    def __init__(self, stream_b: bytes):
        super().__init__(ChannelType.CH_EVENT_SUMMARY)
        self.bytes = stream_b
        self.rep = None
        self.typeID = None
        self.eventTypeDesc = None
        
        # parse the 8 bytes the file spec indicates
        eventSummary_dict = self.read_channelInfo_eventSummary(self.bytes)
        self.rep = eventSummary_dict['rep']
        self.typeID = eventSummary_dict['typeID']
        self.eventTypeDesc = eventSummary_dict['eventTypeDesc']

    def read_channelInfo_eventSummary(self, stream_b: bytes) -> dict:
        """Read additional EventSummary info based on the Basic ChannelInfo stream in an EPO file.

        Args:
            eventSummary_b (bytes): Bytes of the stream

        Returns:
            dict: a dictionary of the deserialized stream fields
        """
        
        # Sizing: DATASUMMARY contains the following
        #   - 4 byte Rep int
        #   - ? byte TypeID BSTR (first 4 bytes are the BSTR length)
        #   - ? byte EventTypeDesc BSTR (first 4 bytes are the BSTR length)
        IDX_TYPEID_SIZE = 4
        IDX_TYPEID = IDX_TYPEID_SIZE + 4
        
        # get the TypeID length (4 bytes)
        idx_start = IDX_TYPEID_SIZE
        idx_end = IDX_TYPEID
        (typeID_len,) = struct.unpack('<I', stream_b[idx_start:idx_end])
        
        # define the struct format for the first two parts of the stream bytes
        STRUCT_PART1_PART2 = '<I' + ('I' + '{}s'.format(typeID_len))
        size_part1_part2 = struct.calcsize(STRUCT_PART1_PART2)
        
        # get the EventTypeDesc length (4 bytes)
        idx_start = size_part1_part2
        idx_end = idx_start + 4
        (eventTypeDesc_len,) = struct.unpack('<I', stream_b[idx_start:idx_end])
        STRUCT_PART1_PART2_PART3 = STRUCT_PART1_PART2 + 'I' + '{}s'.format(eventTypeDesc_len)
        size_part1_part2_part3 = struct.calcsize(STRUCT_PART1_PART2_PART3)
        
        # ensure that all bytes are being read
        if len(stream_b) != size_part1_part2_part3:
            print('WARNING: EventSummary bytes not fully read')
            
        # unpack the EventSummary bytes into a dict
        keys = ['rep',
                'typeID_len', 'typeID',
                'eventTypeDesc_len', 'eventTypeDesc']
        values = struct.unpack(STRUCT_PART1_PART2_PART3, stream_b[0:size_part1_part2_part3])
        eventSummary = dict(zip(keys, values))
        
        # convert rep int to string
        eventSummary['rep'] = EventRepType(eventSummary['rep'])
        
        # convert additional field bytes to string
        eventSummary['typeID'] = b_to_ascii(eventSummary['typeID'])
        eventSummary['eventTypeDesc'] = b_to_ascii(eventSummary['eventTypeDesc'])
        
        return eventSummary
    
    def __str__(self) -> str:
        return 'ChannelInfoEventSummary: rep={}, typeID={}, eventTypeDesc={}'.format(self.rep, self.typeID, self.eventTypeDesc)
    
class ChannelRawData():
    def __init__(self, stream_b: bytes):
        self.bytes = stream_b
        
class ChannelRawDataUnknown(ChannelRawData):
    def __init__(self, stream_b: bytes):
        super().__init__(stream_b)
        #convert bytes to ndarray of bytes
        self.values: np.ndarray = self.read(self.bytes)
        
    def read(self, rawdata_b: bytes) -> np.ndarray:
        """Read the ChannelRawData as bytes from the stream of an EPO file.

        Args:
            rawdata_b (bytes): Bytes of the ChannelRawData

        Returns:
            values: an ndarray of bytes
        """
        STRUCT_DATA = '<{}B'.format(len(rawdata_b))
        return np.array(struct.unpack(STRUCT_DATA, rawdata_b))

    def as_bytes(self) -> np.ndarray:
        return self.values
    
class ChannelRawDataByte(ChannelRawData):
    def __init__(self, stream_b: bytes):
        super().__init__(stream_b)
        self.values: np.ndarray = self.read(self.bytes)
        
    def read(self, rawdata_b: bytes) -> np.ndarray:
        """Read the ChannelRawData as bytes from the stream of an EPO file.

        Args:
            rawdata_b (bytes): Bytes of the ChannelRawData

        Returns:
            values: an ndarray of bytes
        """
        STRUCT_DATA = '<{}B'.format(len(rawdata_b))
        return np.array(struct.unpack(STRUCT_DATA, rawdata_b))
    
    def as_sleep_stages(self) -> np.ndarray[str]:
        return np.array([SleepStages(i).name for i in self.values])
    
    def as_bytes(self) -> np.ndarray:
        return self.values
    
class ChannelRawDataShort(ChannelRawData):
    def __init__(self, stream_b: bytes):
        super().__init__(stream_b)
        self.values: np.ndarray[np.short] = self.read(self.bytes)
        
    def read(self, rawdata_b: bytes) -> np.ndarray:
        """Read the ChannelRawData as shorts from the stream of an EPO file.

        Args:
            rawdata_b (bytes): Bytes of the ChannelRawData

        Returns:
            values: an ndarray of shorts
        """
        short_size = struct.calcsize('H')
        num_shorts = int(len(rawdata_b) / short_size)
        STRUCT_DATA = '<{}H'.format(num_shorts)
        return np.array(struct.unpack(STRUCT_DATA, rawdata_b))
    
    def as_shorts(self) -> np.ndarray[np.short]:
        return self.values

class ChannelRawDataDouble(ChannelRawData):
    def __init__(self, stream_b: bytes):
        super().__init__(stream_b)
        self.values: np.ndarray[np.double] = self.read(self.bytes)
        
    def read(self, rawdata_b: bytes) -> np.ndarray:
        """Read the ChannelRawData as doubles from the stream of an EPO file.

        Args:
            rawdata_b (bytes): Bytes of the ChannelRawData

        Returns:
            values: an ndarray of doubles
        """
        double_size = struct.calcsize('d')
        num_doubles = int(len(rawdata_b) / double_size)
        STRUCT_DATA = '<{}d'.format(num_doubles)
        return np.array(struct.unpack(STRUCT_DATA, rawdata_b))
    
    def as_doubles(self) -> np.ndarray[np.double]:
        return self.values
    
class EpochInfo():
    def __init__(self, epochInfo_b: bytes):
        self.bytes = epochInfo_b
        self.epochLength = None           # Epoch length for the study (in seconds)
        self.epochsAfterLightsOff = None  # Number of epochs in the study (**from LIGHTS OFF** to end of study)
        self.currentEpoch = None          # The current epoch being looked at while reviewing the study
        self.startTime = None             # The sample stamp corresponding to the start of epoch #1 in the study
        self.sleepTimeBase = None         # The timebase used for sleep studies (obsolete)
        self.valid = None                 # The valid flag to determine whether or not all data in the file is complete.
        self.creationTime = None          # Unused
        self.currentStageName = None      # The “friendly name” of the current staging set being written to/read from.
        self.segmentStartStamp = None     # Unused (originally intended to be used with merging and auto-recovery)
        self.studyStartStamp = None       # The sample stamp corresponding to the start of the study
        self.epochsBeforeLightsOff = None # The number of epochs in the study **BEFORE LIGHTS OFF**
        self.recoverEpochOffset = None    # Unused (another variable intended for use with merging and auto-recovery)
        self.nextFileNum = None           # Next file number
        
        epochInfo_dict = self.read_GlobalHeader_epochInfo(epochInfo_b)
        
        self.epochLength = epochInfo_dict['epochLength']
        self.epochsAfterLightsOff = epochInfo_dict['totalEpochs']
        self.currentEpoch = epochInfo_dict['currentEpoch']
        self.startTime = epochInfo_dict['startTime']
        self.sleepTimeBase = epochInfo_dict['sleepTimeBase']
        self.valid = epochInfo_dict['valid']
        self.creationTime = epochInfo_dict['creationTime']
        # ignore epochInfo_dict['currentStageName_len']
        self.currentStageName = epochInfo_dict['currentStageName']
        self.segmentStartStamp = epochInfo_dict['segmentStartStamp']
        self.studyStartStamp = epochInfo_dict['studyStartStamp']
        self.epochsBeforeLightsOff = epochInfo_dict['epochOffset']
        self.recoverEpochOffset = epochInfo_dict['recoverEpochOffset']
        self.nextFileNum = epochInfo_dict['nextFileNum']
        
    def __str__(self) -> str:
        return 'EpochInfo: epochLength={}, totalEpochs={}, currentEpoch={}, startTime={}, sleepTimeBase={}, valid={}, creationTime={}, currentStageName={}, segmentStartStamp={}, studyStartStamp={}, epochOffset={}, recoverEpochOffset={}, nextFileNum={}'.format(self.epochLength, self.epochsAfterLightsOff, self.currentEpoch, self.startTime, self.sleepTimeBase, self.valid, self.creationTime, self.currentStageName, self.segmentStartStamp, self.studyStartStamp, self.epochsBeforeLightsOff, self.recoverEpochOffset, self.nextFileNum)
        
    def read_GlobalHeader_epochInfo(self, epochInfo_b: bytes) -> dict:
        """Read the EpochInfo from the GlobalHeader stream of an EPO file.

        Args:
            epochInfo_b (bytes): Bytes of the EpochInfo

        Returns:
            dict: A dictionary of the EpochInfo fields
        """
        # Sizing: EpochInfo contains the following
        #   - 25 known bytes
        #   - 4 byte int containing the length of the CurrentStageName BSTR
        #   - ?? byte (variable) CurrentStageName BSTR
        #   - 20 known bytes
        EPOCHINFO_IDX_CURR_STAGE_NAME_SIZE = 25
        EPOCHINFO_IDX_CURR_STAGE_NAME = EPOCHINFO_IDX_CURR_STAGE_NAME_SIZE + 4
        
        # get the CurrentStageName length (4 bytes)
        idx_start = EPOCHINFO_IDX_CURR_STAGE_NAME_SIZE
        idx_end = EPOCHINFO_IDX_CURR_STAGE_NAME
        (currentStageName_len,) = struct.unpack('<I', epochInfo_b[idx_start:idx_end])
        
        # define the struct format for the EpochInfo bytes now that we know the CurrentStageName length
        STRUCT_GLOBALHEADER_EPOCHINFO = '<IIIIIBI' + 'I' + '{}s'.format(currentStageName_len) + 'IIIII'
        epochinfo_total_size = struct.calcsize(STRUCT_GLOBALHEADER_EPOCHINFO)
        
        # unpack the EpochInfo bytes into a dict
        keys = ['epochLength','totalEpochs','currentEpoch','startTime','sleepTimeBase','valid','creationTime',
                'currentStageName_len',
                'currentStageName',
                'segmentStartStamp','studyStartStamp','epochOffset','recoverEpochOffset','nextFileNum']
        values = struct.unpack(STRUCT_GLOBALHEADER_EPOCHINFO, epochInfo_b[0:epochinfo_total_size])
        epochInfo = dict(zip(keys, values))
        
        # convert CurrentStageName bytes to string
        epochInfo['currentStageName'] = b_to_ascii(epochInfo['currentStageName'])
        
        return epochInfo

class GlobalHeader():
    def __init__(self, ole: olefile.OleFileIO, verbose: bool = False):
        self.epochInfo = None
        self.studyInfo = None
        self.schema = None
        
        # parse the GlobalHeader stream
        epochInfo_b: bytes = ole.openstream('GlobalHeader/EpochInfo').read()
        self.epochInfo = EpochInfo(epochInfo_b)
        if verbose: print('epochInfo: ', self.epochInfo)
        
        # parse the StudyInfo stream
        studyInfo_b: bytes = ole.openstream('GlobalHeader/StudyInfo').read()
        self.studyInfo = self.read_GlobalHeader_studyInfo(studyInfo_b)
        if verbose: print('studyInfo: ', self.studyInfo)
        
        # parse the Schema stream
        schema_b: bytes = ole.openstream('GlobalHeader/Schema').read()
        self.schema = self.read_GlobalHeader_schema(schema_b)
        if verbose: print('schema: ', self.schema)

    def read_GlobalHeader_studyInfo(self, studyInfo_b: bytes) -> dict:
        # TODO: spec says that this is actually 9 bytes GUID, but am questioning how to parse this
        STRUCT_GLOBALHEADER_STUDYINFO = '<16s16s'
        studyinfo_total_size = struct.calcsize(STRUCT_GLOBALHEADER_STUDYINFO)
        keys = ['studyGuid', 'patientGuid']
        values = struct.unpack(STRUCT_GLOBALHEADER_STUDYINFO, studyInfo_b[0:studyinfo_total_size])
        studyInfo = dict(zip(keys, values))
        
        # convert studyGuid and patientGuid bytes to string
        studyInfo['studyGuid'] = b_to_utf8(studyInfo['studyGuid'])
        studyInfo['patientGuid'] = b_to_utf8(studyInfo['patientGuid'])
        
        return studyInfo

    def read_GlobalHeader_schema(self, schema_b: bytes) -> dict:
        STRUCT_GLOBALHEADER_SCHEMA = '<IIII'
        schema_total_size = struct.calcsize(STRUCT_GLOBALHEADER_SCHEMA)
        keys = ['Major', 'Minor', 'Revision', 'Build']
        values = struct.unpack(STRUCT_GLOBALHEADER_SCHEMA, schema_b[0:schema_total_size])
        schema = dict(zip(keys, values))

        return schema

class EpoStorage():
    def __init__(self, ole: olefile.OleFileIO, storage_name: str, verbose: bool = False):
        self.ole: olefile.OleFileIO = ole
        self.name: str = storage_name
        self.streams: dict = {}
        self.verbose: bool = verbose
        self.channelInfoBasic: ChannelInfoBasic = None
        self.channelInfoExtra: ChannelInfo = None
        self.channelType: ChannelType = None
        self.channelRawData: ChannelRawData = None

        # all storages have a Basic ChannelInfo stream
        channelInfo_b = self.ole.openstream([self.name, StreamName.STM_CHANNELINFO.value]).read()
        self.channelInfoBasic = ChannelInfoBasic(channelInfo_b, self.name, verbose)
        
        # get the channel type
        self.channelType = self.channelInfoBasic.channelType
        
        # parse additional streams based on channelType
        self.channelInfoExtra = self._create_channel_info_from_type(self.channelType)
        if self.channelInfoExtra == None and self.verbose:
            print(f'{self.name}.channelType = {self.channelType.name}, only a basic ChannelInfo is supported.')
        
        # parse the raw data stream based on channelType
        self.channelRawData = self._create_rawdata_from_type(self.channelType)
            
    def _create_channel_info_from_type(self, channelType: ChannelType):
        target_stream: StreamName = None
        
        # parse additional streams based on channelType
        if channelType == ChannelType.CH_DATA_SUMMARY:
            target_stream = StreamName.STM_SUMMARY
        elif channelType == ChannelType.CH_EVENT_SUMMARY:
            target_stream = StreamName.STM_SLEEP_EVENT    
        else:
            # other ChannelInfo types not described in file spec
            return None
            
        # ensure target stream exists in this storage
        assert [self.name, target_stream.value] in self.ole.listdir(streams=True, storages=False)
            
        # read the stream
        stream_b = self.ole.openstream([self.name, target_stream.value]).read()
        
        # parse and return the extended ChannelInfo stream
        if channelType == ChannelType.CH_DATA_SUMMARY:
            return ChannelInfoDataSummary(stream_b) 
        elif channelType == ChannelType.CH_EVENT_SUMMARY:
            return ChannelInfoEventSummary(stream_b)
        else:
            raise Exception(f'Should not get here for channel type: {channelType.name}')
        
    def _create_rawdata_from_type(self, channelType: ChannelType):
        target_stream: StreamName = StreamName.STM_RAWDATA
        
        # ensure there is also a "RawData" stream
        if [self.name, target_stream.value] not in self.ole.listdir(streams=True, storages=False):
            return None
        
        # read the stream
        rawdata_b = self.ole.openstream([self.name, target_stream.value]).read()
        
        if channelType in [ChannelType.CH_DATA_SUMMARY, ChannelType.CH_EVENT_SUMMARY, ChannelType.CH_DOUBLE_DATA]:
            # return double stream
            return ChannelRawDataDouble(rawdata_b)
        elif channelType in [ChannelType.CH_SHORT_DATA]:
            # return short stream
            return ChannelRawDataShort(rawdata_b)
        elif channelType in [ChannelType.CH_BYTE_DATA, ChannelType.CH_STAGE, ChannelType.CH_MARK]:
            # return byte stream
            return ChannelRawDataByte(rawdata_b)
        else:
            print(f'WARNING: returning generic byte structure for RawData where channel type is {channelType.name}')
            return ChannelRawDataUnknown(rawdata_b)
    
    def add_stream(self, stream_name: StreamName):
        stream_b = self.ole.openstream([self.name, stream_name.value]).read()
        self.streams[stream_name] = stream_b

class EpoFile():
    def __init__(self, globalHeader: GlobalHeader, storages: dict[str, EpoStorage]):
        self.header: GlobalHeader = globalHeader
        self.storages: dict[str, EpoStorage] = storages

def read_epo_file(epo_path: str, verbose: bool = False):
    """Read all the storages into a dict of EpoStorage objects.

    Args:
        epo_path (str): path to the EPO file
        verbose (bool, optional): bool to print verbose statements. Defaults to False.

    Returns:
        dict: the dict of EpoStorage objects, each with their own streams
    """
    epo_path = os.path.abspath(epo_path)
    assert(olefile.isOleFile(epo_path))
    ole = olefile.OleFileIO(epo_path)
    
    print('Reading GlobalHeader from EPO file: {}'.format(epo_path))
    epo_global_header = GlobalHeader(ole, verbose=verbose)
    
    # first create a dict of all the storages and their streams
    # we want sibling streams of the same storage to be able to find each other
    storage_dict: dict[str, EpoStorage] = {}
    for stream_path in ole.listdir(streams=True, storages=False):
        # stream_path is a tuple of (storage, stream)
        assert len(stream_path) == 2
        storage_str = stream_path[0]
        stream_str = stream_path[-1]
        stream = StreamName(stream_str)
        
        # skip GlobalHeader streams: [Schema, StudyInfo, EpochInfo]
        if stream in [StreamName.STM_SCHEMA, StreamName.STM_STUDYINFO, StreamName.STM_EPOCHINFO]:
            continue
        
        # add the storage to the storage_dict if it doesn't exist
        if storage_str not in storage_dict:
            storage_dict[storage_str] = EpoStorage(ole, storage_str, verbose=verbose)
        
        # if this is ChannlInfo, then we will parse it now
        if stream in [StreamName.STM_CHANNELINFO,
                      StreamName.STM_SUMMARY, StreamName.STM_SLEEP_EVENT,
                      StreamName.STM_BYTE_DATA, StreamName.STM_SHORT_DATA, StreamName.STM_DOUBLE_DATA,
                      StreamName.STM_RAWDATA]:
            continue # alread accounted for in EpoStorage ctor
        
        # add the stream to the storage
        if verbose:
            print(f"WARNING: ignoring stream: {stream_str}")
        storage_dict[storage_str].add_stream(stream)
    
    return EpoFile(epo_global_header, storage_dict)
