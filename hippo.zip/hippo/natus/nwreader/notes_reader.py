from io import BufferedReader
from uuid import UUID

from .header_reader import GenericHeader
from .fast.keytree import CKeyTree
from .snc_reader import SyncFile
from .utils import b_to_utf8, b_to_i

ENT_TYPE_GUID = UUID('ca0b0793-d795-11d0-af32-00a0245b54a5')
ENT_SCHEMAS = [3]

def _read_ent_records(f: BufferedReader, sync_file: SyncFile = None):
    """Read ent records from file.

    Args:
        f (BufferedReader): file to read from
        sync_file (SyncFile, optional): See read_annotations_file.

    Yields:
        CKeyTree: records from file
    """
    while True:
        _ = f.read(4)  # note type
        rlength = b_to_i(f.read(4)) # record length
        _ = f.read(4)  # previous record length
        _ = f.read(4)  # ID, unused

        record = f.read(rlength - 16)
        if len(record) == 0:
            return

        try:
            record = CKeyTree.create_from_string(b_to_utf8(record), length=-1, sync_file=sync_file)
        except Exception as e:
            import warnings

            warnings.warn(f"{e} -- {record}")
            breakpoint()
            continue

        yield record
        
def read_annotations_file(file_path: str, sync_file: SyncFile = None):
    """Generates annotations from from .ent file.

    Args:
        file_path (str): file to open
        sync_file (SyncFile, optional): SyncFile object for converting samplestamps to datetime, adding adjacent <name>TimeUtc fields.
    """
    with open(file_path, "rb") as f:
        # read generic header
        gheader = GenericHeader.from_file(f)
        gheader.validate_guid(ENT_TYPE_GUID)
        gheader.validate_schemas(ENT_SCHEMAS)
        
        # read ent records
        records = list(_read_ent_records(f, sync_file))
        return records
