from datetime import datetime, timedelta, timezone
from uuid import UUID

import struct


def b_to_i(b: bytes) -> str:
    return int.from_bytes(b, "little")

def b_to_utf8(b: bytes):
    try:
        return b.decode('utf-8')
    except:
        pass
    try:
        return b.decode('latin-1') # superset of ascii, including degree symbol 0xb0
    except:
        pass
    try:
        return b.decode('utf-8', errors='backslashreplace') # serialize as "\xb0" for example
    except Exception as e:
        raise e

def b_to_ascii(b: bytes) -> str:
    try:
        return b.decode('ascii', errors='ignore').replace('\x00', '')
    except Exception as e:
        raise e

def b_to_str(buf: bytes) -> str:
    buf_terminated = buf.split(b'\x00', maxsplit=1)[0]
    return buf_terminated.decode("utf-8")


def b_to_guid(buf: bytes) -> UUID:
    if len(buf) != 16:
        raise ValueError("GUID expected to be 16 bytes, found {}".format(len(buf)))

    # in a Microsoft GUID, the first 64 bits are "reversed" from RFC4122, i.e. little endian
    time_low_le, time_mid_le, time_hi_version_le = struct.unpack("<IHH", buf[:8])

    # the next 64 bits of the GUID is as-specified in RFC4122, i.e. network order aka big endian
    clock_seq_hi_variant, clock_seq_low = struct.unpack(">BB", buf[8:10])

    # the last 48 bits is a uint48
    node = int.from_bytes(buf[10:16], byteorder='big', signed=False)

    return UUID(
        fields=(time_low_le, time_mid_le, time_hi_version_le,
                clock_seq_hi_variant, clock_seq_low, node)
    )


def filetime_to_datetime(filetime: int) -> datetime:
    """Windows FileTime (64-bit) to datetime
    Note: this handles single filetime to single datetime.datetime.
    For the numpy-styled version with np.datetime64, please see
    filetime_to_npdatetime64() in module .snc_reader

    Args:
        filetime (int): 100-ns tick count since 1601-01-01
            Note: not leap second aware, FileTime ignores whole concept

    Returns:
        datetime: datetime.datetime in timezone.utc
    """
    elapsed = timedelta(microseconds=round(filetime / 10))
    return datetime(1601, 1, 1, tzinfo=timezone.utc) + elapsed

def olefiletime_to_datetime(olefiletime: float):
    """Converts an OLE local filetime float to a datetime string.
    Note that these OLE filetimes are not timezone aware, so the datetime
    string is in the local timezone where the study was acquired.

    Args:
        olefiletime (float): The OLE filetime float to convert.

    Returns:
        str: The datetime string in the format '%Y-%m-%d %H:%M:%S.%f', which may
             be rehydrated into a datetime using datetime.strptime.
    """
    base_date = datetime(1899, 12, 30)
    delta_days = timedelta(days=olefiletime)

    dt = base_date + delta_days
    dt_format_local = '%Y-%m-%d %H:%M:%S.%f'
    dt_str = dt.strftime(dt_format_local)
    
    # ensure it can be read back as well
    dt_check = datetime.strptime(dt_str, dt_format_local)
    assert dt_check == dt
    return dt_str