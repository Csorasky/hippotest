SHRT_MAX = 32767

CHANNEL_LABELS_SCHEMA_8 = {
    1: [
        "C3", "C4", "CZ", "F3", "F4", "F7", "F8", "FZ", "FP1", "FP2",
        "FPZ", "O1", "O2", "P3", "P4", "PZ", "T3", "T4", "T5", "T6",
        "AUX1", "AUX2", "AUX3", "AUX4", "AUX5", "AUX6", "AUX7", "AUX8", "PG1", "PG2",
        "A1", "A2",
    ], # EEG32U Type 1
    3: [
        "C1", "C2", "C3", "C4", "C5", "C6", "C7", "C8", "C9", "C10",
        "C11", "C12", "C13", "C14", "C15", "C16", "C17", "C18", "C19", "C20",
        "C21", "C22", "C23", "C24", "C25", "C26", "C27", "C28", "C29", "C30",
        "C31", "C32", "C33", "C34", "C35", "C36", "C37", "C38", "C39", "C40",
        "C41", "C42", "C43", "C44", "C45", "C46", "C47", "C48", "C49", "C50",
        "C51", "C52", "C53", "C54", "C55", "C56", "C57", "C58", "C59", "C60",
        "C61", "C62", "C63", "C64", "C65", "C66", "C67", "C68", "C69", "C70",
        "C71", "C72", "C73", "C74", "C75", "C76", "C77", "C78", "C79", "C80",
        "C81", "C82", "C83", "C84", "C85", "C86", "C87", "C88", "C89", "C90",
        "C91", "C92", "C93", "C94", "C95", "C96", "C97", "C98", "C99", "C100",
        "C101", "C102", "C103", "C104", "C105", "C106", "C107", "C108", "C109", "C110",
        "C111", "C112", "C113", "C114", "C115", "C116", "C117", "C118", "C119", "C120",
        "C121", "C122", "C123", "C124", "C125", "C126", "C127", "C128", "OSAT", "PR",
        "C131", "C132", "C133", "C134", "C135", "C136", "C137", "C138", "C139", "C140",
        "C141", "C142", "C143", "C144", "C145", "C146", "C147", "C148", "C149", "C150",
        "C151", "C152", "C153", "C154", "C155", "C156", "C157", "C158", "C159", "C160",
        "C161", "C162", "C163", "C164", "C165", "C166", "C167", "C168", "C169", "C170",
        "C171", "C172", "C173", "C174", "C175", "C176", "C177", "C178", "C179", "C180",
        "C181", "C182", "C183", "C184", "C185", "C186", "C187", "C188", "C189", "C190",
        "C191", "C192", "C193", "C194", "C195", "C196", "C197", "C198", "C199", "C200",
        "C201", "C202", "C203", "C204", "C205", "C206", "C207", "C208", "C209", "C210",
        "C211", "C212", "C213", "C214", "C215", "C216", "C217", "C218", "C219", "C220",
        "C221", "C222", "C223", "C224", "C225", "C226", "C227", "C228", "C229", "C230",
        "C231", "C232", "C233", "C234", "C235", "C236", "C237", "C238", "C239", "C240",
        "C241", "C242", "C243", "C244", "C245", "C246", "C247", "C248", "C249", "C250",
        "C251", "C252", "C253", "C254", "C255", "C256",
    ], # EEG128
    4: {
        "AC1", "AC2", "Ref", "Fp1", "F7", "T3", "T5", "O1", "F3", "C3",
        "P3", "Fz", "Cz", "Pz", "F4", "C4", "P4", "Fp2", "F8", "T4",
        "T6", "O2", "AC23", "AC24", "DC1", "DC2", "DC3", "DC4",
    }, # AMB28
    5: [
        "C3", "C4", "O1", "O2", "A4", "A2", "LOC", "ROC", "CHIN1", "CHIN2",
        "ECGL", "ECGR", "LAT1", "RAT1", "LAT2", "RAT2", "X1", "X2", "X3", "X4",
        "X5", "X6", "X7", "X8", "X9", "X10", "CHEST", "ABD", "FLOW", "SNORE",
        "DIF1", "DIF2", "POSITION", "PRES", "DC1", "DC2", "DC3", "DC4", "DC5", "DC6",
        "OSAT", "PR",
    ], # HYPPO
    6: [
        "AC1", "AC2", "Ref", "Fp1", "F7", "T3", "T5", "O1", "F3", "C3",
        "P3", "Fz", "Cz", "Pz", "F4", "C4", "P4", "Fp2", "F8", "T4",
        "T6", "O2", "AC23", "AC24", "AC25", "AC26", "AC27", "AC28", "AC29", "AC30",
        "AC31", "AC32", "DC1", "DC2", "DC3", "DC4",
    ], # EMU36
    8: [
        "Ref", "Fp1", "F7", "T3", "A1", "T5", "O1", "F3", "C3", "P3",
        "Fpz", "Fz", "Cz", "Pz", "Fp2", "F8", "T4", "A2", "T6", "O2",
        "F4", "C4", "P4", "X1", "X2",
    ], # MOBEE24
    9: [
        "Ref", "Fp1", "F7", "T3", "A1", "T5", "O1", "F3", "C3", "P3",
        "Fpz", "Fz", "Cz", "Pz", "Fp2", "F8", "T4", "A2", "T6", "O2",
        "F4", "C4", "P4", "X1", "X2", "X3", "X4", "X5", "X6", "X7",
        "X8", "X9", "X10",
    ], # MOBEE32
}

# (k: v) headbox_type: channel_labels
CHANNEL_LABELS_SCHEMA_9 = {
    14: [
        "C3",   "C4",   "O1",    "O2",  "A1",    "A2",    "Cz",   "F3",   "F4",   "F7",
        "F8",   "Fz",   "Fp1",   "Fp2", "Fpz",   "P3",    "P4",   "Pz",   "T3",   "T4",
        "T5",   "T6",   "LOC",   "ROC", "CHIN1", "CHIN2", "ECGL", "ECGR", "LAT1", "LAT2",
        "RAT1", "RAT2", "CHEST", "ABD", "FLOW",  "SNORE", "DIF5", "DIF6", "POS",  "DC2",
        "DC3",  "DC4",  "DC5",   "DC6", "DC7",   "DC8",   "DC9",  "DC10", "OSAT", "PR",
    ],  # Connex EEG/Sleep
    15: [
        "Fp1", "F7",  "T3",  "A1",   "T5",   "O1",   "F3",   "C3",   "P3",  "Fpz",
        "Fz",  "Cz",  "Pz",  "Fp2",  "F8",   "T4",   "A2",   "T6",   "O2",  "F4",
        "C4",  "P4",  "X1",  "X2",   "DIF1", "DIF2", "DIF3", "DIF4", "DC1", "DC2",
        "DC3", "DC4", "OSAT", "PR",
    ],  # Trex Ambulatory
    17: [
        "Fp1", "F7",  "T3",  "T5",  "O1",   "F3",  "C3",  "P3",  "A1",  "Fz",
        "Cz",  "Fp2", "F8",  "T4",  "T6",   "O2",  "F4",  "C4",  "P4",  "A2",
        "Fpz", "Pz",  "X1",  "X2",  "X3",   "X4",  "X5",  "X6",  "X7",  "X8",
        "X9",  "X10", "X11", "X12", "X13",  "X14", "X15", "X16", "X17", "X18",
        "DC1", "DC2", "DC3", "DC4", "OSAT", "PR"
    ],  # EMU40 Ambulatory
    19: [
        "C3",   "C4",   "CZ",   "F3",   "F4",   "F7",   "F8",   "FZ", "FP1", "FP2",
        "FPZ",  "O1",   "O2",   "P3",   "P4",   "PZ",   "T3",   "T4", "T5",  "T6",
        "AUX1", "AUX2", "AUX3", "AUX4", "AUX5", "AUX6", "AUX7", "AUX8",
        "PG1", "PG2", "A1", "A2",
    ],  # EEG32U same as EEG32U Type 1
    20: [
        # AC channels (256)
        "C1", "C2", "C3", "C4", "C5", "C6", "C7", "C8", "C9", "C10",
        "C11", "C12", "C13", "C14", "C15", "C16", "C17", "C18", "C19", "C20",
        "C21", "C22", "C23", "C24", "C25", "C26", "C27", "C28", "C29", "C30",
        "C31", "C32", "C33", "C34", "C35", "C36", "C37", "C38", "C39", "C40",
        "C41", "C42", "C43", "C44", "C45", "C46", "C47", "C48", "C49", "C50",
        "C51", "C52", "C53", "C54", "C55", "C56", "C57", "C58", "C59", "C60",
        "C61", "C62", "C63", "C64", "C65", "C66", "C67", "C68", "C69", "C70",
        "C71", "C72", "C73", "C74", "C75", "C76", "C77", "C78", "C79", "C80",
        "C81", "C82", "C83", "C84", "C85", "C86", "C87", "C88", "C89", "C90",
        "C91", "C92", "C93", "C94", "C95", "C96", "C97", "C98", "C99", "C100",
        "C101", "C102", "C103", "C104", "C105", "C106", "C107", "C108", "C109", "C110",
        "C111", "C112", "C113", "C114", "C115", "C116", "C117", "C118", "C119", "C120",
        "C121", "C122", "C123", "C124", "C125", "C126", "C127", "C128", "C129", "C130",
        "C131", "C132", "C133", "C134", "C135", "C136", "C137", "C138", "C139", "C140",
        "C141", "C412", "C143", "C144", "C145", "C146", "C147", "C148", "C149", "C150",
        "C151", "C152", "C153", "C154", "C155", "C156", "C157", "C158", "C159", "C160",
        "C161", "C162", "C163", "C164", "C165", "C166", "C167", "C168", "C169", "C170",
        "C171", "C172", "C173", "C174", "C175", "C176", "C177", "C178", "C179", "C180",
        "C181", "C182", "C183", "C184", "C185", "C186", "C187", "C188", "C189", "C190",
        "C191", "C192", "C193", "C194", "C195", "C196", "C197", "C198", "C199", "C200",
        "C201", "C202", "C203", "C204", "C205", "C206", "C207", "C208", "C209", "C210",
        "C211", "C212", "C213", "C214", "C215", "C216", "C217", "C218", "C219", "C220",
        "C221", "C222", "C223", "C224", "C225", "C226", "C227", "C228", "C229", "C230",
        "C231", "C232", "C233", "C234", "C235", "C236", "C237", "C238", "C239", "C240",
        "C241", "C242", "C243", "C244", "C245", "C246", "C247", "C248", "C249", "C250",
        "C251", "C252", "C253", "C254", "C255", "C256",
        # DC Channels (16 = 12 on base unit + 4 on breakout)
        "DC1", "DC2", "DC3", "DC4", "DC5", "DC6", "DC7", "DC8", "DC9", "DC10",
        "DC11", "DC12", "DC13", "DC14", "DC15", "DC16",
        # Trigger (pseudo-DC channel)
        "TRIG",
        # Other
        "OSAT", "PR", "Pleth",
    ], # Quantum 1
    # 20: [
    # ], ===> TODO: handle Quantum 2, which uses the same headbox id (20) but has C1-C512
    21: ["C1",   "C2",   "C3",   "C4",   "C5",   "C6",   "C7",   "C8",   "C9",   "C10",
         "C11",  "C12",  "C13",  "C14",  "C15",  "C16",  "C17",  "C18",  "C19",  "C20",
         "C21",  "C22",  "C23",  "C24",  "C25",  "C26",  "C27",  "C28",  "C29",  "C30",
         "C31",  "C32",  "C33",  "C34",  "C35",  "C36",  "C37",  "C38",  "C39",  "C40",
         "C41",  "C42",  "C43",  "C44",  "C45",  "C46",  "C47",  "C48",  "C49",  "C50",
         "C51",  "C52",  "C53",  "C54",  "C55",  "C56",  "C57",  "C58",  "C59",  "C60",
         "C61",  "C62",  "C63",  "C64",  "C65",  "C66",  "C67",  "C68",  "C69",  "C70",
         "C71",  "C72",  "C73",  "C74",  "C75",  "C76",  "C77",  "C78",  "C79",  "C80",
         "C81",  "C82",  "C83",  "C84",  "C85",  "C86",  "C87",  "C88",  "C89",  "C90",
         "C91",  "C92",  "C93",  "C94",  "C95",  "C96",  "C97",  "C98",  "C99",  "C100",
         "C101", "C102", "C103", "C104", "C105", "C106", "C107", "C108", "C109", "C110",
         "C111", "C112", "C113", "C114", "C115", "C116", "C117", "C118", "C119", "C120",
         "C121", "C122", "C123", "C124", "C125", "C126", "C127", "C128",
         "PR",   "OSAT",
         "C131", "C132", "C133", "C134", "C135", "C136", "C137", "C138", "C139", "C140",
         "C141", "C142", "C143", "C144", "C145", "C146", "C147", "C148", "C149", "C150",
         "C151", "C152", "C153", "C154", "C155", "C156", "C157", "C158", "C159", "C160",
         "C161", "C162", "C163", "C164", "C165", "C166", "C167", "C168", "C169", "C170",
         "C171", "C172", "C173", "C174", "C175", "C176", "C177", "C178", "C179", "C180",
         "C181", "C182", "C183", "C184", "C185", "C186", "C187", "C188", "C189", "C190",
         "C191", "C192", "C193", "C194", "C195", "C196", "C197", "C198", "C199", "C200",
         "C201", "C202", "C203", "C204", "C205", "C206", "C207", "C208", "C209", "C210",
         "C211", "C212", "C213", "C214", "C215", "C216", "C217", "C218", "C219", "C220",
         "C221", "C222", "C223", "C224", "C225", "C226", "C227", "C228", "C229", "C230",
         "C231", "C232", "C233", "C234", "C235", "C236", "C237", "C238", "C239", "C240",
         "C241", "C242", "C243", "C244", "C245", "C246", "C247", "C248", "C249", "C250",
         "C251", "C252", "C253", "C254", "C255", "C256",
    ], # NeuroLink IP
    22: [
        "Fp1",  "Fp2", "F7",  "F3",  "Fz",  "F4",  "F8",  "T3",  "C3",  "Cz",
        "C4",   "T4",  "T5",  "P3",  "Pz",  "P4",  "T6",  "O1",  "O2",  "A1",
        "A2",   "Pg1", "Pg2", "Oz",  "X1",  "X2",  "X3",  "X4",  "X5",  "X6",
        "X7",   "X8",  "DC1", "DC2", "DC3", "DC4", "DC5", "DC6", "DC7", "DC8",
        "OSAT", "PR",  "POS",
    ], # Netlink
    23: [
        "Pg1", "Pg2", "Eogl", "Fp1", "Fp2", "Eogr", "T1",   "F7", "F3",  "Fz",
        "F4",  "F8",  "T2",   "A1",  "T3",  "C3",   "Cz",   "C4", "T4",  "A2",
        "T5",  "P3",  "Pz",   "P4",  "T6",  "O1",   "Oz",   "O2", "X1",  "X2",
        "X3",  "X4",  "DC1",  "DC2", "DC3", "DC4",  "OSAT", "PR", "POS",
    ], # Traveler Ambulatory
    24: ["Pg1",  "Pg2",  "Fp1",  "Fp2",  "F7",   "F8",   "F3",   "F4",   "T3",   "T4",
         "C3",   "C4",   "T5",   "T6",   "P3",   "P4",   "O1",   "O2",   "Fz",   "Cz",
         "Pz",   "A1",   "A2",   "24",   "25",   "26",   "27",   "28",   "29",   "30",
         "31",   "32",   "33",   "34",   "35",   "36",   "37",   "38",   "39",   "40",
         "DCM1", "DCM2", "DCM3", "DCM4", "DCM5", "DCM6", "DCM7", "DCM8",
         "OSat", "PR",
    ],# Grass Comet
    25: [
         "Pg1",  "Pg2",  "Fp1",  "Fp2",  "F7",   "F8",    "F3",   "F4",   "T3", "T4",
         "C3",   "C4",   "T5",   "T6",   "P3",   "P4",    "O1",   "O2",   "Fz", "Cz",
         "Pz",   "A1",   "A2",   "24",   "25",   "26",    "27",   "28",   "29", "30",
         "31",   "32",   "33",   "34",   "35",   "36",    "37",   "38",   "39", "40",
         "DCM1", "DCM2", "DCM3", "DCM4", "DCM5", "DCM6",  "DCM7", "DCM8",
         "DC1",  "DC2",  "DC3",  "DC4",  "PPG",  "Pleth", "OSat", "PR",
    ], # Grass Comet Plus
    26: [
         "Fp1", "Fp2", "F3",  "F4",   "C3", "C4", "P3", "P4", "O1", "O2",
         "F7",  "F8",  "T3",  "T4",   "T5", "T6", "A1", "A2", "Fz", "Cz",
         "Pz",  "ROC", "LOC", "24",   "25", "26", "27", "28", "29", "30",
         "31",  "32",  "DC",  "OSAT", "PR",
    ], # V32
    27: [
        "Fp1", "Fp2", "F3", "F4", "C3", "C4", "P3", "P4", "O1", "O2",
        "F7", "F8", "T3", "T4", "T5", "T6", "A1", "A2", "Fz", "Cz",
        "Pz", "ROC", "LOC", "24", "25", "26", "27", "28", "29", "30",
        "31", "32", "DC1", "DC2", "DC3", "DC4", "DC5", "DC6", "DC7", "DC8",
        "DC9", "DC10", "DC11", "DC12", "OSAT", "PR", "Pleth",
    ], # V44
    28: [
        "C3", "C4", "Cz", "F3", "F4", "F7", "F8", "Fz", "Fp1", "Fp2",
        "Fpz", "M1", "M2", "O1", "O2", "Oz", "P3", "P4", "P7", "P8",
        "Pz", "T7", "T8", "X25", "X26", "X28", "X29", "X30", "X31", "X32",
        "ECG-LA", "ECG-RA", "ECG-LL", "ECG-V1", "ECG-V2", "E1", "E2", "CHIN1", "CHIN2", "CHINz",
        "DIF1+", "DIF1-", "DIF2+", "DIF2-", "DIF3+", "DIF3-", "DIF4+", "DIF4-", "DIF5+", "DIF5-",
        "DIF6+", "DIF6-", "DIF7+", "DIF7-", "DIF8+", "DIF8-", "DIF9+", "DIF9-", "DIF10+", "DIF10-",
        "RLEG+", "RLEG-", "LLEG+", "LLEG-", "Snore", "Flow", "Pressure", "Flow_DR", "Snore_DR", "Abdomen",
        "Chest", "Phase", "RMI", "RR", "XSum", "XFlow", "XVolume", "Position", "Elevation", "Activity",
        "PPG", "PTT", "Pleth", "DC13", "DC14", "DC15", "DC16", "DC1", "DC2", "DC3",
        "DC4", "DC5", "DC6", "DC7", "DC8", "DC9", "DC10", "DC11", "DC12", "TRIG",
        "SpO2", "PR", "PulseQuality",
    ], # Brain Monitor
    29: [
        "C3", "C4", "Cz", "F3", "F4", "F7", "F8", "Fz", "Fp1", "Fp2",
        "Fpz", "M1", "M2", "O1", "O2", "Oz", "P3", "P4", "P7", "P8",
        "Pz", "T7", "T8", "X25", "X26", "X28", "X29", "X30", "X31", "X32",
        "ECG-LA", "ECG-RA", "ECG-LL", "ECG-V1", "ECG-V2", "E1", "E2", "CHIN1", "CHIN2", "CHINz",
        "DIF1+", "DIF1-", "DIF2+", "DIF2-", "DIF3+", "DIF3-", "DIF4+", "DIF4-", "DIF5+", "DIF5-",
        "DIF6+", "DIF6-", "DIF7+", "DIF7-", "DIF8+", "DIF8-", "DIF9+", "DIF9-", "DIF10+", "DIF10-",
        "RLEG+", "RLEG-", "LLEG+", "LLEG-", "Snore", "Flow", "Pressure", "Flow_DR", "Snore_DR", "Abdomen",
        "Chest", "Phase", "RMI", "RR", "XSum", "XFlow", "XVolume", "Position", "Elevation", "Activity",
        "PPG", "PTT", "Pleth", "DC13", "DC14", "DC15", "DC16", "DC1", "DC2", "DC3",
        "DC4", "DC5", "DC6", "DC7", "DC8", "DC9", "DC10", "DC11", "DC12", "TRIG",
        "SpO2", "PR", "PulseQuality",
    ], # Embla NDx
    30: [
        "C3", "C4", "F3", "F4", "O1", "X1", "O2", "M1", "M2", "E1",
        "E2", "CHIN1", "CHIN2", "CHINz", "DIF1+", "DIF1-", "DIF2+", "DIF2-", "ECG+", "ECG-",
        "RLEG+", "RLEG-", "LLEG+", "LLEG-", "Snore", "Flow", "Pressure", "Flow_DR", "Snore_DR", "Abdomen",
        "Chest", "Phase", "RMI", "RR", "XSum", "XFlow", "XVolume", "Position", "Elevation", "Activity",
        "PPG", "PTT", "Pleth", "DC13", "DC14", "DC1", "DC2", "DC3", "DC4", "DC5",
        "DC6", "SpO2", "PR", "PulseQuality",
    ], # Embla SDx
    31: [
        "C3", "C4", "Cz", "F3", "F4", "F7", "F8", "Fz", "Fp1", "Fp2",
        "Fpz", "M1", "M2", "O1", "O2", "Oz", "P3", "P4", "P7", "P8",
        "Pz", "T7", "T8", "X25", "X26", "X28", "X29", "X30", "X31", "X32",
        "ECG-LA", "ECG-RA", "ECG-LL", "ECG-V1", "ECG-V2", "E1", "E2", "CHIN1", "CHIN2", "CHINz",
        "DIF1+", "DIF1-", "DIF2+", "DIF2-", "DIF3+", "DIF3-", "DIF4+", "DIF4-", "DIF5+", "DIF5-",
        "DIF6+", "DIF6-", "DIF7+", "DIF7-", "DIF8+", "DIF8-", "DIF9+", "DIF9-", "DIF10+", "DIF10-",
        "RLEG+", "RLEG-", "LLEG+", "LLEG-", "Snore", "Flow", "Pressure", "Flow_DR", "Snore_DR", "Abdomen",
        "Chest", "Phase", "RMI", "RR", "XSum", "XFlow", "XVolume", "Position", "Elevation", "Activity",
        "PPG", "PTT", "Pleth", "DC13", "DC14", "DC15", "DC16", "DC1", "DC2", "DC3",
        "DC4", "DC5", "DC6", "DC7", "DC8", "DC9", "DC10", "DC11", "DC12", "TRIG",
        "SpO2", "PR", "PulseQuality",
    ], # Brain Monitor iX
    32: [
        "C3", "C4", "F3", "F4", "M1", "M2", "O1", "O2", "ExG", "EOG L",
        "EOG R", "Chin", "ChinL", "ChinR", "LegL", "LegR", "ECG", "Nasal Pressure", "Nasal Flow", "Mask Pressure",
        "Snore", "Audio Level", "SpO2", "SpO2 B-B", "Pulse Rate", "Pleth", "PPG", "SpO2 Quality", "Pleth Quality", "Position",
        "Elevation", "Activity", "Thorax", "Abdomen", "Phase", "RMI", "RR", "XSum", "XFlow", "Tidal Volume",
        "Thermistor", "DC",
    ], # Embletta MPR
    34: [
        "SpO2", "SaO2", "SvjO2", "NIRS", "PR", "HR", "RR", "T", "Perf", "dT",
        "PbtO2", "CPP", "ICP", "NIBPS", "NIBPD", "NIBPM", "IBPS", "IBPD", "IBPM", "DC20",
        "DC21", "DC22", "DC23", "DC24", "DC25", "DC26", "DC27", "DC28", "DC29", "DC30",
    ], # Cain
}

CHANNEL_LABELS = {
    8: CHANNEL_LABELS_SCHEMA_8,
    9: CHANNEL_LABELS_SCHEMA_9,
}

CONVERSION_FACTORS_BM_NDX = [
    (
        list(range(0, 64)),
        lambda discard_bits: (-8711.0 / (2**21 - 0.5)) * 2**discard_bits, # negative
    ),
    (
        list(range(64, 65)),
        lambda discard_bits: (500_000 / 27306 / 2**6) * 2**discard_bits, # TODO: spec says 5e5 but could be 5e6?
    ),
    (
        list(range(65, 66)),
        lambda discard_bits: (-500_000 / 27072 / 2**6) * 2**discard_bits, # TODO: spec says 5e5 but could be 5e6?
    ),
    (
        list(range(66, 67)),
        lambda discard_bits: (50.9858 / 31515 / 2**6) * 2**discard_bits,
    ),
    (
        list(range(67, 69)),
        lambda discard_bits: (50 / (2**15 - 1) / 2**6) * 2**discard_bits,
    ),
    (
        list(range(69, 71)),
        lambda discard_bits: (-5_000_000 / (2**15 - 1) / 2**6) * 2**discard_bits, # negative
    ),
    (
        list(range(71, 77)),
        lambda discard_bits: (400 / (2**15 - 1) / 2**6) * 2**discard_bits,
    ),
    (
        list(range(77, 78)),
        lambda discard_bits: (1_000_000 / (2**15 - 1) / 2**6) * 2**discard_bits,
    ),
    (
        list(range(78, 79)),
        lambda discard_bits: (4 / (2**15 - 1) / 2**6) * 2**discard_bits,
    ),
    (
        list(range(79, 80)),
        lambda discard_bits: (50 / (2**15 - 1) / 2**6) * 2**discard_bits,
    ),
    (
        list(range(80, 82)),
        lambda discard_bits: (1 / 2**6) * 2**discard_bits,
    ),
    (
        list(range(82, 83)),
        lambda discard_bits: (1 / (2**15 - 1) / 2**6) * 2**discard_bits,
    ),
    (
        list(range(83, 87)),
        lambda discard_bits: (-5_000_000 / 26703 / 2**6) * 2**discard_bits, # negative
    ),
    (
        list(range(87, 99)),
        lambda discard_bits: ( (2 * 5.4 * 0.954 * 1_000_000) / (2**16 - 1) / 2**6) * 2**discard_bits,
    ),
    (
        list(range(99, 100)),
        lambda discard_bits: 1 * 2**discard_bits,
    ),
    (
        list(range(100, 103)),
        lambda discard_bits: (1 / 2**6) * 2**discard_bits,
    ),
]

CONVERSION_FACTORS_SCHEMA_8 = {
    1: [
        (
            list(range(0, 32)),
            lambda discard_bits: (8711.0 / (2**21 - 0.5)) * 2**discard_bits,
        ),
    ],
    3: [
        (
            list(range(0, 256)),
            lambda discard_bits: (8711.0 / (2**21 - 0.5)) * 2**discard_bits,
        ),
    ],
    4: [
        (
            list(range(0, 24)),
            lambda discard_bits: (8711.0 / (2**21 - 0.5)) * 2**discard_bits,
        ),
        (
            list(range(24, 28)),
            lambda discard_bits: (5_000_000 / (2**10 - 0.5) / 2**6) * 2**discard_bits,
        )
    ],
    5: [
        (
            list(range(0, 26)),
            lambda discard_bits: (8711.0 / (2**21 - 0.5)) * 2**discard_bits,
        ),
        (
            list(range(26, 32)),
            lambda discard_bits: ((8711.0 / (2**21 - 0.5)) / (159.8 / 249.5))
            * 2**discard_bits,
        ),
        (
            list(range(32, 40)),
            lambda discard_bits: (10_000_000 / (2**10 - 0.5) / 2**6) * 2**discard_bits,
        ),
        # TODO: handle v3.4+ which would use below discard_bits instead
        # (
        #     list(range(32, 40)),
        #     lambda discard_bits: (20_000_000 / 65536) * 2**discard_bits,
        # )
        (
            list(range(40, 42)),
            lambda discard_bits: (1 / 2**6) * 2**discard_bits,
        ),
    ],
    6: [
        (
            list(range(0, 32)),
            lambda discard_bits: (8711.0 / (2**21 - 0.5)) * 2**discard_bits,
        ),
        (
            list(range(32, 36)),
            lambda discard_bits: (5_000_000 / (2**10 - 0.5) / 2**6) * 2**discard_bits,
        ),
    ],
    8: [
        (
            list(range(0, 25)),
            lambda discard_bits: (8711.0 / (2**21 - 0.5)) * 2**discard_bits,
        ),
        (
            list(range(25, 27)),
            lambda discard_bits: (1 / 2**6) * 2**discard_bits,
        ),
    ],
    9: [
        (
            list(range(0, 33)),
            lambda discard_bits: (8711.0 / (2**21 - 0.5)) * 2**discard_bits,
        ),
        (
            list(range(33, 35)),
            lambda discard_bits: (1 / 2**6) * 2**discard_bits,
        ),
    ]
}
CONVERSION_FACTORS_SCHEMA_9 = {
    14: [
        (
            list(range(0, 38)),
            lambda discard_bits: (8711.0 / (2**21 - 0.5)) * 2**discard_bits,
        ),
        (
            list(range(38, 48)),
            lambda discard_bits: ((10_800_000 / 65536) / 2**6) * 2**discard_bits,
        ),
        (
            list(range(48, 50)),
            lambda discard_bits: (1 / 2**6) * 2**discard_bits,
        ),
    ],
    15: [
        (
            list(range(0, 28)),
            lambda discard_bits: (8711.0 / (2**21 - 0.5)) * 2**discard_bits,
        ),
        (
            list(range(28, 32)),
            lambda discard_bits: ((10_000_000 / 65536) / 2**6) * 2**discard_bits,
        ),
        (
            list(range(32, 34)),
            lambda discard_bits: (1 / 2**6) * 2**discard_bits,
        ),
    ],
    17: [
        (
            list(range(0, 40)),
            lambda discard_bits: (8711.0 / (2**21 - 0.5)) * 2**discard_bits,
        ),
        (
            list(range(40, 44)),
            lambda discard_bits: ((10_800_000 / 65536) / 2**6) * 2**discard_bits,
        ),
        (
            list(range(44, 46)),
            lambda discard_bits: (1 / 2**6) * 2**discard_bits,
        ),
    ],
    19: [
        (
            list(range(0, 32)),
            lambda discard_bits: (8711.0 / (2**21 - 0.5)) * 2**discard_bits,
        )
    ],
    20: [
        (
            list(range(0, 256)),
            lambda discard_bits: (-8711.0 / (2**21 - 0.5)) * 2**discard_bits, # negative
        ),
        (
            list(range(256, 272)),
            lambda discard_bits: ((-10_800_000 / 65536) / 2**6) * 2**discard_bits, # negative
        ),
        (
            list(range(272, 276)),
            lambda discard_bits: (1 / 2**6) * 2**discard_bits,
        ),
    ],
    21: [
        (
            list(range(0, 128)),
            lambda discard_bits: (8711.0 / (2**21 - 0.5)) * 2**discard_bits,
        ),
        (
            list(range(128, 130)),
            lambda discard_bits: (1 / 2**6) * 2**discard_bits,
        ),
        (
            list(range(130, 256)),
            lambda discard_bits: (8711.0 / (2**21 - 0.5)) * 2**discard_bits,
        ),
    ],
    22: [
        (
            list(range(0, 32)),
            lambda discard_bits: (8711.0 / (2**21 - 0.5)) * 2**discard_bits,
        ),
        (
            list(range(32, 40)),
            lambda discard_bits: ((10_800_000 / 65536) / 2**6) * 2**discard_bits,
        ),
        (
            list(range(40, 42)),
            lambda discard_bits: (1 / 2**6) * 2**discard_bits,
        ),
        (
            list(range(42, 43)),
            lambda discard_bits: ((10_800_000 / 65536) / 2**6) * 2**discard_bits,
        ),
    ],
    23: [
        (
            list(range(0, 32)),
            lambda discard_bits: (8711.0 / (2**21 - 0.5)) * 2**discard_bits,
        ),
        (
            list(range(32, 36)),
            lambda discard_bits: ((10_800_000 / 65536) / 2**6) * 2**discard_bits,
        ),
        (
            list(range(36, 38)),
            lambda discard_bits: (1 / 2**6) * 2**discard_bits,
        ),
        (
            list(range(38, 39)),
            lambda discard_bits: ((10_800_000 / 65536) / 2**6) * 2**discard_bits,
        ),
    ],
    24: [
        (
            list(range(0, 40)),
            lambda discard_bits: (4_000.0 / (2**16 - 1) / 2**6) * 2**discard_bits,
        ),
        (
            list(range(40, 48)),
            lambda discard_bits: (5_000_000 / (2**16 - 1) / 2**6) * 2**discard_bits,
        ),
        (
            list(range(48, 50)),
            lambda discard_bits: (1 / 2**6) * 2**discard_bits,
        ),
    ],
    25: [
        (
            list(range(0, 40)),
            lambda discard_bits: (4_000.0 / (2**16 - 1) / 2**6) * 2**discard_bits,
        ),
        (
            list(range(40, 52)),
            lambda discard_bits: (5_000_000 / (2**16 - 1) / 2**6) * 2**discard_bits,
        ),
        (
            list(range(52, 54)),
            lambda discard_bits: (1 / (2**15 - 1) / 2**6) * 2**discard_bits,
        ),
        (
            list(range(54, 56)),
            lambda discard_bits: (1 / 2**6) * 2**discard_bits,
        ),
    ],
    26: [
        (
            list(range(0, 32)),
            lambda discard_bits: (-1_000 / (2**16 - 1) / 2**6) * 2**discard_bits, # negative
        ),
        (
            list(range(32, 33)),
            lambda discard_bits: (-5_000_000 / (2**16 - 1) / 2**6) * 2**discard_bits, # negative
        ),
        (
            list(range(33, 35)),
            lambda discard_bits: (1 / 2**6) * 2**discard_bits,
        ),
    ],
    27: [
        (
            list(range(0, 32)),
            lambda discard_bits: (-1_000 / (2**16 - 1) / 2**6) * 2**discard_bits, # negative
        ),
        (
            list(range(32, 44)),
            lambda discard_bits: (-10_000_000 / (2**16 - 1) / 2**6) * 2**discard_bits, # negative
        ),
        (
            list(range(44, 46)),
            lambda discard_bits: (1 / 2**6) * 2**discard_bits,
        ),
        (
            list(range(46, 47)),
            lambda discard_bits: (1 / (2**15 - 1) / 2**6) * 2**discard_bits,
        ),
    ], # V44
    28: CONVERSION_FACTORS_BM_NDX, # Brain Monitor
    29: CONVERSION_FACTORS_BM_NDX, # Embla NDx
    30: [
        (
            list(range(0, 24)),
            lambda discard_bits: (-8711.0 / (2**21 - 0.5)) * 2**discard_bits, # negative
        ),
        (
            list(range(24, 25)),
            lambda discard_bits: (500_000 / 27306 / 2**6) * 2**discard_bits, # TODO: spec says 5e5 but could be 5e6?
        ),
        (
            list(range(25, 26)),
            lambda discard_bits: (-500_000 / 27072 / 2**6) * 2**discard_bits, # TODO: spec says 5e5 but could be 5e6?
        ),
        (
            list(range(26, 27)),
            lambda discard_bits: (50.9858 / 31515 / 2**6) * 2**discard_bits,
        ),
        (
            list(range(27, 29)),
            lambda discard_bits: (50 / (2**15 - 1) / 2**6) * 2**discard_bits,
        ),
        (
            list(range(29, 31)),
            lambda discard_bits: (-5_000_000 / (2**15 - 1) / 2**6) * 2**discard_bits, # negative
        ),
        (
            list(range(31, 37)),
            lambda discard_bits: (400 / (2**15 - 1) / 2**6) * 2**discard_bits,
        ),
        (
            list(range(37, 38)),
            lambda discard_bits: (1_000_000 / (2**15 - 1) / 2**6) * 2**discard_bits,
        ),
        (
            list(range(38, 39)),
            lambda discard_bits: (4 / (2**15 - 1) / 2**6) * 2**discard_bits,
        ),
        (
            list(range(39, 40)),
            lambda discard_bits: (50 / (2**15 - 1) / 2**6) * 2**discard_bits,
        ),
        (
            list(range(40, 42)),
            lambda discard_bits: (1 / 2**6) * 2**discard_bits,
        ),
        (
            list(range(42, 43)),
            lambda discard_bits: (1 / (2**15 - 1) / 2**6) * 2**discard_bits,
        ),
        (
            list(range(43, 45)),
            lambda discard_bits: (-5_000_000 / 26703 / 2**6) * 2**discard_bits, # negative
        ),
        (
            list(range(45, 51)),
            lambda discard_bits: ( (2 * 5.4 * 0.954 * 1_000_000) / (2**16 - 1) / 2**6) * 2**discard_bits,
        ),
        (
            list(range(51, 54)),
            lambda discard_bits: (1 / 2**6) * 2**discard_bits,
        ),
    ], # Embla SDx
    31: CONVERSION_FACTORS_BM_NDX, # Brain Monitor iX
    32: [
        (
            list(range(0, 8)),
            lambda discard_bits: (-6_000 / (2**16 - 1) / 2**6) * 2**discard_bits, # negative
        ),
        (
            list(range(8, 9)),
            lambda discard_bits: (-40_000 / (2 * 419430 / 16) / 2**6) * 2**discard_bits, # negative
        ),
        (
            list(range(9, 16)),
            lambda discard_bits: (-6_000 / (2**16 - 1) / 2**6) * 2**discard_bits, # negative
        ),
        (
            list(range(16, 17)),
            lambda discard_bits: (-8_000 / (2**16 - 1) / 2**6) * 2**discard_bits, # negative
        ),
        (
            list(range(17, 18)),
            lambda discard_bits: (5.0 * 1.01972 / (2**15 - 1) / 2**6) * 2**discard_bits,
        ),
        (
            list(range(18, 19)),
            lambda discard_bits: (5.0 / (2**15 - 1) / 2**6) * 2**discard_bits,
        ),
        (
            list(range(19, 20)),
            lambda discard_bits: (-50.0 * 1.01972 * 0.05 * 1_000_000 / (2**15 - 1) / 2**6) * 2**discard_bits, # negative
        ),
        (
            list(range(20, 21)),
            lambda discard_bits: ( 1 / 2**6) * 2**discard_bits,
        ),
        (
            list(range(21, 22)),
            lambda discard_bits: (-1_000_000 / (2**15 - 1) / 2**6) * 2**discard_bits, # negative
        ),
        (
            list(range(22, 25)),
            lambda discard_bits: (1 / 2**6) * 2**discard_bits,
        ),
        (
            list(range(25, 26)),
            lambda discard_bits: (2 / (2**16 - 1) / 2**6) * 2**discard_bits,
        ),
        (
            list(range(26, 27)),
            lambda discard_bits: (1 / (2**15 - 1) / 2**6) * 2**discard_bits,
        ),
        (
            list(range(27, 29)),
            lambda discard_bits: (1 / 2**6) * 2**discard_bits,
        ),
        (
            list(range(29, 30)),
            lambda discard_bits: (1_000_000 / (2**15 - 1) / 2**6) * 2**discard_bits,
        ),
        (
            list(range(30, 31)),
            lambda discard_bits: (2 / (2**16 - 1) / 2**6) * 2**discard_bits,
        ),
        (
            list(range(31, 32)),
            lambda discard_bits: (20 / (2**16 - 1) / 2**6) * 2**discard_bits,
        ),
        (
            list(range(32, 34)),
            lambda discard_bits: (1 / 2**6) * 2**discard_bits,
        ),
        (
            list(range(34, 40)),
            lambda discard_bits: (400 / (2**15 - 1) / 2**6) * 2**discard_bits,
        ),
        (
            list(range(40, 41)),
            lambda discard_bits: (-2_000_000 / (65532) / 2**6) * 2**discard_bits, # negative
        ),
        (
            list(range(41, 42)),
            lambda discard_bits: (2_400_000 / (2**15 - 1) / 2**6) * 2**discard_bits,
        ),
    ], # Embletta MPR
    34: [
        (
        list(range(0, 30)),
        lambda discard_bits: ( (-2 * 5.4 * 0.954 * 1_000_000) / (2**16 - 1) / 2**6) * 2**discard_bits, # negative
    ),
    ], # Cain
}

CONVERSION_FACTORS = {
    8: CONVERSION_FACTORS_SCHEMA_8,
    9: CONVERSION_FACTORS_SCHEMA_9,
}
