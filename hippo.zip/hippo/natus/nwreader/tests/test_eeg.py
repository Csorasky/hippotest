import json
import os

from nwreader.snc_reader import SyncFile
from nwreader.eeg_reader import read_eeg_file
from nwreader.notes_reader import read_annotations_file
from .conftest import DATA_PATH

# set to False to keep converted json files
cleanup = False

def _get_test_files(data_dir: str, study_dir: str):
    file_prefix = f"{data_dir}/{study_dir}/{study_dir.split('/')[-1]}"
    eeg_path = f"{file_prefix}.eeg"
    ent_path = f"{file_prefix}.ent"
    snc_path = f"{file_prefix}.snc"
    return (eeg_path, ent_path, snc_path)

def test_without_sync_file():
    study_dirs = [
        "sample~ data_8ef647e3-e5ea-43a6-8c69-fb848b8db7c2",
    ]
    for study_dir in study_dirs:
        # get test files
        (eeg_path, ent_path, snc_path) = _get_test_files(DATA_PATH, study_dir)
        
        # read annotations without extra fields with converted stamps
        ent_list = read_annotations_file(ent_path)
        ent_list_json = json.dumps(ent_list)
        assert all(item is not None for item in ent_list), "List should not contain None values"
        
        # write annotations to log file
        with open(f"{ent_path}.json", "w") as f:
            f.write(ent_list_json)
        
        # delete the file if we're cleaning up
        if cleanup:
            os.remove(f"{ent_path}.json")
        
        print(f"Finished reading {study_dir}")

def test_with_sync_file():
    study_dirs = [
        "sample~ data_8ef647e3-e5ea-43a6-8c69-fb848b8db7c2",
    ]
    for study_dir in study_dirs:
        # get test files
        (eeg_path, ent_path, snc_path) = _get_test_files(DATA_PATH, study_dir)
        
        with open(snc_path, 'rb') as snc_f:
            # get a sync file ready
            sync_file = SyncFile.from_file(snc_f)

            # read patient/study info
            eeg_file = read_eeg_file(eeg_path, sync_file=sync_file, verbose=False)
            eeg_file_json = json.dumps(eeg_file, indent=2)
            
            # write formatted json to log file
            with open(f"{eeg_path}.json", "w") as f:
                f.write(eeg_file_json)
            
            # read annotations
            ent_list = read_annotations_file(ent_path, sync_file)
            ent_list_json = json.dumps(ent_list)
            
            # write formatted json to log file
            with open(f"{ent_path}.json", "w") as f:
                f.write(ent_list_json)
            assert all(item is not None for item in ent_list), "List should not contain None values"
            
            # delete the file if we're cleaning up
            if cleanup:
                os.remove(f"{eeg_path}.json")
                os.remove(f"{ent_path}.json")
            
        print(f"Finished reading {study_dir}")
