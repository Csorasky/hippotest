from nwreader.notes_reader import read_annotations_file
from .conftest import ENT_FILE_0


def test_read_annotations():
    annotations = read_annotations_file(ENT_FILE_0)
    assert isinstance(annotations, list)
    assert len(annotations) == 14
    assert all(isinstance(a, dict) for a in annotations)
    assert all("Stamp" in a for a in annotations)
