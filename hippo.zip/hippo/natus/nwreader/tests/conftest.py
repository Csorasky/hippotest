import os

HERE = os.path.dirname(os.path.abspath(__file__))
DATA_PATH = os.path.join(
    HERE,
    "data",
)

STUDY_PATH_0 = os.path.join(
    DATA_PATH,
    'sample~ data_8ef647e3-e5ea-43a6-8c69-fb848b8db7c2'
)

TOC_FILE_0 = os.path.join(
    STUDY_PATH_0,
    'sample~ data_8ef647e3-e5ea-43a6-8c69-fb848b8db7c2_001.etc'
)

ERD_FILE_0 = os.path.join(
    STUDY_PATH_0,
    'sample~ data_8ef647e3-e5ea-43a6-8c69-fb848b8db7c2_001.erd'
)

ERD_PART_0_TESTVECTOR = os.path.join(
    DATA_PATH,
    'sample~ data_8ef647e3-e5ea-43a6-8c69-fb848b8db7c2_001.test_vectors.json'
)

ENT_FILE_0 = os.path.join(
    STUDY_PATH_0,
    'sample~ data_8ef647e3-e5ea-43a6-8c69-fb848b8db7c2.ent'
)

EEG_FILE_0 = os.path.join(
    STUDY_PATH_0,
    'sample~ data_8ef647e3-e5ea-43a6-8c69-fb848b8db7c2.eeg'
)

EDF_FILE_0 = os.path.join(
    STUDY_PATH_0,
    'sample~ data_8ef647e3-e5ea-43a6-8c69-fb848b8db7c2.edf'
)

EPO_FILE_0 = os.path.join(
    DATA_PATH, 'sample.epo'
)
