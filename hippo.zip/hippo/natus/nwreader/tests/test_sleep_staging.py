from datetime import datetime
import json
import numpy as np
import os
import pandas as pd
from nwreader.eeg_reader import read_eeg_file
from nwreader.epo_reader import read_epo_file
from nwreader.epo_reader import EpoFile, EpoStorage, ChannelType, EpochInfo, ChannelInfoBasic
from nwreader.notes_reader import read_annotations_file
from nwreader.snc_reader import SyncFile

UTC_FORMAT = '%Y-%m-%d %H:%M:%S.%f%z'

def _get_test_files(data_dir: str, study_dir: str):
    file_stem = study_dir.split('/')[-1]
    file_prefix = f"{data_dir}/{study_dir}/{file_stem}"
    eeg_path = f"{file_prefix}.eeg"
    ent_path = f"{file_prefix}.ent"
    snc_path = f"{file_prefix}.snc"
    epo_path = f"{file_prefix}.epo"
    # output
    os.makedirs(f"{data_dir}/{study_dir}/output", exist_ok=True)
    output_prefix = f"{data_dir}/{study_dir}/output/{file_stem}"
    return (eeg_path, ent_path, epo_path, snc_path, output_prefix)

def _create_stage_entries(sleep_stages: np.ndarray[str],
                             epoch_start_index: int,
                             epoch_start_stamp: int,
                             samples_per_epoch: int,
                             max_study_stamp: int,
                             utc_to_local_diff: np.timedelta64,
                             sync_file: SyncFile) -> list[dict]:
    
    sleep_stage_entries = []
    for i, stage in enumerate(sleep_stages):
        epoch_index = i + epoch_start_index
        # epoch sample stamps
        epoch_stamp = epoch_start_stamp + i * samples_per_epoch
        epoch_end_stamp = min(epoch_stamp + samples_per_epoch - 1, max_study_stamp) # would be better to use final ETC stamp for max
        # epoch start utc
        epoch_utc = sync_file.interp_stamps(epoch_stamp)
        epoch_utc_end = sync_file.interp_stamps(epoch_end_stamp)
        # epoch start local
        epoch_local = epoch_utc + utc_to_local_diff
        epoch_local_end = epoch_utc_end + utc_to_local_diff
        # add to list
        sleep_stage_entries.append({'epoch': epoch_index, 'sleep_stage': stage,
                                    'sample_stamp_start': epoch_stamp, 'sample_stamp_end': epoch_end_stamp,
                                    'utc_time_start': str(epoch_utc), 'utc_time_end': str(epoch_utc_end),
                                    'local_time_start': str(epoch_local), 'local_time_end': str(epoch_local_end)})
    return sleep_stage_entries

def _filter_annotations(ent_list: list[dict], storage_name: str, utc_to_local_diff: np.timedelta64, include_global_annotations: bool = False) -> list[dict]:
    """Filter the annotations list to exclude global annotations (if desired) and only include annotations for the specified storage_name.

    Args:
        ent_list (list[dict]): list of dict objects representing annotations
        storage_name (str): the storage name to keep notes for
        utc_to_local_diff (np.timedelta64): the difference between UTC and local time
        include_global_annotations (bool, optional): set to true to include annotations not specific to any scoring set. Defaults to False.

    Returns:
        list[dict]: annotation list after filtering out those from other scoring sets, or optionally global annotations
    """
    annotations_filtered = []
    
    for item in ent_list:
        # add a StampTimeLocal field
        stamp_utc = np.datetime64(item['StampTimeUtc'])
        stamp_local = stamp_utc + utc_to_local_diff
        item['StampTimeLocal'] = str(stamp_local)
        
        # filter
        if 'ScoringSet' in item and item['ScoringSet'] == storage_name:
            annotations_filtered.append(item)
        elif include_global_annotations:
            annotations_filtered.append(item)
    
    # return sorted list (based on stamp)
    return sorted(annotations_filtered, key=lambda k: k['Stamp'])

def epo_scoring_set_to_json(data_folder: str, study_folder: str):
    # get test files
    (eeg_path, ent_path, epo_path, snc_path, output_prefix) = _get_test_files(data_folder, study_folder)
    
    with open(snc_path, 'rb') as snc_f:
        # get a sync file ready
        sync_file = SyncFile.from_file(snc_f)

        # read patient/study info
        eeg_file = read_eeg_file(eeg_path, sync_file=sync_file, verbose=False)
        eeg_file_json = json.dumps(eeg_file, indent=2)
        
        # write formatted json to log file
        with open(f"{output_prefix}.eeg.json", "w") as f:
            f.write(eeg_file_json)
            
        # save the sampling frequency
        samplingFreq = eeg_file['Study'][0]['Headbox']['HB0']['SamplingFreq']
        study_duration_ms = int(eeg_file['Study'][0]['Duration'])
        
        # read annotations, write to log file
        ent_list = read_annotations_file(ent_path, sync_file)
        ent_list_json = json.dumps(ent_list, indent=2)
        with open(f"{output_prefix}.ent.json", "w") as f:
            f.write(ent_list_json)
        
        # read the epo file
        epoFile: EpoFile = read_epo_file(epo_path)
        header = epoFile.header
        epochInfo: EpochInfo = header.epochInfo
        storage_dict = epoFile.storages
    
        # get epo and study info
        epochsAfterLightsOff = epochInfo.epochsAfterLightsOff   # Number of epochs in the study (**from LIGHTS OFF** to end of study)
        epochsBeforeLightsOff = epochInfo.epochsBeforeLightsOff # The number of epochs in the study **BEFORE LIGHTS OFF**
        epochLength = epochInfo.epochLength                     # Epoch length for the study (in seconds)
        epochOneStamp = epochInfo.startTime                     # The sample stamp corresponding to the start of epoch #1 in the study
        studyStartStamp = epochInfo.studyStartStamp             # The sample stamp corresponding to the start of the study
        epochsEntireStudy = epochsAfterLightsOff + epochsBeforeLightsOff # Total number of epochs in the study
        
        # figure out the difference between local time and UTC time
        creation_utc_str = eeg_file['Study'][0]['XLCreationTime']
        creation_utc = np.datetime64(creation_utc_str)
        creation_local_str = eeg_file['Study'][0]['CreationTime'] + '+0000'
        creation_local = np.datetime64(creation_local_str)
        utc_to_local_diff = creation_local - creation_utc
        
        # general epoch info
        print(f"\n\nFile: {epo_path}")
        print(f"\tEpochInfo:")
        print(f"\t\tTotal Epochs = {epochsEntireStudy}")
        print(f"\t\tEpochs Before Lights Off: {epochsBeforeLightsOff}")
        print(f"\t\tEpochs Ater Lights Off: {epochsAfterLightsOff}")
        print(f"\t\tEpoch Duration(s): {epochLength}")
        
        scoring_json: dict = {}
        scoring_json['epoch_info'] = {}
        scoring_json['epoch_info']['total_epochs'] = epochsEntireStudy
        scoring_json['epoch_info']['epochs_before_lights_off'] = epochsBeforeLightsOff
        scoring_json['epoch_info']['epochs_after_lights_off'] = epochsAfterLightsOff
        scoring_json['epoch_info']['epoch_duration'] = epochLength
        
        # time info: entire study (utc and local)
        studyStart_utc = sync_file.interp_stamps(studyStartStamp)
        studyStart_local = studyStart_utc + utc_to_local_diff
        print(f"\tTime Info: entire study")
        print(f"\t\tStart UTC time: {str(studyStart_utc)}")
        print(f"\t\tStart Local time: {str(studyStart_local)}")
        print(f"\t\tStart sample stamp: {studyStartStamp}")
        print(f"\t\tSampling Frequency: {samplingFreq}")
        
        scoring_json['time_info'] = {'study': {}, 'epoch_one_lights_off': {}}
        scoring_json['time_info']['study']['start_utc'] = str(studyStart_utc)
        scoring_json['time_info']['study']['start_local'] = str(studyStart_local)
        scoring_json['time_info']['study']['start_stamp'] = studyStartStamp
        scoring_json['time_info']['study']['sampling_frequency'] = samplingFreq
        
        # time info: first epoch (utc and local)
        epochOne_utc = sync_file.interp_stamps(epochOneStamp)
        epochOne_local = epochOne_utc + utc_to_local_diff
        print(f"\tTime Info: first epoch AFTER LIGHTS OFF")
        print(f"\t\tStart UTC time: {str(epochOne_utc)}")
        print(f"\t\tStart Local time: {str(epochOne_local)}")
        print(f"\t\tStart sample stamp: {epochOneStamp}")
        
        scoring_json['time_info']['epoch_one_lights_off']['start_utc'] = str(epochOne_utc)
        scoring_json['time_info']['epoch_one_lights_off']['start_local'] = str(epochOne_local)
        scoring_json['time_info']['epoch_one_lights_off']['start_stamp'] = epochOneStamp
        
        storage_name: str
        storage: EpoStorage
        for storage_name, storage in storage_dict.items():
            
            # handle sleep stage channel (unique scoring set)
            if storage.channelType == ChannelType.CH_STAGE:
                # get details for this storage channel
                channelInfoBasic: ChannelInfoBasic = storage.channelInfoBasic
                friendlyName = channelInfoBasic.friendlyName
                scoring_json['scoring_set'] = {'friendly_name': friendlyName, 'storage_name': storage_name}
                print(f"Found Scoring Set: {friendlyName}({storage_name}) ")
                
                # get all ent_list items where item['ScoringSet'] == storage_name
                scoring_json['annotations'] = _filter_annotations(ent_list, storage_name, utc_to_local_diff, include_global_annotations=False)
                
                # get sleep stages
                scoring_json['sleep_stages'] = {}
                sleep_stages: np.ndarray[str] = storage.channelRawData.as_sleep_stages()
                
                # Case: before Lights Off
                # NOTE: epoch index is NEGATIVE for epochs before Lights Off (there is no epoch 0))
                before_lights_off_entries = _create_stage_entries(sleep_stages[:epochsBeforeLightsOff],
                                                                 -1 * epochsBeforeLightsOff,
                                                                 studyStartStamp,
                                                                 epochLength * samplingFreq,
                                                                 int(study_duration_ms / 1000 * samplingFreq),
                                                                 utc_to_local_diff,
                                                                 sync_file)
                # Case: after Lights Off
                # NOTE: epoch index is POSITIVE for epochs after Lights Off to match SleepWorks
                after_lights_off_entries = _create_stage_entries(sleep_stages[epochsBeforeLightsOff:],
                                                                1,
                                                                epochOneStamp,
                                                                epochLength * samplingFreq,
                                                                int(study_duration_ms / 1000 * samplingFreq),
                                                                utc_to_local_diff,
                                                                sync_file)
                # write the list to a json file
                scoring_json['sleep_stages'] = before_lights_off_entries + after_lights_off_entries
        
                # write all epochs to json file
                with open(f"{output_prefix}.{friendlyName}.scoring.json", "w") as f:
                    f.write(json.dumps(scoring_json, indent=2))
                    
                # write sleep stages to csv
                if len(scoring_json['sleep_stages']) > 0:
                    df = pd.json_normalize(scoring_json['sleep_stages'])
                    with open(f"{output_prefix}.{friendlyName}.sleep_stages.csv", "w") as f:
                        df.to_csv(f, index=False, date_format=UTC_FORMAT, lineterminator='\n')
                
                # write annotations to csv
                if len(scoring_json['annotations']) > 0:
                    df = pd.json_normalize(scoring_json['annotations'])
                    df_cols = [col for col in df.columns.tolist() if col not in ['GUID', 'Host']]
                    with open(f"{output_prefix}.{friendlyName}.annotations.csv", "w") as f:
                        df.to_csv(f, index=False, date_format=UTC_FORMAT, lineterminator='\n', columns=df_cols)
            
        print("Done")

# main function
if __name__ == '__main__':
    data_folder = 'D:\studies'
    all_items = os.listdir(data_folder)
    study_folders = [item for item in all_items if os.path.isdir(os.path.join(data_folder, item))]
    for study_folder in study_folders:
        epo_scoring_set_to_json(data_folder, study_folder)
