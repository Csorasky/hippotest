import numpy as np
import xarray as xr

from nwreader.edf_reader import read_edf

from .conftest import EDF_FILE_0

import dask

# https://docs.dask.org/en/stable/scheduling.html
# The pyedf reader has a hard time with the default dask scheduler
dask.config.set(scheduler="processes")


def read_sample_edf():
    import pyedflib

    with pyedflib.EdfReader(EDF_FILE_0) as f:
        num_channels = f.signals_in_file
        sigbufs = np.zeros((num_channels, f.getNSamples()[0]), dtype="i4")
        for i in np.arange(num_channels):
            sigbufs[i, :] = f.readSignal(i, digital=True)

    return sigbufs


def test_read_edf():
    ret = read_edf(EDF_FILE_0)

    assert isinstance(ret, xr.DataArray)
    assert ret.data.dtype == np.dtype("int32")
    assert ret.shape[0] == 42

    exp_nsamples = 15000
    assert ret.shape[1] == exp_nsamples
    assert ret.sample.data.shape == (ret.shape[1],)

    exp_data = read_sample_edf()
    assert np.array_equal(ret.data.compute(), exp_data)

    assert "channel" in ret.dims
    assert "sample" in ret.dims

    assert "C3" in ret.channel.data
    assert "CHEST" in ret.channel.data

    duration = ret.timestamp[-1] - ret.timestamp[0]
    assert duration.data == np.timedelta64(75, "s")
