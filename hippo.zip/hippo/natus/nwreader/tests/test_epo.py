from nwreader.epo_reader import read_epo_file
from nwreader.epo_reader import EpoFile, EpoStorage, ChannelType, EpochInfo

from .conftest import EPO_FILE_0

def test_epo_file():
    epoFile: EpoFile = read_epo_file(EPO_FILE_0)
    storage_dict = epoFile.storages
    assert len(storage_dict) == 32
    
    header = epoFile.header
    epochInfo: EpochInfo = header.epochInfo
    assert (epochInfo.epochsAfterLightsOff + epochInfo.epochsBeforeLightsOff == 959)
    assert epochInfo.studyStartStamp == 3524463
    
    storage_name: str
    storage: EpoStorage
    for storage_name, storage in storage_dict.items():
        if storage.channelType == ChannelType.CH_STAGE:
            sleep_stages = storage.channelRawData.as_sleep_stages()
            assert len(sleep_stages) == 960
            assert sleep_stages[0] == 'UNSCORED'
            assert sleep_stages[-1] == 'UNSCORED'
            
            rem = [stage for stage in sleep_stages if stage == 'REM']
            assert len(rem) == 40
        elif storage.channelType == ChannelType.CH_MARK:
            marks = storage.channelRawData.as_bytes()
            assert len(marks) == 960
            assert all(mark == 0 for mark in marks)
