from datetime import datetime, timezone
from uuid import UUID

from nwreader.header_reader import GenericHeader
from .conftest import TOC_FILE_0, ERD_FILE_0


def test_generic_file_header_toc():
    with open(TOC_FILE_0, "rb") as f:
        header = GenericHeader.from_file(f)

    assert header.guid == UUID('ca0b0792-d795-11d0-af32-00a0245b54a5')
    assert header.schema == 3
    assert header.base_schema == 1
    assert header.creation_time == datetime(2004, 9, 9, 14, 49, 24, tzinfo=timezone.utc)
    assert header._study_id == 0
    assert header.last_name == "sample"
    assert header.first_name == ""
    assert header.middle_name == "data"
    assert header.patient_id == ""


def test_generic_file_header_erd():
    with open(ERD_FILE_0, "rb") as f:
        header = GenericHeader.from_file(f)

    assert header.guid == UUID('ca0b0791-d795-11d0-af32-00a0245b54a5')
    assert header.schema == 8
    assert header.base_schema == 1
    assert header.creation_time == datetime(2004, 9, 9, 14, 49, 24, tzinfo=timezone.utc)
    assert header._study_id == 0
    assert header.last_name == "sample"
    assert header.first_name == ""
    assert header.middle_name == "data"
    assert header.patient_id == ""
