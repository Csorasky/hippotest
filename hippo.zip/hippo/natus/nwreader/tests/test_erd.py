from datetime import datetime
from uuid import UUID
import json
import warnings
import numpy as np
import xarray as xr

from nwreader.erd_reader import (
    read_block,
    read_erd,
    RawDataSegment,
    RawDataHeader,
)

from .conftest import DATA_PATH, STUDY_PATH_0, TOC_FILE_0, ERD_FILE_0, ERD_PART_0_TESTVECTOR


def test_read_toc_entries():
    with open(TOC_FILE_0, "rb") as f:
        entries = RawDataSegment.read_toc_entries(f)

    assert len(entries) == 16
    assert entries[0]["offset"] == 8656
    assert entries[0]["samplestamp"] == 712
    assert entries[0]["sample_num"] == 0
    assert entries[0]["sample_span"] == 288


def test_read_raw_data_header():
    with open(ERD_FILE_0, "rb") as f:
        header = RawDataHeader.from_file(f)

    assert header.sample_freq == 200.0
    assert header.num_channels == 42
    assert header.deltabits == 8
    assert header.headbox_sn == 65535
    assert header.headbox_type == 5
    assert header.headbox_sw_version == "3.6"
    assert header.dsp_hw_version == "0.0"
    assert header.dsp_sw_version == "0.0"
    assert header.discardbits == 6
    assert np.array_equal(header._saved_phys_chans, np.asarray([0, 26]))

    # all 1s except for index 0 and 26
    shorted_expected = np.zeros(42) + 1
    shorted_expected[0] = 0
    shorted_expected[26] = 0
    assert np.array_equal(header.shorted, shorted_expected)

    idxs_expected = np.asarray([0, 26])
    assert np.array_equal(header._recorded_channel_idxs, idxs_expected)

    # all "same as headbox frequency" except the 26th channel
    freq_factor_expected = np.asarray([1, 4])
    assert np.array_equal(header._derived_frequency_factor, freq_factor_expected)


def test_read_block():
    with open(ERD_FILE_0, "rb") as f:
        f.seek(8656)  # first sample entry
        buffer = f.read(2932)
        nchannels = 2
        nsamples = 288
        delta_mask_size = 6
        freq_factor_arr = np.asarray([1, 4], dtype="i2")
        recorded_channel_idxs = np.asarray([0, 26]).astype("int64")

        event_arr = np.zeros(nsamples, dtype="u1")
        sample_arr = np.zeros((nchannels, nsamples), dtype="i4")

        values_state = np.zeros([len(recorded_channel_idxs), 2], dtype="int32")
        phases_state = np.zeros([len(recorded_channel_idxs), 2], dtype="uint8")

        read_block(
            buffer,
            freq_factor_arr,
            delta_mask_size,  # math.ceil(num_channels / 8)
            recorded_channel_idxs,
            values_state,
            phases_state,
            event_arr,
            sample_arr,
        )

    # block samples extracted using the legacy SDK, rightshifted (>>) by discardbits
    expected_channel_0 = np.asarray([8661, 8739, 8047, 8421, 8907, 8237, 8161, 8860, 8476, 7998, 8660, 8719, 8019, 8394, 8880, 8221, 8170, 8878, 8503, 8035, 8693, 8733, 8021, 8392, 8853, 8185, 8145, 8853, 8467, 7998, 8654, 8700, 7996, 8371, 8836, 8172, 8129, 8833, 8450, 7993, 8654, 8688, 7985, 8366, 8822, 8156, 8118, 8822, 8435, 7985, 8661, 8699, 7995, 8378, 8830, 8153, 8116, 8822, 8427, 7972, 8643, 8678, 7980, 8376, 8835, 8159, 8125, 8825, 8419, 7961, 8624, 8636, 7935, 8344, 8803, 8131, 8115, 8825, 8424, 7987, 8668, 8677, 7969, 8362, 8803, 8118, 8095, 8793, 8390, 7964, 8648, 8667, 7979, 8389, 8825, 8140, 8116, 8803, 8389, 7961, 8647, 8675, 7998, 8429, 8867, 8183, 8172, 8860, 8428, 7989, 8664, 8670, 7983, 8405, 8843, 8153, 8142, 8833, 8410, 7988, 8661, 8645, 7942, 8348, 8763, 8070, 8081, 8785, 8376, 7970, 8661, 8660, 7979, 8402, 8817, 8127, 8133, 8817, 8383, 7973, 8659, 8645, 7965, 8399, 8815, 8129, 8140, 8811, 8362, 7945, 8621, 8597, 7918, 8357, 8774, 8092, 8124, 8811, 8365, 7953, 8637, 8605, 7917, 8348, 8747, 8049, 8070, 8752, 8317, 7933, 8643, 8630, 7959, 8405, 8791, 8090, 8122, 8795, 8338, 7937, 8638, 8636, 7998, 8462, 8861, 8159, 8190, 8865, 8411, 8010, 8681, 8623, 7942, 8397, 8805, 8134, 8198, 8877, 8411, 8014, 8705, 8655, 7975, 8428, 8820, 8132, 8197, 8881, 8429, 8058, 8759, 8701, 8006, 8455, 8838, 8132, 8178, 8833, 8352, 7972, 8672, 8621, 7957, 8420, 8800, 8101, 8165, 8844, 8380, 8012, 8718, 8668, 8004, 8482, 8861, 8164, 8238, 8902, 8414, 8034, 8724, 8648, 7986, 8459, 8827, 8115, 8175, 8838, 8357, 7999, 8701, 8627, 7963, 8434, 8784, 8071, 8153, 8830, 8365, 8017, 8721, 8644, 7972, 8439, 8785, 8068, 8141, 8796, 8299, 7942, 8648, 8575, 7931, 8423, 8787, 8090, 8180, 8833, 8333, 7980, 8679, 8592, 7947, 8436, 8782, 8076, 8177, 8837], dtype="i4")  # fmt: skip
    expected_channel_26 = np.asarray([5119, 5119, 5119, 5119, 5119, 5150, 5181, 5212, 5243, 5276, 5309, 5342, 5376, 5406, 5437, 5467, 5498, 5529, 5560, 5591, 5622, 5656, 5691, 5726, 5761, 5799, 5837, 5875, 5914, 5951, 5988, 6025, 6062, 6095, 6129, 6163, 6197, 6232, 6267, 6302, 6338, 6377, 6416, 6455, 6494, 6537, 6580, 6623, 6666, 6706, 6746, 6786, 6827, 6864, 6901, 6938, 6976, 7014, 7052, 7090, 7129, 7169, 7210, 7250, 7291, 7333, 7376, 7419, 7462, 7503, 7544, 7585, 7627, 7662, 7698, 7734, 7770, 7805, 7841, 7877, 7913, 7952, 7991, 8030, 8070, 8111, 8152, 8193, 8235, 8274, 8314, 8353, 8393, 8427, 8462, 8496, 8531, 8566, 8601, 8636, 8672, 8709, 8746, 8783, 8821, 8860, 8900, 8939, 8979, 9017, 9056, 9094, 9133, 9168, 9203, 9238, 9274, 9309, 9344, 9379, 9415, 9451, 9488, 9524, 9561, 9598, 9636, 9673, 9711, 9744, 9777, 9810, 9843, 9871, 9900, 9929, 9958, 9985, 10013, 10041, 10069, 10098, 10128, 10157, 10187, 10217, 10247, 10277, 10308, 10335, 10363, 10391, 10419, 10443, 10467, 10491, 10516, 10541, 10566, 10591, 10616, 10643, 10670, 10697, 10724, 10752, 10781, 10809, 10838, 10863, 10889, 10914, 10940, 10961, 10983, 11004, 11026, 11046, 11067, 11087, 11108, 11130, 11153, 11175, 11198, 11222, 11247, 11271, 11296, 11317, 11338, 11359, 11380, 11397, 11414, 11431, 11449, 11466, 11484, 11501, 11519, 11539, 11559, 11579, 11599, 11620, 11642, 11663, 11685, 11703, 11722, 11740, 11759, 11774, 11789, 11804, 11819, 11834, 11849, 11864, 11879, 11896, 11913, 11930, 11947, 11965, 11984, 12002, 12021, 12036, 12051, 12066, 12081, 12092, 12103, 12114, 12126, 12137, 12148, 12159, 12171, 12184, 12198, 12212, 12226, 12240, 12255, 12270, 12285, 12297, 12309, 12321, 12334, 12342, 12350, 12358, 12366, 12374, 12382, 12390, 12398, 12408, 12419, 12430, 12441, 12453, 12465, 12477, 12489, 12498, 12507, 12516, 12526, 12530, 12535, 12539, 12544, 12546, 12549, 12551, 12554, 12556, 12558, 12560, 12563, 12563, 12564, 12565], dtype="i4")  # fmt: skip

    assert np.all(event_arr == 0)
    np.testing.assert_array_equal(sample_arr[0], expected_channel_0)
    np.testing.assert_array_equal(sample_arr[1], expected_channel_26)


def test_read_erd_part():
    with open(ERD_PART_0_TESTVECTOR, 'r') as f:
        test_vector = json.load(f)

    nchannels = 2
    nsamples = 14469
    freq_factor_arr = np.asarray([1, 4], dtype="i2")
    recorded_channel_idxs = np.asarray([0, 26])

    segment = RawDataSegment.from_filepair(
        ERD_FILE_0,
        TOC_FILE_0,
    )

    np.testing.assert_array_equal(freq_factor_arr, segment.data_header._derived_frequency_factor)
    np.testing.assert_array_equal(recorded_channel_idxs, segment.data_header._recorded_channel_idxs)

    assert isinstance(segment.samples, np.ndarray)
    assert isinstance(segment.events, np.ndarray)
    assert np.array_equal(segment.sample_stamps, np.arange(712, 712 + nsamples))

    assert segment.samples.shape == (nchannels, nsamples)
    assert segment.samples.dtype == np.dtype("i4")
    assert segment.events.shape == (nsamples,)
    assert segment.events.dtype == np.dtype("u1")

    sample_arr = segment.samples

    subsampled_idxs = [i for i in range(nsamples) if i % 4 == 0]
    assert np.count_nonzero(sample_arr[1][subsampled_idxs] == 0) == 0

    expected_channel_0 = np.asarray(test_vector['0'], dtype="i4")
    expected_channel_26 = np.asarray(test_vector['26'], dtype="i4")

    np.testing.assert_array_equal(sample_arr[0], expected_channel_0, verbose=True)
    np.testing.assert_array_equal(sample_arr[1], expected_channel_26, verbose=True)


def test_read_erd_dir() -> None:
    with warnings.catch_warnings(record=True) as w:
        ret = read_erd(STUDY_PATH_0, ignore_stc=True)
        assert len(w) == 1

    assert isinstance(ret, xr.DataArray)

    assert ret.data.dtype == np.dtype("int32")
    assert ret.shape[0] == 2

    exp_nsamples = 14470
    assert ret.shape[1] == exp_nsamples
    assert np.all(ret.event == 0)

    assert "channel" in ret.dims
    assert "sample" in ret.dims

    assert np.array_equal(ret.channel.data, np.asarray(["C3", "CHEST"]))
    assert ret.sample.data.shape == (ret.shape[1],)

    assert isinstance(ret.attrs["guid"], UUID)
    assert isinstance(ret.attrs["last_name"], str)
    assert isinstance(ret.attrs["middle_name"], str)
    assert isinstance(ret.attrs["first_name"], str)
    assert isinstance(ret.attrs["schema"], int)
    assert isinstance(ret.attrs["base_schema"], int)
    assert isinstance(ret.attrs["num_channels"], int)
    assert isinstance(ret.attrs["deltabits"], int)
    assert isinstance(ret.attrs["sample_freq"], float)
    assert isinstance(ret.attrs["creation_time"], datetime)
    assert isinstance(ret.attrs["phys_chan_order"], np.ndarray)
    assert isinstance(ret.attrs["_recorded_channel_idxs"], np.ndarray)
    assert isinstance(ret.attrs["frequency_factor"], np.ndarray)

    ret.load()

    subsampled_idxs = [0] + [i for i in range(exp_nsamples) if (i - 1) % 4 == 0]
    assert np.count_nonzero(ret.data[1][subsampled_idxs] == 0) == 0


def test_read_erd_convert():
    with warnings.catch_warnings(record=True) as w:
        ret = read_erd(STUDY_PATH_0, convert=True, ignore_stc=True)
        assert len(w) == 1

    print(ret.attrs)
    # FIX: these don't currently match the EDF
    assert isinstance(ret, xr.DataArray)
    assert ret.data.dtype == np.dtype("float32")


def test_read_erd_range():
    with warnings.catch_warnings(record=True) as w:
        ret = read_erd(STUDY_PATH_0, parts=[1], ignore_stc=True)
        assert len(w) == 1

    assert isinstance(ret, xr.DataArray)
