from __future__ import annotations

import math
import os

# from collections.abc import Iterable
from typing import Iterable, Tuple
from dataclasses import dataclass, asdict
from functools import partial
from glob import glob
from io import BufferedReader
from itertools import chain
from typing import Optional, ClassVar, Tuple
from uuid import UUID

import numpy as np
import struct
import xarray as xr
import warnings

from .fast.erd import read_block
from .utils import b_to_str
from .header_reader import GenericHeader
from .snc_reader import SyncFile
from .erd_schema import SHRT_MAX, CHANNEL_LABELS, CONVERSION_FACTORS

ERD_HEADER_LEN = 8304
ERD_TYPE_GUID = UUID('ca0b0791-d795-11d0-af32-00a0245b54a5')
ETCTOC_TYPE_GUID = UUID('ca0b0792-d795-11d0-af32-00a0245b54a5')
ETCTOC_SCHEMAS = {3}  # set containing implemented schemas
STC_TYPE_GUID = UUID('e9b71278-a84b-4d59-bf87-10728fb8bd9d')
STC_SCHEMAS = {1}  # set containing implemented schemas

# set of supported ERD schemas is set intersection
# of CHANNEL_LABELS and CONVERSION_FACTORS from .erd_schma module
ERD_SCHEMAS = CONVERSION_FACTORS.keys() & CHANNEL_LABELS.keys()


# START BLOCK STC HANDLING
@dataclass
class STCSegment:
    """A single Study Table of Contents segment, contained in .stc
    type files. It is used for rapid seeking of samples in a directory,
    where the sample can belong to any number of .erd/.etc files.
    We expand this out to contain filename, tocname.
    """
    ENCODING: ClassVar[str] = "<256siiii"
    # note: STC_ENCODING is a class variable

    filename: str
    tocname: str
    start_stamp: Optional[int] = None
    end_stamp: Optional[int] = None
    sample_num: Optional[int] = None
    sample_span: Optional[int] = None

    @staticmethod
    def name_to_erdetcpair(input: str) -> Tuple[str, str]:
        """
        Args:
            input (str): path/to/Sample_Data
                         path/to/Sample_Data.xxx

        Returns:
            tuple[str, str]: (
                path/to/Sample_Data.erd,
                path/to/Sample_Data.etc
            )
        """
        basename = os.path.splitext(input)[0]
        return (basename + ".erd", basename + ".etc")

    def with_suffix(self, suffix: str) -> str:
        """Returns self.filename with a different suffix

        Args:
            suffix (str): .snc

        Returns:
            str: basename.snc
        """
        if not suffix.startswith("."):
            suffix = "." + suffix
        basename = os.path.splitext(self.filename)[0]
        return basename + suffix

    @classmethod
    def from_segment_buf(cls, b: bytes, dirpath: str = None) -> 'STCSegment':
        """Each 272-byte STC entry containing a CString filename,
        start and end stamps in each ERD / ETC pair,
        sample_num which is number of accumulated samples recorded
        equal to sample_num of the first entry in the ETC file,
        and number of samples from this stc entry to the next.

        Args:
            b (bytes): buffer containing 272-byte entry
            dirpath (str): dirpath to prepend to each file
        """
        filename_b, start_stamp, end_stamp, sample_num, sample_span = \
            struct.unpack(cls.ENCODING, b)

        filename_str = b_to_str(filename_b)

        if dirpath:
            filename_str = os.path.join(dirpath, filename_str)

        filename, tocname = cls.name_to_erdetcpair(filename_str)
        return cls(
            filename, tocname, start_stamp, end_stamp, sample_num, sample_span
        )

    @classmethod
    def from_filename_only(cls, filenamein: str) -> 'STCSegment':
        """Fakes an STC entry from globbed filenames only. This
        is used if the .stc file is to be ignored, or is lost
        and data must be recovered from .erd/.etc pairs only.

        Args:
            filenamein (str): filename (usually .erd)
        """
        filename, tocname = cls.name_to_erdetcpair(filenamein)
        return cls(filename, tocname)


class STCSegmentsList(list):
    """A list containing multiple STCSegment elements.
    @TODO: This can later having seeking methods that spit out a
    STCSegment that contain an arbitrary sample.
    Right now, only constructor methods are supported.
    """

    def basename_with_suffix(self, suffix: str) -> str:
        """Return the first STCSegment file name with
        a replaced suffix. Usually used to obtain the base
        study + another file type suffix.

        Args:
            suffix (str): Something like ".snc"

        Returns:
            str: a filename, e.g. basename.snc
        """
        if len(self) < 1:
            return IndexError("STCSegmentsList is empty")
        return self[0].with_suffix(suffix)

    def filter_parts(self, partslist: Iterable[int]) -> 'STCSegmentsList':
        """Select specific segments of the segment list only.
        CAVEATS: does not modify in-place, instead returns a new class obj
        so use it as: new_obj = old_obj.filter_parts(parts)
        Additionally, following previous implementor logic, currently
        the 1-sample initiation .erd without _xxx is kept no matter what.
        This may or may not be a wise design choice.

        Args:
            partslist (Iterable[int]): a list of int parts, like [1, 2]

        Returns:
            self.__class__: A new filtered STCSegmentsList
        """
        parts = {f"{part:03d}" for part in partslist}
        return self.__class__([f for f in self if f.filename[-8] != "_" or
                               f.filename[-7:][:3] in parts])

    @classmethod
    def from_stc_segment(cls, f: BufferedReader, dirpath: str = None) -> 'STCSegmentsList':
        gheader = GenericHeader.from_file(f)
        gheader.validate_guid(STC_TYPE_GUID)
        gheader.validate_schemas(STC_SCHEMAS)

        num_segments, m_final, _ = struct.unpack("<ii48s", f.read(56))
        num_segments += 1
        # +1 because there is a bare .etc/.erd, then follows num_segments _xxx .etc/.erd pairs

        entries = []
        for buf in iter(partial(f.read, struct.calcsize(STCSegment.ENCODING)), b''):
            entries.append(STCSegment.from_segment_buf(buf, dirpath))

        if len(entries) != num_segments:
            warnings.warn('Number of STC entries {} did not match header count {}'.format(
                len(entries), num_segments
            ))

        return cls(entries)

    @classmethod
    def from_stc_dirpath(cls, dirpath: str) -> 'STCSegmentsList':
        """Helper to read stc segment lists, and also wrap a study dir for easier handling

        Args:
            dirpath (str): parent study directory to open
        """
        stc = glob(os.path.join(dirpath, "*.stc"))
        if len(stc) != 1:
            # There should only be a single *.stc in a study dir
            raise ValueError("Irregular number of study .stc files found. \
                Please verify valid NeuroWorks study.")

        with open(stc[0], 'rb') as f:
            return cls.from_stc_segment(f, dirpath)

    @classmethod
    def from_globbed_only_path(cls, dirpath: str) -> 'STCSegmentsList':
        """Fakes a STCSegmentsList from only a set of globbed paths.
        This is used if the .stc file is to be ignored, or is lost
        and data must be recovered from .erd/.etc pairs only.

        Args:
            dirpath (str): parent study directory to open
        """
        erd_files = sorted(glob(os.path.join(dirpath, "*.erd")))
        entries = [
            STCSegment.from_filename_only(seg) for seg in erd_files
        ]
        return cls(entries)


# END STC HANDLING


@dataclass
class RawDataHeader:
    """Class to encapsulate raw data (.erd) headers info
    """
    sample_freq: float  # Sample frequency in Hertz.
    num_channels: int  # Number of channels stored.
    deltabits: int  # Number of bits of delta info / channel. (only = 8 supported)
    phys_chan_order: np.ndarray[np.int32]  # Storage order to physical channel assignments.
    headbox_type: int
    headbox_sn: int  # Serial number of the headboxes.
    headbox_sw_version: str  # Headbox software version number: (major_rev.minor_rev).
    dsp_hw_version: str
    dsp_sw_version: str
    discardbits: int  # Number of least significant bits to discard when storing.
    shorted: np.ndarray[np.bool_]  # 0’s indicate recorded channels, 1’s are shorted
    frequency_factor: np.ndarray[np.int16]  # 0’s indicate recorded channels
    # Frequency multipliers:
    # SHRT_MAX indicates headbox frequency, 20 – every 20th sample, 4 – every 4th sample etc.

    # derived from indices of shorted[:num_channels] == 0
    _recorded_channel_idxs: np.ndarray[np.intp]

    # derived from phys_chan_order[_recorded_channel_idxs]
    # also see comments in .from_buffer() to see the interchangability
    # between _recorded_channel_idxs and _saved_phys_chans
    _saved_phys_chans: np.ndarray[np.int32]

    # derived from frequency_factor[_recorded_channel_idxs]
    _derived_frequency_factor: np.ndarray[np.int16]

    def as_dict(self) -> dict:
        """serializes self as dict
        """
        return asdict(self)

    def merge(self, headers: Iterable['RawDataHeader']) -> 'RawDataHeader':
        """Merge this instance of data header with others

        Args:
            headers (Iterable[RawDataHeader]): an iterable list of headers

        Raises:
            ValueError: mismatch in study conditions across headers
            ValueError: unified channelset did not verify using 2 methods

        Returns:
            RawDataHeader: a copy of RawDataHeader merged
        """

        unified_recordset = set(self._recorded_channel_idxs.copy())  # need to compute union set
        unified_shorted = self.shorted.copy()  # need to compute max set

        for seg_ in headers:
            if (
                    # these should all exactly match; the only thing that gets
                    # to change in the middle of a study is channel on/off in the
                    # form of changing m_shorted
                    seg_.sample_freq != self.sample_freq or
                    seg_.num_channels != self.num_channels or
                    seg_.deltabits != self.deltabits or
                    not np.array_equal(seg_.phys_chan_order, self.phys_chan_order) or
                    seg_.headbox_type != self.headbox_type or
                    seg_.headbox_sn != self.headbox_sn or
                    seg_.headbox_sw_version != self.headbox_sw_version or
                    seg_.dsp_hw_version != self.dsp_hw_version or
                    seg_.dsp_sw_version != self.dsp_sw_version or
                    seg_.discardbits != self.discardbits or
                    not np.array_equal(seg_.frequency_factor, self.frequency_factor)
            ):
                raise ValueError('merging headers show mismatching study conditions')

            unified_recordset.update(set(seg_._recorded_channel_idxs))
            # equivalent to ~np.logical_or(~unified_shorted, ~seg_.shorted)
            # because any time it's not shorted, it must remain not shorted
            # False & True = False
            unified_shorted = np.logical_and(unified_shorted, seg_.shorted)

        # these are two separate methods of computing the unified, non-shorted
        # channel set
        unified_recorded_channel_idxs = np.array(
            sorted(list(unified_recordset)), dtype='int16'
        )
        unified_idxs = (unified_shorted == 0).nonzero()[0]

        if not np.array_equal(unified_recorded_channel_idxs, unified_idxs):
            raise ValueError('Cannot verify RawData recorded channels unionset merging')

        unified_saved_phys_chans = self.phys_chan_order.copy()
        unified_saved_phys_chans = unified_saved_phys_chans[unified_idxs]
        unified_frequency_factor = self.frequency_factor[unified_idxs].copy()
        unified_frequency_factor[unified_frequency_factor == SHRT_MAX] = 1

        # return a duplicate class with everything the same,
        # but shorted and recorded_idx merged iteratively as above
        return self.__class__(
            self.sample_freq,
            self.num_channels,
            self.deltabits,
            self.phys_chan_order.copy(),
            self.headbox_type,
            self.headbox_sn,
            self.headbox_sw_version,
            self.dsp_hw_version,
            self.dsp_sw_version,
            self.discardbits,
            unified_shorted,
            self.frequency_factor.copy(),
            unified_idxs,
            unified_saved_phys_chans,
            unified_frequency_factor
        )

    @classmethod
    def from_buffer(cls, buf: bytes, schema=9) -> 'RawDataHeader':
        """Generates dataclass from from bytes buffer of size ERD_HEADER_LEN.

        Args:
            buf (bytes): should be of size ERD_HEADER_LEN
            schema (int, optional): from GenericHeader. Defaults to 9.

        Raises:
            NotImplementedError: If not schema 8, 9
        """
        if schema not in ERD_SCHEMAS:
            raise NotImplementedError("Only RawDataHeader schema 8, 9 implemented")

        (sample_freq, num_channels, deltabits) = struct.unpack_from("<dii", buf, 0)
        phys_chan_order = np.frombuffer(buf[16:4112], dtype="<i4", count=1024)
        headbox_type = struct.unpack_from("<iiii", buf, 4112)
        headbox_sn = struct.unpack_from("<iiii", buf, 4128)
        headbox_sw_version = struct.unpack_from("<10s10s10s10s", buf, 4144)
        headbox_sw_version = tuple(b_to_str(vbuf) for vbuf in headbox_sw_version)
        (dsp_hw_version, dsp_sw_version, discardbits) = \
            struct.unpack_from("<10s10si", buf, 4184)
        dsp_hw_version = b_to_str(dsp_hw_version)
        dsp_sw_version = b_to_str(dsp_sw_version)
        shorted = np.frombuffer(buf[4208:6256], dtype="<i2", count=1024)
        frequency_factor = np.frombuffer(buf[6256:8304], dtype="<i2", count=1024)

        # postprocess
        # modification from spec: seems to care about only first of 4 elements
        headbox_type = headbox_type[0]
        headbox_sn = headbox_sn[0]
        headbox_sw_version = headbox_sw_version[0]
        phys_chan_order = phys_chan_order[:num_channels]
        shorted = shorted[:num_channels].astype(dtype='bool')
        _recorded_channel_idxs = (shorted == 0).nonzero()[0]
        _saved_phys_chans = phys_chan_order[_recorded_channel_idxs]  # in practice,
        # there should be no difference between _saved_phys_chans and _recorded_channel_idxs
        # and they can be used effectively interchangably, and that's because phys_chan_order
        # is defined in schema as always as a continuous range 0...512.
        # In theory, this could change in a future schema, where phys_chan_order does not
        # start at 0 or is not a monotonically increasing range, depending on hardware protocol
        # definitions, so we preserve the distinction here. Guidelines:
        # - use _recorded_channel_idxs for tasks related to unpacking .erd file compression
        # - use _saved_phys_chans for hardware protocol tasks, like channel label lookup tables
        _derived_frequency_factor = frequency_factor[_recorded_channel_idxs].copy()
        _derived_frequency_factor[_derived_frequency_factor == SHRT_MAX] = 1

        return cls(
            sample_freq,
            num_channels,
            deltabits,
            phys_chan_order,
            headbox_type,
            headbox_sn,
            headbox_sw_version,
            dsp_hw_version,
            dsp_sw_version,
            discardbits,
            shorted,
            frequency_factor,
            _recorded_channel_idxs,
            _saved_phys_chans,
            _derived_frequency_factor
        )

    @classmethod
    def from_file(cls, f: BufferedReader) -> 'RawDataHeader':
        """Generates dataclass from from file handle of .erd.

        Args:
            f (BufferedReader): file handle to open .erd
        """
        gheader = GenericHeader.from_file(f)
        gheader.validate_guid(ERD_TYPE_GUID)
        gheader.validate_schemas(ERD_SCHEMAS)

        buf = f.read(ERD_HEADER_LEN)
        return cls.from_buffer(buf, schema=gheader.schema)


@dataclass
class RawDataSegment:
    """Class to encapsulate a Raw Data segment (a single .erd file)."""
    sample_stamps: np.ndarray
    samples: np.ndarray
    events: np.ndarray
    generic_header: GenericHeader
    data_header: RawDataHeader

    def merge(self, segments: Iterable['RawDataSegment']) -> 'RawDataSegment':
        """Extends this RawDataSegment with more RawDataSegments,
        creating a unified channel set and filling in the rest with
        zeros

        Args:
            segments (Iterable[RawDataSegment]): a list of RawDataSegments
            to join together

        Returns:
            RawDataSegment: big RawDataSegment containing all the segments
        """
        # performs identity checks and merges generic headers
        genericheaders_to_merge = [seg_.generic_header for seg_ in segments]
        unified_generic_header = self.generic_header.merge(genericheaders_to_merge)

        # performs identity checks and merges data headers, esp channel sets
        headers_to_merge = [seg_.data_header for seg_ in segments]
        unified_data_header = self.data_header.merge(headers_to_merge)

        # derive the first dim of the array
        unified_channel_list = unified_data_header._recorded_channel_idxs.tolist()
        # to use .index() later
        dim1len = len(unified_channel_list)

        # figure out the 2nd dim of the array
        dim2len = self.sample_stamps.shape[0]
        for seg_ in segments:
            dim2len += seg_.sample_stamps.shape[0]

        # perform the raw data joins
        samples = np.zeros((dim1len, dim2len), dtype='int32')  # init zeros
        insert_start = 0
        for seg_ in chain([self], segments):  # don't forget self to start
            block_chs = np.asarray([
                unified_channel_list.index(ch)
                for ch in seg_.data_header._recorded_channel_idxs
            ])
            samples[block_chs, insert_start:(insert_start + seg_.samples.shape[1])] = seg_.samples
            insert_start += seg_.samples.shape[1]

        events = np.concatenate(
            [seg_.events for seg_ in chain([self], segments)]
        )
        sample_stamps = np.concatenate(
            [seg_.sample_stamps for seg_ in chain([self], segments)]
        )

        return self.__class__(
            sample_stamps, samples, events, unified_generic_header, unified_data_header
        )

    @staticmethod
    def join_segments(segments: Iterable['RawDataSegment']) -> 'RawDataSegment':
        """Helper wrapper on this class's merge method, to operate externally
        on a list of this class

        Args:
            segments (Iterable[RawDataSegment]): iterable of RawDataSegments to
            merge together

        Raises:
            ValueError: iterable contains nothing
            TypeError: iterable contained non-RawDataSegment items

        Returns:
            RawDataSegment: joined RawDataSegment
        """
        segments_list = list(segments)
        if len(segments_list) < 1:
            raise ValueError("No segments found to merge")

        if not all(isinstance(item, RawDataSegment) for item in segments_list):
            raise TypeError("join_segments() can only be used on RawDataSegments")

        return segments_list[0].merge(segments_list[1:])

    @property
    def channel_labels(self) -> np.ndarray[np.str_]:
        reference_labels = np.asarray(
            CHANNEL_LABELS[self.generic_header.schema][self.data_header.headbox_type]
        )
        return reference_labels[self.data_header._saved_phys_chans]

    def convert_samples(self) -> np.ndarray[np.float32]:
        """Returns a copy of the array with physical sample units with respect to headbox-specific
        encoding schema

        Returns:
            np.ndarray[np.float32]: an array the size of self.samples, but with CONVERSION_FACTORS
            applied to each sample
        """
        conversion_factors = \
            CONVERSION_FACTORS[self.generic_header.schema][self.data_header.headbox_type]
        discard_bits = self.data_header.discardbits

        phys_samples = np.empty(shape=self.samples.shape, dtype=np.float32)
        for channels, func in conversion_factors:
            idxs = np.isin(self.data_header._saved_phys_chans, channels).nonzero()[0]
            phys_samples[idxs, :] = self.samples[idxs, :] * func(discard_bits)

        return phys_samples

    @staticmethod
    def read_toc_entries(f: BufferedReader) -> list[dict]:
        """
        The Table Of Contents file is an index into the raw data file used for
        mapping samples to times, and also to facilitate quick searches. This file
        ends in the extension ‘.toc’.
        The file starts with a generic EEG file header, and is followed by a series
        of fixed length records called toc entries.

        Each toc entry provides an offset into the raw data file to the start of a
        sample packet. The packet at that location is guaranteed to contain
        all abs_delta values in the delta information, followed by absolute
        sample values.

        A toc entry is added to the toc file whenever recording is started and also
        for every 1000 samples.

        Note: The byte alignment for the toc entry structure is set at 4 bytes.
        """
        gheader = GenericHeader.from_file(f)
        gheader.validate_guid(ETCTOC_TYPE_GUID)
        gheader.validate_schemas(ETCTOC_SCHEMAS)

        entries = []
        TOC_ENCODING = "<Lllh"
        # note: 16 byte reads for alignment, even though data is 14 bytes
        for entry in iter(partial(f.read, 16), b""):
            (offset, samplestamp, sample_num, sample_span) = \
                struct.unpack_from(TOC_ENCODING, entry, 0)

            entries.append(
                {
                    "offset": offset,
                    "samplestamp": samplestamp,
                    "sample_num": sample_num,
                    "sample_span": sample_span
                }
            )

        return entries

    @classmethod
    def from_filepair(cls, erd_file: str, toc_file: str) -> 'RawDataSegment':
        """Opens a pair of .erd + .etc/toc files and reads the contents

        Args:
            erd_file (str): path to raw data .erd file
            toc_file (str): path to matching .etc file

        Raises:
            NotImplementedError: unsupported headbox type
            ValueError: if toc entries are invalid

        Returns:
            RawDataSegment: RawDataSegment as read via erd and etc/toc files
        """
        with open(erd_file, "rb") as f:
            generic_header = GenericHeader.from_file(f)
            data_header = RawDataHeader.from_file(f)

        if data_header.headbox_type not in CHANNEL_LABELS[generic_header.schema] or \
                data_header.headbox_type not in CONVERSION_FACTORS[generic_header.schema]:
            raise NotImplementedError(
                'headbox type = {} not implemented in schema {}'.format(
                    data_header.headbox_type, generic_header.schema
                ))

        delta_mask_size = int(math.ceil(data_header.num_channels / 8))  # in bytes

        with open(toc_file, "rb") as f:
            entries = cls.read_toc_entries(f)

        if not entries:
            raise ValueError("no valid .etc toc entries found")

        num_samples = (
                entries[-1]["samplestamp"]
                + entries[-1]["sample_span"]
                - entries[0]["samplestamp"]
        )
        start_sample = entries[0]["samplestamp"]
        sample_stamps = np.arange(start_sample, start_sample + num_samples)

        def _read():
            sample_arr = np.zeros(
                (len(data_header._recorded_channel_idxs), num_samples), dtype="int32"
            )
            event_arr = np.zeros(num_samples, dtype="uint8")

            values_state = np.zeros(
                [len(data_header._recorded_channel_idxs), 2], dtype="int32"
            )
            # use to save state for last values for diff or interpolation
            # 2nd dimension [0: new, 1: old]

            phases_state = np.zeros(
                [len(data_header._recorded_channel_idxs), 2], dtype="uint8"
            )
            # use to save state for phase for variable freq interpolation only
            # 2nd dimension [0: phase, 1: initialization]

            with open(erd_file, "rb") as f:
                for i, entry in enumerate(entries):
                    next_entry = entries[i + 1] if i + 1 < len(entries) else None
                    sample_stamp = entry["samplestamp"]
                    span = entry["sample_span"]
                    start = np.searchsorted(sample_stamps, sample_stamp)
                    sample_idxs = slice(start, start + span)

                    f.seek(entry["offset"])
                    if next_entry is not None:
                        buffsize = next_entry["offset"] - entry["offset"]
                        buf = f.read(buffsize)
                    else:
                        buf = f.read()

                    read_block(
                        buf,
                        data_header._derived_frequency_factor,
                        delta_mask_size,
                        data_header._recorded_channel_idxs,
                        values_state,
                        phases_state,
                        event_arr[sample_idxs],
                        sample_arr[:, sample_idxs],
                    )

                return sample_arr, event_arr

        values = _read()

        samples = values[0].astype(dtype="int32")
        events = values[1].astype(dtype="uint8")

        return cls(sample_stamps, samples, events, generic_header, data_header)

    @classmethod
    def from_stc_segment(cls, stcsegment: STCSegment) -> 'RawDataSegment':
        """Wraps from_filepair for now, but should actually pass the
        start/stop/sample/span properties for verification as well later
        @TODO

        Args:
            stcsegment (STCSegment): STCSegment object read from .stc files

        Returns:
            RawDataSegment: Raw Data
        """
        return cls.from_filepair(stcsegment.filename, stcsegment.tocname)


class SampleStampToIndex(dict):
    """Helper class to generate samplestamp -> array index lookup tables
    with a dict hashmap.

    As other NeuroWorks data structures (e.g. event annotations) will refer back
    to samplestamps (generated from original hardware) as the unit of time reference,
    it is often necessary to look up the position of a samplestamp in a particular
    array.

    This helper class allows the construction of an array index lookup table from a particular
    samplestamp.
    """

    def __init__(self, sample_stamps: np.ndarray) -> 'SampleStampToIndex':
        """Initializes a look up table (a reverse hashmap) from a vector of samplestamps.

        Args:
            sample_stamps (np.ndarray): A vector of samplestamps, e.g. from read_erd()

        Raises:
            ValueError: a non-1D vector was input for sample_stamps
            TypeError: sample_stamps were not integers

        Returns:
            SampleStampToIndex: A wrapped dict object (this class)
        """
        sample_stamps = np.asarray(sample_stamps)
        if sample_stamps.ndim != 1:
            raise ValueError('sample_stamps must have a 1D vector')
        if not np.issubdtype(sample_stamps.dtype, np.integer):
            raise TypeError('sample_stamps must be integer type')

        super().__init__([(int(stamp), i) for i, stamp in enumerate(sample_stamps)])

    def get_multiple(self, sample_stamps: np.ndarray) -> np.ndarray:
        """Looks up multiple sample_stamps at a time

        Args:
            sample_stamps (np.ndarray): a vector of sample_stamps

        Returns:
            np.ndarray: array indices corresponding to sample_stamps
        """
        sample_stamps = np.asarray(sample_stamps)
        if sample_stamps.ndim != 1:
            raise ValueError('sample_stamps must have a 1D vector')
        if not np.issubdtype(sample_stamps.dtype, np.integer):
            raise TypeError('sample_stamps must be integer type')

        return np.array([self.get(stamp, -1) for stamp in sample_stamps])


def read_erd(file_dir: str, ignore_stc=False, parts=None,
             convert=False, convert_time=False):
    """From the spec doc Introduction:

    Each EEG study generates four files with the same name, but unique
    extensions. These four files are known as the patient information, raw
    data, notes and the table of contents (toc) files with the extensions
    .eeg, .erd, .ent and .etc respectively.

    Each file has two schema numbers which are used to identify version changes
    to the file format. The information in this document is valid only for the
    indicated schema numbers.

    Args:
        file_dir (str): Path to study
        ignore_stc (bool, optional): Ignore STC file when reading data. Defaults to False.
        parts (list, optional): List of segments to subselect. Defaults to None for all.
        convert (bool, optional): Convert to sensor units. Defaults to False.

    Raises:
        e: STC read failure
        IndexError: headbox type not implemented
    """

    try:
        stc_segments = STCSegmentsList.from_stc_dirpath(file_dir)
    except ValueError as e:
        # rethrow error, unless we were supposed to ignore the stc
        if not ignore_stc:
            raise e
        warnings.warn(str(e))

    if ignore_stc:
        stc_segments = STCSegmentsList.from_globbed_only_path(file_dir)
    if parts:
        stc_segments = stc_segments.filter_parts(parts)
    segments = [RawDataSegment.from_stc_segment(stc_) for stc_ in stc_segments]

    rawdata = RawDataSegment.join_segments(segments)

    frequency_ms = (1 / rawdata.data_header.sample_freq) * 1000
    timestamps = np.array(rawdata.sample_stamps * frequency_ms,
                          dtype="timedelta64[ms]").astype("timedelta64[ns]")

    if convert_time:
        sncfile = stc_segments.basename_with_suffix(".snc")

        if os.path.isfile(sncfile):  # has SNC sync file
            with open(sncfile, 'rb') as f:
                syncfile = SyncFile.from_file(f)
            timestamps = syncfile.interp_stamps(rawdata.sample_stamps)
        else:  # does not have SNC, infer from creation_time
            warnings.warn('no precision snc file, inferring timestamps from creation_time')
            timestamps = np.datetime64(rawdata.generic_header.creation_time) + timestamps

    data = rawdata.samples
    if convert:
        data = rawdata.convert_samples()

    da = xr.DataArray(
        data=data,
        dims=["channel", "sample"],
        coords={
            "channel": rawdata.channel_labels,
            "timestamp": ("sample", timestamps),
            "event": ("sample", rawdata.events),
            "samplestamp": ("sample", rawdata.sample_stamps),
        },
    )

    da.attrs = {**rawdata.generic_header.as_dict(), **rawdata.data_header.as_dict()}

    return da


def read_erd_segment(stc_segment: STCSegment, convert=False, convert_time=False):
    rawdata = RawDataSegment.join_segments(stc_segment)

    frequency_ms = (1 / rawdata.data_header.sample_freq) * 1000
    timestamps = np.array(rawdata.sample_stamps * frequency_ms,
                          dtype="timedelta64[ms]").astype("timedelta64[ns]")

    if convert_time:
        sncfile = stc_segments.basename_with_suffix(".snc")

        if os.path.isfile(sncfile):  # has SNC sync file
            with open(sncfile, 'rb') as f:
                syncfile = SyncFile.from_file(f)
            timestamps = syncfile.interp_stamps(rawdata.sample_stamps)
        else:  # does not have SNC, infer from creation_time
            warnings.warn('no precision snc file, inferring timestamps from creation_time')
            timestamps = np.datetime64(rawdata.generic_header.creation_time) + timestamps

    data = rawdata.samples
    if convert:
        data = rawdata.convert_samples()

    da = xr.DataArray(
        data=data,
        dims=["channel", "sample"],
        coords={
            "channel": rawdata.channel_labels,
            "timestamp": ("sample", timestamps),
            "event": ("sample", rawdata.events),
            "samplestamp": ("sample", rawdata.sample_stamps),
        },
    )

    da.attrs = {**rawdata.generic_header.as_dict(), **rawdata.data_header.as_dict()}

    return da
