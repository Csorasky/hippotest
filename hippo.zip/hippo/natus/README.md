[//]: # (These are reference links used in the body of this note and get stripped out when the markdown processor runs.)

   [the specification doc]: <https://github.com/natus-rad/nw-sdk-files/blob/main/docs/EEG%20File%20Format%209.3.doc>
   
   [Sample data]: </data>

# nw-sdk-files

This repository contains a prototype for reading raw EEG recordings into a single [Xarray](https://docs.xarray.dev/en/stable/index.html), and for parsing the associated notes file into a Python dictionary.

Overview:
- Raw data (ERD) is read via the `read_erd` function, which takes a study directory as an argument.
  - The `read_erd` function looks for `.erd` and `.toc` files and builds a lazy [Dask array](https://docs.dask.org/en/latest/array.html) with a chunk for each `.erd` file.
- Annotations (ENT) are read via the `read_annotations_file` function which takes a single `.ent` file as an argument
  - There is only one ENT file per study

File Reading Specification:
- This repo also includes [the specification doc] used to create the reader.
- It contains specifications for several data schemas but *this reader* currently only handles the schema of the initial sample data (8 and 9).

## Installation

Clone this repo and create a new __*local*__ conda environment in an Anaconda Prompt (`v23.1.0` or greater):
```bash
# Note: run from the repo root, creating an environment inside <root>/envs/
# Note: forward slash / will work fine with Windows Anaconda as well
conda env create --prefix ./envs/sdk-files --file environment.yml
conda activate ./envs/sdk-files
```

Optionally check your python version:
```bash
# Should show "Python 3.11.4"
python --version
```

Install the package and build the Cython extension:
```bash
# Note: run from the repo root
pip install -e .

# Ignore new folders: ./build and ./nwreader.egg-info
# Ignore nwreader/*.pyd: but do not delete; only appears if `-e` flag was used during pip install
```
> *Note: The `-e` flag avoids copying this package into the env, respecting any changes you make to this repo.*

> *Note: if the `-e` (editable) flag is NOT used, then be sure to run the below tests from somewhere OTHER than the root repo dir, because Python will think `nwreader` is referring to the local folder, rather than the installed package name and will throw a Module Not Found error.*

If you need to uninstall this package for some reason:
```bash
pip uninstall nwreader
```

If you need to delete the environment for some reason:
```bash
conda deactivate
conda env remove --prefix ./envs/sdk-files
```

## Reading ERD files

[Sample data] is also provided.
> Re-iterating: if you installed without the `-e` flag via `pip install .` then the below must be run from somewhere other than the repo root and the `./data` must be edited.


```python
from nwreader import read_erd

sample_dir = "./data/sample~ data_8ef647e3-e5ea-43a6-8c69-fb848b8db7c2/"
da = read_erd(sample_dir)
print(da)
```

    <xarray.DataArray 'concatenate-003e45b3ca0949fdd49162c8f3515a3e' (channel: 2,
                                                                      sample: 14470)>
    dask.array<concatenate, shape=(2, 14470), dtype=int32, chunksize=(2, 14469), chunktype=numpy.ndarray>
    Coordinates:
      * channel           (channel) <U8 'C3' 'CHEST'
        timestamp         (sample) timedelta64[ns] 00:00:03.555000 ... 00:01:15.9...
        frequency_factor  (channel) int16 1 4
        event             (sample) uint8 dask.array<chunksize=(1,), meta=np.ndarray>
        sample_stamp      (sample) int64 711 712 713 714 ... 15177 15178 15179 15180
    Dimensions without coordinates: sample
    Attributes: (12/22)
        guid:                   0xa5545b24a00032af11d0d795ca0b0791
        schema_version:         8
        header_version:         1
        timestamp:              2004-09-09 07:49:20
        study_id:               0
        lname:                  sample
        ...                     ...
        dsp_hw_version:         0.0
        dsp_sw_version:         0.0
        discard_bits:           6
        shorted:                [0 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 ...
        recorded_channel_idxs:  [ 0 26]
        frequency_factor:       [1 4]


This xarray.DataArray has two dimensions, `channel` and `sample`, and has coordinate labels for each channel. The `sample` dimension has a `timestamp` timeseries where each timestamp is an offset from the start of the study. The `sample` dimension also has a `sample_stamp` coordinate array -- these are the same sample stamps found in the annotations/notes file and can be used to match each note to a particular timestamp. 

Because of the way the input files are laid out on disk, slicing along the sample/timestamp dimension will be very efficient, whereas slicing just along the channel dimension will require opening and reading every input file.


```python
import pandas as pd

start = pd.Timedelta(5, "seconds")
stop = pd.Timedelta(30, "seconds")

print(da.set_xindex("timestamp").loc[dict(timestamp=slice(start, stop))].compute())
```

    <xarray.DataArray 'concatenate-003e45b3ca0949fdd49162c8f3515a3e' (channel: 2,
                                                                      sample: 5001)>
    array([[ 8338,  7995,  8704, ...,  8436,  8148,  8872],
           [12576,     0,     0, ...,     0,     0, 10615]], dtype=int32)
    Coordinates:
      * channel           (channel) <U8 'C3' 'CHEST'
      * timestamp         (sample) timedelta64[ns] 00:00:05 ... 00:00:30
        frequency_factor  (channel) int16 1 4
        event             (sample) uint8 0 0 0 0 0 0 0 0 0 0 ... 0 0 0 0 0 0 0 0 0 0
        sample_stamp      (sample) int64 1000 1001 1002 1003 ... 5997 5998 5999 6000
    Dimensions without coordinates: sample
    Attributes: (12/22)
        guid:                   0xa5545b24a00032af11d0d795ca0b0791
        schema_version:         8
        header_version:         1
        timestamp:              2004-09-09 07:49:20
        study_id:               0
        lname:                  sample
        ...                     ...
        dsp_hw_version:         0.0
        dsp_sw_version:         0.0
        discard_bits:           6
        shorted:                [0 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 ...
        recorded_channel_idxs:  [ 0 26]
        frequency_factor:       [1 4]


There's also an optional `convert` argument for applying the scientific conversions found in the spec doc to the signal data


```python
pt0_converted = read_erd(sample_dir, convert=True)
pt0_converted.data.compute()
```




    array([[2125.1145, 2302.163 , 2322.8984, ..., 2199.8152, 2197.9543,
            2381.1172],
           [2120.5469, 2124.2822,    0.    , ...,    0.    ,    0.    ,
            1665.6399]], dtype=float32)



## Reading ENT files

Each annotation is a dictionary containing at least a "Stamp" field which corresponds to the `sample_stamp` coordinate in the xarray


```python
import yaml
from nwreader import read_annotations_file

file = "./data/sample~ data_8ef647e3-e5ea-43a6-8c69-fb848b8db7c2/sample~ data_8ef647e3-e5ea-43a6-8c69-fb848b8db7c2.ent"
annotations = read_annotations_file(file)
print(yaml.dump(annotations[0]))
```

    Comment: ''
    Data:
      CreationTime: 38239.45097222222
      ModificationTime: 38239.45097222222
      Type: A564F36E-B1AE-4ae7-9D2F-D514812432B7
      User: ''
    GUID: '{D7E4766B-4F92-4C81-9C87-9DB4285015CE}'
    Host: Fastibm
    Origin: Acquisition
    ReadOnly: 1
    Stamp: 720
    Text: Start Recording
    Type: Annotation
    

## Reading EPO files

Each epo file is an OLE file with a variety of storages and streams. The `read_epo_file` function returns a dictionary of `EpoStorage`` objects, which can be used to access the data in each stream. See the `EpoStorage` class for more info.

```python
from nwreader.epo_reader import read_epo_file
from nwreader.epo_reader import EpoFile, EpoStorage, ChannelType, EpochInfo

file = "./data/sample.epo"
epoFile = read_epo_file(file)
epo_dict = epoFile.storages
epo_header = epoFile.header
epochInfo: EpochInfo = header.epochInfo

storage_name: str
storage: EpoStorage
for storage_name, storage in epo_dict.items():
    if storage.channelType == ChannelType.CH_STAGE:
        # print staging values
        print(f'[STAGING: {storage_name}]: {storage.channelRawData.as_sleep_stages()}')
    elif storage.channelType == ChannelType.CH_MARK:
        # print mark values
        print(f'[MARK: {storage_name}]: {storage.channelRawData.as_bytes()}')
```

## Running the tests

Tests can be run using the installation environment.

```bash
pytest -sv .
```

## License
Please see the included license file and request an NDA by emailin sdk@natus.com.
