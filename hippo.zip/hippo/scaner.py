import schedule
from hippo.comm import config
import time
from hippo.comm.logger import setup_log_hippo
from hippo.src.generate_device_data import generate_natus_device_data

'''
这个脚本的作用是定时扫描和处理 Natus 设备生成的原始文件。
每 8 小时运行一次 job 函数，记录任务开始和结束的时间，并调用 generate_natus_device_data 函数进行实际的文件处理。
主循环不断检查并执行到期的任务，确保定时任务能够按时执行。
'''
logger = setup_log_hippo()


def job():
    logger.info("Scan Natus Raw files At: {}".format(time.ctime()))
    generate_natus_device_data(config.natus_root_path, logger)
    logger.info("Scan Natus Raw files Done At: {}".format(time.ctime()))


# schedule.every().day.at(config.scaner_time).do(job)
schedule.every(8).hours.do(job)
schedule.run_all()


while True:
    schedule.run_pending()
    time.sleep(1)