"""
This is the main file for the file io server. It contains the main function that starts the server.
It also contains the implementation of the server class, which is responsible for handling
requests from the client.
用户上传了文件，发送消息
==》服务器接收消息，将文件下载至download_path，对文件处理并上传至s3，将download_path的暂存文件删除，并将序列化的信息传给用户
"""

import os
import asyncio
from concurrent.futures.process import ProcessPoolExecutor

from grpclib.utils import graceful_exit
from grpclib.server import Server, Stream

from hippo.comm import config
from hippo.comm.logger import setup_log_hippo
from hippo.src.lambda_mri import lambda_mri_handler
from hippo.src.lambda_meeg import lambda_meeg_handler
from hippo.src.lambda_natus import lambda_natus_handler
from hippo.src.lambda_video import lambda_video_handler

from hippo.proto.hippo.web.file_io_grpc import DataProcessBase
from hippo.proto.hippo.web.file_io_pb2 import ProtobufGenerationRequest, ProtobufGenerationResponse
from hippo.proto.hippo.common.data_type_pb2 import DataFileFormat
from hippo.proto.hippo.common.common_pb2 import BooleanType

# serviceRegistry_url = 'http://127.0.0.1:5001'
#
# node = {'ipaddress': '',
#         'port': ''
#         }
logger = setup_log_hippo()


class DataProcess(DataProcessBase):

    def __init__(self, executor: ProcessPoolExecutor):
        # logging.basicConfig(level=logging.INFO)
        # logging.info('initializing GRPC server')
        # try:
        #     registerAPI = serviceRegistry_url + "/register"
        #     x = requests.post(registerAPI, data=node)
        # except Exception as e:
        #     logging.warning('Failed to register: ' + str(e))
        self.workspace = config.workspace
        self._executor = executor
        self._loop = asyncio.get_event_loop()

    async def generate_protobuf(self, stream: Stream[ProtobufGenerationRequest, ProtobufGenerationResponse]) -> None:
        """
        Run the local lambda function to generate the protobuf file for the large data.
        """
        request = await stream.recv_message()    
        assert request is not None
        logger.info(f'run_lambda_function:{request}')

        # Get the patient id and identifier file key from the request
        patient_id = request.patientId
        is_raw_data_internal = request.isRawDataInternal
        raw_data_directory = request.rawDataDirectory
        data_file_format = request.dataFileFormat
        raw_data_id = request.rawDataId
        hospital_info = request.hospital
        download_id = request.downloadId
        token = request.downloadAwtToken

        hospital_eeg_system = hospital_info.eegSystem
        hospital_image_system = hospital_info.imageSystem

        patient_folder = self.check_folder(patient_id)

        if data_file_format == DataFileFormat.EEG_EDF or data_file_format == DataFileFormat.MEG_CTF:
            # MEEG lambda function process
            message, job_status, device_data = lambda_meeg_handler(patient_id,
                                                                   patient_folder,
                                                                   raw_data_directory,
                                                                   data_file_format,
                                                                   raw_data_id,
                                                                   is_raw_data_internal,
                                                                   logger)

        elif data_file_format == DataFileFormat.MRI_NIFTI1 or data_file_format == DataFileFormat.MRI_DICOM:
            # MRI lambda function process
            message, job_status, device_data = lambda_mri_handler(patient_id,
                                                                  patient_folder,
                                                                  raw_data_directory,
                                                                  data_file_format,
                                                                  raw_data_id,
                                                                  is_raw_data_internal,
                                                                  hospital_image_system,
                                                                  download_id,
                                                                  token,
                                                                  logger)
        elif data_file_format == DataFileFormat.EEG_NATUS_RAW:
            # EEG Natus lambda function process
            message, job_status, device_data = lambda_natus_handler(patient_id,
                                                                    patient_folder,
                                                                    raw_data_directory,
                                                                    data_file_format,
                                                                    raw_data_id,
                                                                    is_raw_data_internal,
                                                                    hospital_eeg_system,
                                                                    logger)
        elif data_file_format == DataFileFormat.EEG_VIDEO:
            # EEG Video lambda function process
            message, job_status, device_data = lambda_video_handler(patient_id,
                                                                    patient_folder,
                                                                    raw_data_directory,
                                                                    data_file_format,
                                                                    raw_data_id,
                                                                    is_raw_data_internal,
                                                                    hospital_eeg_system,
                                                                    logger)
        else:
            message = f'Invalid data type: {data_file_format}'
            job_status = False
            device_data = None

        await stream.send_message(ProtobufGenerationResponse(patientId=patient_id,
                                                             jobStatus=BooleanType.BOOLEAN_TRUE
                                                             if job_status else BooleanType.BOOLEAN_FALSE,
                                                             deviceDataList=device_data,
                                                             message=message))
        logger.info(f'run_lambda_function:{patient_id} {job_status} {message}')

    def check_folder(self, patient_id):
        patient_folder = os.path.join(self.workspace, patient_id)
        if not os.path.exists(patient_folder):
            os.makedirs(patient_folder)
        return patient_folder


async def main(*, host: str = '0.0.0.0', port: int = config.port) -> None:
    with ProcessPoolExecutor(max_workers=3) as executor:
        server = Server([DataProcess(executor)])
        # keepalive_time=5400, keepalive_timeout=1800, keepalive_permit_without_calls=True
        # server.keepalive_permit_without_calls = True
        # server.keep_alive_timeout = 1800
        # server.keep_alive_time = 5400
        # Note: graceful_exit isn't supported in Windows
        with graceful_exit([server]):
            await server.start(host, port)
            logger.info(f'Hippo Serving on {host}:{port}')
            await server.wait_closed()


if __name__ == '__main__':
    asyncio.run(main())
