from nwreader import read_annotations_file
import os
from nwreader.erd_reader import STCSegmentsList, RawDataSegment, read_erd_segment
import mne
import numpy as np

def find_field(data, field):
    if isinstance(data, list):
        for item in data:
            result = find_field(item, field)
            if result is not None:
                return result
    elif isinstance(data, dict):
        for key, value in data.items():
            if key == field:
                return value
            result = find_field(value, field)
            if result is not None:
                return result
    return None


file = r'C:\Users\RanJian\Downloads\CASTRORUIZAD_f07d5313-404e-433a-8c2f-4e1f535959b1'

stc_segments = STCSegmentsList.from_stc_dirpath(file)

for stc_ in stc_segments:
    raw_data_segment = RawDataSegment.from_stc_segment(stc_)
    ret = read_erd_segment([raw_data_segment])
    print(ret.attrs)


    natus_files = os.listdir(file)
    for natus_file in natus_files:
        if natus_file.endswith('.ent') and not natus_file.startswith('.'):
            ent_file_name = natus_file
    ent_file = '{}/{}'.format(file, ent_file_name)

    # read raw nats file
    # ret = read_erd(download_path, ignore_stc=True, convert=True)

    annotations = read_annotations_file(ent_file)
    nats_chan_names = find_field(annotations, 'ChanNames')
    shorted = ret.attrs['shorted']
    if nats_chan_names is not None:
        channel_name_list = [value for value, flag in zip(nats_chan_names, shorted) if not flag]
    else:
        channel_name_list = ret.channel.values.tolist()

    sample_freq = ret.attrs['sample_freq']
    utc_time = ret.attrs['creation_time']
    natus_raw_data = ret.data / 1e6  # convert to volts
    channel_types = ['eeg' for _ in range(len(channel_name_list))]

    # create mne raw object
    info = mne.create_info(
        ch_names=channel_name_list,
        sfreq=sample_freq,
        ch_types=channel_types
    )
    raw_data = mne.io.RawArray(-natus_raw_data, info, verbose=False)
    print(raw_data)
    # get the raw data information
    original_sfreq = int(raw_data.info['sfreq'])
    ch_names = np.array(raw_data.ch_names)
    chantypes = raw_data.get_channel_types()
    bad_ch = raw_data.info['bads']
    print(original_sfreq)
    print(ch_names)
    print(chantypes)
    print(bad_ch)
    print(utc_time)
    print(raw_data.times)
    print(raw_data.get_data().shape)